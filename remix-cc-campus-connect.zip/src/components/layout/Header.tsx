import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { storageService } from '../../services/storage';
import { Search, Bell, LogOut, ShieldCheck, User as UserIcon, Menu, X } from 'lucide-react';

interface HeaderProps {
  onOpenSearch: () => void;
  onOpenNotifications: () => void;
  onOpenExport: () => void;
  onNavigateHome: () => void;
  onToggleMobileNav?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenSearch,
  onOpenNotifications,
  onOpenExport,
  onNavigateHome,
  onToggleMobileNav
}) => {
  const { currentUser, logout } = useAuth();
  const [showProfileModal, setShowProfileModal] = useState(false);

  const notifications = currentUser ? storageService.getNotificationsForUser(currentUser.id) : [];
  const unreadNotifCount = notifications.filter(n => !n.isRead).length;

  const getRoleLabel = (role?: string) => {
    switch (role) {
      case 'PRINCIPAL': return 'Executive Principal';
      case 'HOD': return 'Head of Department (HOD)';
      case 'ADVISOR': return 'Faculty / Advisor';
      case 'STUDENT': return 'Student';
      default: return 'Authorized User';
    }
  };

  const handleLogout = () => {
    logout();
    onNavigateHome();
  };

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Left: Brand & Mobile Nav Toggle */}
        <div className="flex items-center gap-3">
          {currentUser && onToggleMobileNav && (
            <button
              onClick={onToggleMobileNav}
              className="lg:hidden p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-md transition-colors"
              title="Open Navigation Menu"
            >
              <Menu className="w-5 h-5" />
            </button>
          )}

          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-md bg-red-600 flex items-center justify-center text-white font-bold text-base shadow-xs shrink-0">
              CC
            </div>
            <div>
              <span className="text-base font-bold tracking-tight text-slate-900 whitespace-nowrap">
                CC Campus Connect
              </span>
              <span className="hidden md:inline-block text-[11px] text-slate-400 ml-2 font-mono">
                {currentUser ? `${getRoleLabel(currentUser.role)} Portal` : 'Enterprise System'}
              </span>
            </div>
          </div>
        </div>

        {/* Center: Scope Breadcrumb (strictly informational, no switching!) */}
        {currentUser && (
          <div className="hidden lg:flex items-center text-xs text-slate-500 font-medium">
            <span className="text-slate-400">Authorized Portal</span>
            <span className="mx-1.5 text-slate-300">/</span>
            <span className="font-semibold text-slate-800">{getRoleLabel(currentUser.role)}</span>
            {currentUser.departmentName && (
              <>
                <span className="mx-1.5 text-slate-300">/</span>
                <span className="text-slate-600 truncate max-w-xs">{currentUser.departmentName}</span>
              </>
            )}
          </div>
        )}

        {/* Right: Controls & Logout */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          {/* Global Search */}
          <button
            onClick={onOpenSearch}
            className="p-2 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-md transition-colors flex items-center gap-1.5 text-xs"
            title="Search records"
          >
            <Search className="w-4 h-4" />
            <span className="hidden sm:inline font-medium text-slate-400">Search</span>
          </button>

          {/* Notifications Button */}
          <button
            onClick={onOpenNotifications}
            className="relative p-2 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-md transition-colors"
            title="Notification Center"
          >
            <Bell className="w-4 h-4" />
            {unreadNotifCount > 0 && (
              <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-red-600 text-white font-mono text-[10px] font-bold flex items-center justify-center shadow-xs">
                {unreadNotifCount}
              </span>
            )}
          </button>

          {/* User Profile Badge (Informational only - NO switching!) */}
          {currentUser && (
            <div className="flex items-center gap-2 pl-2 border-l border-slate-200">
              <div className="w-8 h-8 rounded-md bg-slate-100 border border-slate-200 flex items-center justify-center text-slate-800 font-bold text-xs shrink-0">
                {currentUser.name.charAt(0)}
              </div>
              <div className="hidden sm:block text-left">
                <div className="text-xs font-bold text-slate-900 leading-tight truncate max-w-[140px]">
                  {currentUser.name}
                </div>
                <div className="text-[10px] text-slate-500 font-mono leading-none mt-0.5">
                  {currentUser.role}
                </div>
              </div>

              {/* Explicit Logout Button (Requirement 4) */}
              <button
                onClick={handleLogout}
                className="ml-2 px-3 py-1.5 text-xs font-bold text-red-600 hover:text-white hover:bg-red-600 border border-red-200 hover:border-red-600 rounded-md transition-all flex items-center gap-1.5 shadow-2xs"
                title="Sign out of your session"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Log Out</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
