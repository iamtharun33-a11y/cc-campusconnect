import {
  User,
  Department,
  CollegeClass,
  Announcement,
  AnnouncementComment,
  Conversation,
  PrivateMessage,
  Suggestion,
  Grievance,
  FollowUpRequest,
  NotificationItem,
  AuditLog,
  UserRole,
  GrievanceStatus,
  SuggestionStatus
} from '../types';
import { generateSalt, hashPassword, verifyPassword } from './crypto';

const STORAGE_KEYS = {
  USERS: 'cc_campus_users_v3',
  CURRENT_USER_ID: 'cc_campus_current_user_id_v3',
  SESSION_TOKEN: 'cc_campus_session_token_v3',
  DEPARTMENTS: 'cc_campus_departments_v3',
  CLASSES: 'cc_campus_classes_v3',
  ANNOUNCEMENTS: 'cc_campus_announcements_v3',
  COMMENTS: 'cc_campus_comments_v3',
  CONVERSATIONS: 'cc_campus_conversations_v3',
  MESSAGES: 'cc_campus_messages_v3',
  SUGGESTIONS: 'cc_campus_suggestions_v3',
  GRIEVANCES: 'cc_campus_grievances_v3',
  FOLLOW_UPS: 'cc_campus_follow_ups_v3',
  NOTIFICATIONS: 'cc_campus_notifications_v3',
  AUDIT_LOGS: 'cc_campus_audit_logs_v3',
  SYSTEM_SEEDED: 'cc_campus_system_initialized_v3',
};

function getFromStorage<T>(key: string, defaultValue: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return defaultValue;
    return JSON.parse(raw) as T;
  } catch (err) {
    console.error(`Error reading ${key} from storage:`, err);
    return defaultValue;
  }
}

function saveToStorage<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (err) {
    console.error(`Error saving ${key} to storage:`, err);
  }
}

export const storageService = {
  // ---- AUDIT LOGGING ----
  logAudit(userId: string, userName: string, userRole: UserRole, action: string, targetResource: string, details: string) {
    const logs = getFromStorage<AuditLog[]>(STORAGE_KEYS.AUDIT_LOGS, []);
    const newLog: AuditLog = {
      id: 'aud_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      userId,
      userName,
      userRole,
      action,
      targetResource,
      details,
      timestamp: new Date().toISOString()
    };
    logs.unshift(newLog);
    saveToStorage(STORAGE_KEYS.AUDIT_LOGS, logs.slice(0, 500));
  },

  getAuditLogs(): AuditLog[] {
    return getFromStorage<AuditLog[]>(STORAGE_KEYS.AUDIT_LOGS, []);
  },

  // ---- NOTIFICATIONS ----
  createNotification(
    userId: string,
    title: string,
    message: string,
    type: NotificationItem['type'],
    linkTarget?: NotificationItem['linkTarget'],
    senderName?: string,
    senderRole?: UserRole
  ): NotificationItem {
    const notifications = getFromStorage<NotificationItem[]>(STORAGE_KEYS.NOTIFICATIONS, []);
    const newNotif: NotificationItem = {
      id: 'notif_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      userId,
      title,
      message,
      senderName,
      senderRole,
      type,
      linkTarget,
      isRead: false,
      createdAt: new Date().toISOString()
    };
    notifications.unshift(newNotif);
    saveToStorage(STORAGE_KEYS.NOTIFICATIONS, notifications);
    return newNotif;
  },

  getNotificationsForUser(userId: string): NotificationItem[] {
    const notifications = getFromStorage<NotificationItem[]>(STORAGE_KEYS.NOTIFICATIONS, []);
    return notifications.filter(n => n.userId === userId);
  },

  getNotificationById(notifId: string): NotificationItem | undefined {
    const notifications = getFromStorage<NotificationItem[]>(STORAGE_KEYS.NOTIFICATIONS, []);
    return notifications.find(n => n.id === notifId);
  },

  markNotificationAsRead(notifId: string): void {
    const notifications = getFromStorage<NotificationItem[]>(STORAGE_KEYS.NOTIFICATIONS, []);
    const updated = notifications.map(n => n.id === notifId ? { ...n, isRead: true } : n);
    saveToStorage(STORAGE_KEYS.NOTIFICATIONS, updated);
  },

  markAllNotificationsAsRead(userId: string): void {
    const notifications = getFromStorage<NotificationItem[]>(STORAGE_KEYS.NOTIFICATIONS, []);
    const updated = notifications.map(n => n.userId === userId ? { ...n, isRead: true } : n);
    saveToStorage(STORAGE_KEYS.NOTIFICATIONS, updated);
  },

  // ---- USERS & AUTHENTICATION (4 PORTALS ONLY: STUDENT, ADVISOR, HOD, PRINCIPAL) ----
  getUsers(): User[] {
    const rawUsers = getFromStorage<any[]>(STORAGE_KEYS.USERS, []);
    // Migration safeguard: if any user was saved as ADMIN, migrate role to HOD
    return rawUsers.map(u => {
      if (u.role === 'ADMIN') {
        return { ...u, role: 'HOD' as UserRole };
      }
      return u as User;
    });
  },

  getUserById(id: string): User | undefined {
    const users = this.getUsers();
    return users.find(u => u.id === id);
  },

  getUserByIdentifier(identifier: string): User | undefined {
    const users = this.getUsers();
    const clean = identifier.trim().toLowerCase();
    return users.find(u => 
      u.email.toLowerCase() === clean || 
      (u.rollNumber && u.rollNumber.toLowerCase() === clean) ||
      (u.employeeId && u.employeeId.toLowerCase() === clean)
    );
  },

  async createUser(user: Omit<User, 'id' | 'createdAt' | 'salt' | 'passwordHash'> & { password: string }): Promise<User> {
    const users = this.getUsers();

    if (users.some(u => u.email.toLowerCase() === user.email.toLowerCase())) {
      throw new Error(`An account with email "${user.email}" already exists.`);
    }

    if (user.rollNumber && users.some(u => u.rollNumber && u.rollNumber.toLowerCase() === user.rollNumber?.toLowerCase())) {
      throw new Error(`An account with Student Register Number "${user.rollNumber}" already exists.`);
    }

    if (user.employeeId && users.some(u => u.employeeId && u.employeeId.toLowerCase() === user.employeeId?.toLowerCase())) {
      throw new Error(`An account with Staff ID "${user.employeeId}" already exists.`);
    }

    const salt = await generateSalt();
    const passwordHash = await hashPassword(user.password, salt);

    const newUser: User = {
      ...user,
      id: 'usr_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      salt,
      passwordHash,
      failedLoginAttempts: 0,
      lockedUntil: null,
      createdAt: new Date().toISOString()
    };

    users.push(newUser);
    saveToStorage(STORAGE_KEYS.USERS, users);

    this.logAudit(newUser.id, newUser.name, newUser.role, 'USER_REGISTERED', 'USERS', `Registered account for ${newUser.email} (${newUser.role})`);
    return newUser;
  },

  async authenticateUser(identifier: string, password: string, requiredRole?: UserRole): Promise<{ success: boolean; user?: User; error?: string }> {
    const user = this.getUserByIdentifier(identifier);
    if (!user) {
      return { success: false, error: 'Invalid credentials. Please verify your institutional email or register number.' };
    }

    if (user.lockedUntil && new Date(user.lockedUntil).getTime() > Date.now()) {
      const waitMinutes = Math.ceil((new Date(user.lockedUntil).getTime() - Date.now()) / (60 * 1000));
      return { success: false, error: `Account temporarily locked due to repeated failed logins. Please try again in ${waitMinutes} minute(s).` };
    }

    if (requiredRole && user.role !== requiredRole) {
      return { success: false, error: `Unauthorized: This account has the role "${user.role}" and cannot access the ${requiredRole} Portal.` };
    }

    if (!user.isActive) {
      return { success: false, error: 'Account is deactivated or pending administrative verification.' };
    }

    const isMatch = await verifyPassword(password, user.salt, user.passwordHash);
    const users = this.getUsers();
    const userIndex = users.findIndex(u => u.id === user.id);

    if (!isMatch) {
      const attempts = (user.failedLoginAttempts || 0) + 1;
      let lockUntil: string | null = null;
      if (attempts >= 5) {
        lockUntil = new Date(Date.now() + 5 * 60 * 1000).toISOString();
      }

      if (userIndex !== -1) {
        users[userIndex].failedLoginAttempts = attempts;
        users[userIndex].lockedUntil = lockUntil;
        saveToStorage(STORAGE_KEYS.USERS, users);
      }

      this.logAudit(user.id, user.name, user.role, 'FAILED_LOGIN', 'AUTH', `Failed password attempt (${attempts}/5)`);
      if (lockUntil) {
        return { success: false, error: 'Too many failed login attempts. Account locked for 5 minutes for security.' };
      }
      return { success: false, error: 'Invalid password. Please verify your credentials and try again.' };
    }

    if (userIndex !== -1) {
      users[userIndex].failedLoginAttempts = 0;
      users[userIndex].lockedUntil = null;
      saveToStorage(STORAGE_KEYS.USERS, users);
    }

    const sessionToken = 'ses_' + Date.now() + '_' + Math.random().toString(36).substring(2, 8);
    localStorage.setItem(STORAGE_KEYS.SESSION_TOKEN, sessionToken);
    this.setCurrentUserId(user.id);

    this.logAudit(user.id, user.name, user.role, 'USER_LOGIN', 'AUTH', `Successful login for ${user.email}`);
    return { success: true, user };
  },

  getCurrentUserId(): string | null {
    return localStorage.getItem(STORAGE_KEYS.CURRENT_USER_ID);
  },

  setCurrentUserId(id: string | null): void {
    if (id) {
      localStorage.setItem(STORAGE_KEYS.CURRENT_USER_ID, id);
    } else {
      localStorage.removeItem(STORAGE_KEYS.CURRENT_USER_ID);
      localStorage.removeItem(STORAGE_KEYS.SESSION_TOKEN);
    }
  },

  // ---- DEPARTMENTS & CLASSES ----
  getDepartments(): Department[] {
    const depts = getFromStorage<Department[]>(STORAGE_KEYS.DEPARTMENTS, []);
    if (depts.length === 0) {
      return this.getDefaultDepartments();
    }
    return depts;
  },

  getDefaultDepartments(): Department[] {
    return [
      { id: 'dep_cse', name: 'Computer Science & Engineering', code: 'CSE', hodName: 'Dr. Aruna Ramanathan' },
      { id: 'dep_it', name: 'Information Technology', code: 'IT', hodName: 'Dr. S. K. Praveen' },
      { id: 'dep_aids', name: 'Artificial Intelligence & Data Science', code: 'AI & DS', hodName: 'Dr. Malathi V.' },
      { id: 'dep_ece', name: 'Electronics & Communication Engineering', code: 'ECE', hodName: 'Prof. Ramesh Sundaram' },
      { id: 'dep_eee', name: 'Electrical & Electronics Engineering', code: 'EEE', hodName: 'Dr. Muruganandam P.' },
      { id: 'dep_mech', name: 'Mechanical Engineering', code: 'MECH', hodName: 'Dr. Vikram Malhotra' },
      { id: 'dep_civil', name: 'Civil Engineering', code: 'CIVIL', hodName: 'Dr. Anandhakumar K.' },
      { id: 'dep_chem', name: 'Chemical Engineering', code: 'CHEM', hodName: 'Dr. Subhashini R.' },
      { id: 'dep_bme', name: 'Biomedical Engineering', code: 'BME', hodName: 'Dr. Preethi Nair' },
      { id: 'dep_aero', name: 'Aerospace & Aeronautical Engineering', code: 'AERO', hodName: 'Dr. V. Raghavan' },
      { id: 'dep_mca', name: 'Master of Computer Applications', code: 'MCA', hodName: 'Dr. Karthikeyan M.' },
      { id: 'dep_mba', name: 'Department of Management Studies', code: 'MBA', hodName: 'Dr. Gayathri Devi' },
      { id: 'dep_sh', name: 'Science & Humanities', code: 'S&H', hodName: 'Dr. Padmavathi S.' }
    ];
  },

  findOrCreateDepartment(name: string, customCode?: string): Department {
    const trimmed = name.trim();
    const depts = this.getDepartments();
    const existing = depts.find(d => d.name.toLowerCase() === trimmed.toLowerCase() || (d.code && d.code.toLowerCase() === trimmed.toLowerCase()));
    if (existing) return existing;

    const code = customCode?.trim().toUpperCase() || trimmed.split(' ').map(w => w[0]).join('').slice(0, 5).toUpperCase();
    const id = 'dep_' + Date.now().toString(36) + '_' + Math.random().toString(36).substring(2, 5);
    const newDept: Department = { id, name: trimmed, code };
    depts.push(newDept);
    saveToStorage(STORAGE_KEYS.DEPARTMENTS, depts);
    this.logAudit('system', 'System Registry', 'HOD', 'DEPARTMENT_CREATED', 'DEPARTMENTS', `Dynamic department registered: ${trimmed} (${code})`);
    return newDept;
  },

  getClasses(): CollegeClass[] {
    return getFromStorage<CollegeClass[]>(STORAGE_KEYS.CLASSES, []);
  },

  findOrCreateClass(departmentId: string, className: string, semester: number = 1): CollegeClass {
    const trimmed = className.trim();
    const classes = this.getClasses();
    const existing = classes.find(c => c.departmentId === departmentId && c.name.toLowerCase() === trimmed.toLowerCase());
    if (existing) return existing;

    const newClass: CollegeClass = {
      id: 'cls_' + Date.now().toString(36) + '_' + Math.random().toString(36).substring(2, 5),
      departmentId,
      name: trimmed,
      semester
    };
    classes.push(newClass);
    saveToStorage(STORAGE_KEYS.CLASSES, classes);
    return newClass;
  },

  // ---- ANNOUNCEMENTS ----
  getAnnouncements(): Announcement[] {
    return getFromStorage<Announcement[]>(STORAGE_KEYS.ANNOUNCEMENTS, []);
  },

  getAnnouncementsForUser(user: User): Announcement[] {
    const all = this.getAnnouncements().filter(a => !a.isArchived);
    return all.filter(a => {
      if (a.isDraft) {
        return a.publisherId === user.id;
      }
      if (a.audience === 'COLLEGE_WIDE') return true;
      if (a.audience === 'DEPARTMENT') {
        if (user.role === 'PRINCIPAL') return true;
        return user.departmentId === a.targetDepartmentId;
      }
      if (a.audience === 'CLASS') {
        if (user.role === 'PRINCIPAL') return true;
        if (user.role === 'HOD' && user.departmentId === a.targetDepartmentId) return true;
        if (user.role === 'ADVISOR' && user.classId === a.targetClassId) return true;
        if (user.role === 'STUDENT' && user.classId === a.targetClassId) return true;
        return false;
      }
      return false;
    });
  },

  createAnnouncement(data: Omit<Announcement, 'id' | 'createdAt' | 'updatedAt' | 'acknowledgements'>): Announcement {
    const all = this.getAnnouncements();
    const newNotice: Announcement = {
      ...data,
      id: 'ann_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      acknowledgements: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    all.unshift(newNotice);
    saveToStorage(STORAGE_KEYS.ANNOUNCEMENTS, all);

    this.logAudit(
      newNotice.publisherId,
      newNotice.publisherName,
      newNotice.publisherRole,
      newNotice.isDraft ? 'NOTICE_DRAFT_CREATED' : 'NOTICE_PUBLISHED',
      'ANNOUNCEMENTS',
      `Notice: "${newNotice.title}" [${newNotice.category}] audience: ${newNotice.audience}`
    );

    if (!newNotice.isDraft) {
      const users = this.getUsers();
      users.forEach(u => {
        if (u.id === newNotice.publisherId) return;
        let shouldNotify = false;
        if (newNotice.audience === 'COLLEGE_WIDE') shouldNotify = true;
        else if (newNotice.audience === 'DEPARTMENT' && u.departmentId === newNotice.targetDepartmentId) shouldNotify = true;
        else if (newNotice.audience === 'CLASS' && u.classId === newNotice.targetClassId) shouldNotify = true;

        if (shouldNotify) {
          this.createNotification(
            u.id,
            `Official Circular: ${newNotice.title}`,
            `${newNotice.publisherName} published a notice (${newNotice.category}).`,
            'ANNOUNCEMENT',
            { module: 'announcements', id: newNotice.id },
            newNotice.publisherName,
            newNotice.publisherRole
          );
        }
      });
    }

    return newNotice;
  },

  acknowledgeAnnouncement(announcementId: string, userId: string): void {
    const all = this.getAnnouncements();
    const notice = all.find(a => a.id === announcementId);
    if (!notice) return;
    if (!notice.acknowledgements) notice.acknowledgements = [];
    if (!notice.acknowledgements.includes(userId)) {
      notice.acknowledgements.push(userId);
      saveToStorage(STORAGE_KEYS.ANNOUNCEMENTS, all);
    }
  },

  // ---- PUBLIC DISCUSSIONS & COMMENTS ----
  getCommentsForAnnouncement(announcementId: string): AnnouncementComment[] {
    const comments = getFromStorage<AnnouncementComment[]>(STORAGE_KEYS.COMMENTS, []);
    return comments
      .filter(c => c.announcementId === announcementId && !c.isModerated)
      .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
  },

  addComment(announcementId: string, user: User, content: string): AnnouncementComment {
    const comments = getFromStorage<AnnouncementComment[]>(STORAGE_KEYS.COMMENTS, []);
    const newComment: AnnouncementComment = {
      id: 'cmt_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      announcementId,
      userId: user.id,
      userName: user.name,
      userRole: user.role,
      content: content.trim(),
      createdAt: new Date().toISOString()
    };
    comments.push(newComment);
    saveToStorage(STORAGE_KEYS.COMMENTS, comments);
    this.logAudit(user.id, user.name, user.role, 'COMMENT_POSTED', 'DISCUSSIONS', `Comment on notice ID ${announcementId}`);
    return newComment;
  },

  moderateComment(commentId: string, moderator: User): void {
    const comments = getFromStorage<AnnouncementComment[]>(STORAGE_KEYS.COMMENTS, []);
    const updated = comments.map(c => c.id === commentId ? { ...c, isModerated: true } : c);
    saveToStorage(STORAGE_KEYS.COMMENTS, updated);
    this.logAudit(moderator.id, moderator.name, moderator.role, 'COMMENT_MODERATED', 'DISCUSSIONS', `Moderated comment ${commentId}`);
  },

  // ---- PRIVATE MESSAGING (4 ROLES) ----
  getAuthorizedRecipientsForUser(currentUser: User): User[] {
    const allUsers = this.getUsers().filter(u => u.id !== currentUser.id && u.isActive);

    switch (currentUser.role) {
      case 'STUDENT': {
        const studentClass = this.getClasses().find(c => c.id === currentUser.classId);
        return allUsers.filter(u => u.role === 'ADVISOR' && (u.id === studentClass?.advisorId || u.classId === currentUser.classId));
      }
      case 'ADVISOR': {
        return allUsers.filter(u => {
          if (u.role === 'STUDENT' && u.classId === currentUser.classId) return true;
          if (u.role === 'HOD' && u.departmentId === currentUser.departmentId) return true;
          if (u.role === 'PRINCIPAL') return true;
          return false;
        });
      }
      case 'HOD': {
        return allUsers.filter(u => {
          if (u.role === 'ADVISOR' && u.departmentId === currentUser.departmentId) return true;
          if (u.role === 'PRINCIPAL') return true;
          return false;
        });
      }
      case 'PRINCIPAL': {
        return allUsers.filter(u => u.role === 'HOD' || u.role === 'ADVISOR');
      }
      default:
        return [];
    }
  },

  getConversationsForUser(userId: string): Conversation[] {
    const conversations = getFromStorage<Conversation[]>(STORAGE_KEYS.CONVERSATIONS, []);
    return conversations
      .filter(c => c.participantIds.includes(userId))
      .sort((a, b) => new Date(b.lastMessageAt).getTime() - new Date(a.lastMessageAt).getTime());
  },

  getMessagesInConversation(conversationId: string, currentUserId: string): PrivateMessage[] {
    const conversations = getFromStorage<Conversation[]>(STORAGE_KEYS.CONVERSATIONS, []);
    const conversation = conversations.find(c => c.id === conversationId);
    if (!conversation || !conversation.participantIds.includes(currentUserId)) {
      throw new Error('Unauthorized to view this conversation');
    }

    const messages = getFromStorage<PrivateMessage[]>(STORAGE_KEYS.MESSAGES, []);
    const convoMessages = messages
      .filter(m => m.conversationId === conversationId)
      .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());

    let hasUnread = false;
    const updatedMessages = messages.map(m => {
      if (m.conversationId === conversationId && m.recipientId === currentUserId && !m.isRead) {
        hasUnread = true;
        return { ...m, isRead: true };
      }
      return m;
    });

    if (hasUnread) {
      saveToStorage(STORAGE_KEYS.MESSAGES, updatedMessages);
      if (conversation.unreadCountByUser) {
        conversation.unreadCountByUser[currentUserId] = 0;
        saveToStorage(STORAGE_KEYS.CONVERSATIONS, conversations);
      }
    }

    return convoMessages;
  },

  sendPrivateMessage(sender: User, recipientId: string, content: string): PrivateMessage {
    const recipient = this.getUserById(recipientId);
    if (!recipient) throw new Error('Recipient does not exist');

    const conversations = getFromStorage<Conversation[]>(STORAGE_KEYS.CONVERSATIONS, []);
    let conversation = conversations.find(c =>
      c.participantIds.length === 2 &&
      c.participantIds.includes(sender.id) &&
      c.participantIds.includes(recipient.id)
    );

    const now = new Date().toISOString();

    if (!conversation) {
      conversation = {
        id: 'cnv_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
        participantIds: [sender.id, recipient.id],
        participantNames: [sender.name, recipient.name],
        participantRoles: [sender.role, recipient.role],
        lastMessageSnippet: content.slice(0, 60),
        lastMessageAt: now,
        unreadCountByUser: {
          [sender.id]: 0,
          [recipient.id]: 1
        },
        createdAt: now
      };
      conversations.unshift(conversation);
    } else {
      conversation.lastMessageSnippet = content.slice(0, 60);
      conversation.lastMessageAt = now;
      if (!conversation.unreadCountByUser) conversation.unreadCountByUser = {};
      conversation.unreadCountByUser[recipient.id] = (conversation.unreadCountByUser[recipient.id] || 0) + 1;
    }

    saveToStorage(STORAGE_KEYS.CONVERSATIONS, conversations);

    const messages = getFromStorage<PrivateMessage[]>(STORAGE_KEYS.MESSAGES, []);
    const newMessage: PrivateMessage = {
      id: 'msg_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      conversationId: conversation.id,
      senderId: sender.id,
      senderName: sender.name,
      senderRole: sender.role,
      recipientId: recipient.id,
      content: content.trim(),
      isRead: false,
      createdAt: now
    };
    messages.push(newMessage);
    saveToStorage(STORAGE_KEYS.MESSAGES, messages);

    this.createNotification(
      recipient.id,
      `Private Message from ${sender.name}`,
      content.slice(0, 80),
      'MESSAGE',
      { module: 'messages', id: conversation.id },
      sender.name,
      sender.role
    );

    return newMessage;
  },

  // ---- FOLLOW-UP ACTION REQUESTS (REQUIREMENTS 4, 5, 6) ----
  getFollowUpRequests(): FollowUpRequest[] {
    return getFromStorage<FollowUpRequest[]>(STORAGE_KEYS.FOLLOW_UPS, []);
  },

  getFollowUpRequestsForUser(user: User): FollowUpRequest[] {
    const all = this.getFollowUpRequests();
    if (user.role === 'PRINCIPAL') {
      return all;
    }
    if (user.role === 'HOD') {
      // HOD sees requests sent by them, sent to them, or in their department
      return all.filter(r => r.senderId === user.id || r.recipientId === user.id || r.departmentId === user.departmentId);
    }
    if (user.role === 'ADVISOR') {
      // Advisor sees requests assigned to them
      return all.filter(r => r.recipientId === user.id);
    }
    return [];
  },

  createFollowUpRequest(data: {
    caseId: string;
    caseType: 'GRIEVANCE' | 'SUGGESTION';
    caseTitle: string;
    sender: User;
    recipientId: string;
    pendingIssue: string;
    responseDeadline: string;
    requestedAction: string;
  }): FollowUpRequest {
    const recipient = this.getUserById(data.recipientId);
    if (!recipient) throw new Error('Recipient user not found');

    const requests = this.getFollowUpRequests();
    const newReq: FollowUpRequest = {
      id: 'flw_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      caseId: data.caseId,
      caseType: data.caseType,
      caseTitle: data.caseTitle,
      senderId: data.sender.id,
      senderName: data.sender.name,
      senderRole: data.sender.role as 'HOD' | 'PRINCIPAL',
      recipientId: recipient.id,
      recipientName: recipient.name,
      recipientRole: recipient.role as 'ADVISOR' | 'HOD',
      departmentId: data.sender.departmentId || recipient.departmentId || 'dep_gen',
      departmentName: data.sender.departmentName || recipient.departmentName || 'Department',
      pendingIssue: data.pendingIssue.trim(),
      responseDeadline: data.responseDeadline,
      requestedAction: data.requestedAction.trim(),
      status: 'PENDING_EXPLANATION',
      createdAt: new Date().toISOString()
    };

    requests.unshift(newReq);
    saveToStorage(STORAGE_KEYS.FOLLOW_UPS, requests);

    // If it's a grievance, append to timeline
    if (data.caseType === 'GRIEVANCE') {
      const grievances = this.getGrievances();
      const g = grievances.find(item => item.caseId === data.caseId || item.id === data.caseId);
      if (g) {
        g.timeline.push({
          id: 'tml_' + Date.now(),
          actorId: data.sender.id,
          actorName: data.sender.name,
          actorRole: data.sender.role,
          action: `Follow-up Directed to ${recipient.name} (${recipient.role})`,
          comment: `Deadline: ${data.responseDeadline}. Directive: ${data.requestedAction}`,
          timestamp: new Date().toISOString()
        });
        saveToStorage(STORAGE_KEYS.GRIEVANCES, grievances);
      }
    }

    // Trigger real notification for recipient
    this.createNotification(
      recipient.id,
      `Action Directive: ${data.caseId} from ${data.sender.name} (${data.sender.role})`,
      `Pending issue: ${data.pendingIssue}. Response Deadline: ${data.responseDeadline}. Action required: ${data.requestedAction}`,
      'FOLLOW_UP',
      { module: 'follow_ups', id: newReq.id },
      data.sender.name,
      data.sender.role
    );

    this.logAudit(
      data.sender.id,
      data.sender.name,
      data.sender.role,
      'FOLLOW_UP_DIRECTIVE_SENT',
      data.caseType,
      `Directive on ${data.caseId} sent to ${recipient.name} (Deadline: ${data.responseDeadline})`
    );

    return newReq;
  },

  respondToFollowUpRequest(
    requestId: string,
    responder: User,
    data: {
      delayReason?: string;
      statusUpdate?: string;
      correctiveActionPlan?: string;
      expectedCompletionDate?: string;
    }
  ): FollowUpRequest {
    const requests = this.getFollowUpRequests();
    const index = requests.findIndex(r => r.id === requestId);
    if (index === -1) throw new Error('Follow-up request not found');

    const req = requests[index];
    req.delayReason = data.delayReason?.trim() || 'Reason not provided';
    req.statusUpdate = data.statusUpdate?.trim() || 'Awaiting further review';
    req.correctiveActionPlan = data.correctiveActionPlan?.trim() || 'Action in progress';
    req.expectedCompletionDate = data.expectedCompletionDate || new Date().toISOString().split('T')[0];
    req.status = 'REPLIED';
    req.repliedAt = new Date().toISOString();

    saveToStorage(STORAGE_KEYS.FOLLOW_UPS, requests);

    // Update case timeline
    if (req.caseType === 'GRIEVANCE') {
      const grievances = this.getGrievances();
      const g = grievances.find(item => item.caseId === req.caseId || item.id === req.caseId);
      if (g) {
        g.timeline.push({
          id: 'tml_' + Date.now(),
          actorId: responder.id,
          actorName: responder.name,
          actorRole: responder.role,
          action: `Action Plan Submitted by ${responder.name}`,
          comment: `Status: ${req.statusUpdate}. Delay reason: ${req.delayReason}. Plan: ${req.correctiveActionPlan} (Target: ${req.expectedCompletionDate})`,
          timestamp: new Date().toISOString()
        });
        saveToStorage(STORAGE_KEYS.GRIEVANCES, grievances);
      }
    }

    // Notify sender (HOD or Principal)
    this.createNotification(
      req.senderId,
      `Action Response: ${req.caseId} by ${responder.name}`,
      `${responder.name} submitted corrective action plan. Target completion: ${req.expectedCompletionDate}`,
      'FOLLOW_UP',
      { module: 'follow_ups', id: req.id },
      responder.name,
      responder.role
    );

    this.logAudit(
      responder.id,
      responder.name,
      responder.role,
      'FOLLOW_UP_RESPONSE_SUBMITTED',
      req.caseType,
      `Response submitted for ${req.caseId}`
    );

    return req;
  },

  // ---- SUGGESTIONS & PROPOSALS ----
  getSuggestions(): Suggestion[] {
    return getFromStorage<Suggestion[]>(STORAGE_KEYS.SUGGESTIONS, []);
  },

  getSuggestionsForUser(user: User): Suggestion[] {
    const all = this.getSuggestions();
    if (user.role === 'STUDENT') {
      return all.filter(s => s.studentId === user.id);
    }
    if (user.role === 'ADVISOR' || user.role === 'HOD') {
      return all.filter(s => s.departmentId === user.departmentId);
    }
    if (user.role === 'PRINCIPAL') {
      return all;
    }
    return [];
  },

  createSuggestion(student: User, data: { title: string; description: string; category: Suggestion['category']; isAnonymous: boolean }): Suggestion {
    const all = this.getSuggestions();
    const count = all.length + 1;
    const refNo = `SUG-${new Date().getFullYear()}-${count.toString().padStart(4, '0')}`;

    const newSuggestion: Suggestion = {
      id: 'sug_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      referenceNo: refNo,
      title: data.title.trim(),
      description: data.description.trim(),
      category: data.category,
      status: 'SUBMITTED',
      isAnonymous: data.isAnonymous,
      studentId: student.id,
      studentName: data.isAnonymous ? undefined : student.name,
      departmentId: student.departmentId || 'DEP_GEN',
      departmentName: student.departmentName || 'General Campus',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    all.unshift(newSuggestion);
    saveToStorage(STORAGE_KEYS.SUGGESTIONS, all);
    this.logAudit(student.id, student.name, student.role, 'SUGGESTION_SUBMITTED', 'SUGGESTIONS', `Ref: ${refNo}`);
    return newSuggestion;
  },

  updateSuggestionStatus(
    suggestionId: string,
    reviewer: User,
    status: SuggestionStatus,
    officialResponse?: string,
    internalNotes?: string
  ): Suggestion | null {
    const all = this.getSuggestions();
    const index = all.findIndex(s => s.id === suggestionId);
    if (index === -1) return null;

    all[index] = {
      ...all[index],
      status,
      reviewerId: reviewer.id,
      reviewerName: reviewer.name,
      reviewerRole: reviewer.role,
      officialResponse: officialResponse !== undefined ? officialResponse : all[index].officialResponse,
      internalNotes: internalNotes !== undefined ? internalNotes : all[index].internalNotes,
      updatedAt: new Date().toISOString()
    };

    saveToStorage(STORAGE_KEYS.SUGGESTIONS, all);

    this.createNotification(
      all[index].studentId,
      `Suggestion ${all[index].referenceNo} Updated`,
      `Status changed to ${status.replace('_', ' ')} by ${reviewer.name}.`,
      'SUGGESTION',
      { module: 'suggestions', id: suggestionId },
      reviewer.name,
      reviewer.role
    );

    return all[index];
  },

  // ---- GRIEVANCES & ESCALATIONS ----
  getGrievances(): Grievance[] {
    const grievances = getFromStorage<Grievance[]>(STORAGE_KEYS.GRIEVANCES, []);
    const now = Date.now();
    return grievances.map(g => ({
      ...g,
      isOverdue: g.status !== 'RESOLVED' && g.status !== 'REJECTED' && new Date(g.dueDate).getTime() < now
    }));
  },

  getGrievancesForUser(user: User): Grievance[] {
    const all = this.getGrievances();
    if (user.role === 'STUDENT') {
      return all.filter(g => g.studentId === user.id);
    }
    if (user.role === 'ADVISOR') {
      return all.filter(g => g.classId === user.classId || g.assignedAdvisorId === user.id);
    }
    if (user.role === 'HOD') {
      // HOD manages ONLY their assigned department records (Requirement 3 & 8)
      return all.filter(g => g.departmentId === user.departmentId);
    }
    if (user.role === 'PRINCIPAL') {
      // Principal oversees institution-wide
      return all;
    }
    return [];
  },

  createGrievance(student: User, data: { title: string; description: string; category: Grievance['category']; priority: Grievance['priority'] }): Grievance {
    const all = this.getGrievances();
    const count = all.length + 1;
    const caseId = `GRV-${new Date().getFullYear()}-${count.toString().padStart(4, '0')}`;
    const daysToAdd = data.priority === 'CRITICAL' ? 2 : data.priority === 'HIGH' ? 4 : 7;
    const dueDate = new Date(Date.now() + daysToAdd * 24 * 60 * 60 * 1000).toISOString();

    const classAdvisor = this.getUsers().find(u => u.role === 'ADVISOR' && u.classId === student.classId);

    const newGrievance: Grievance = {
      id: 'grv_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      caseId,
      title: data.title.trim(),
      description: data.description.trim(),
      category: data.category,
      priority: data.priority,
      status: 'ADVISOR_REVIEW',
      studentId: student.id,
      studentName: student.name,
      departmentId: student.departmentId || 'DEP_GEN',
      departmentName: student.departmentName || 'General Campus',
      classId: student.classId || 'CLS_GEN',
      className: student.className || 'General Section',
      currentAssigneeRole: 'ADVISOR',
      assignedAdvisorId: classAdvisor?.id,
      assignedAdvisorName: classAdvisor?.name,
      dueDate,
      isOverdue: false,
      timeline: [
        {
          id: 'tml_1',
          actorId: student.id,
          actorName: student.name,
          actorRole: student.role,
          action: 'Case Filed by Student',
          comment: 'Initial confidential grievance petition.',
          timestamp: new Date().toISOString()
        }
      ],
      createdAt: new Date().toISOString()
    };

    all.unshift(newGrievance);
    saveToStorage(STORAGE_KEYS.GRIEVANCES, all);

    if (classAdvisor) {
      this.createNotification(
        classAdvisor.id,
        `New Confidential Grievance: ${caseId}`,
        `Student filed petition ${caseId} [${data.priority}]. Immediate review required.`,
        'GRIEVANCE',
        { module: 'grievances', id: newGrievance.id },
        student.name,
        student.role
      );
    }

    return newGrievance;
  },

  escalateGrievance(caseIdString: string, actor: User, nextTarget: 'HOD' | 'PRINCIPAL', reason: string): Grievance | null {
    const all = this.getGrievances();
    const item = all.find(g => g.id === caseIdString || g.caseId === caseIdString);
    if (!item) return null;

    let newStatus: GrievanceStatus = item.status;
    let newAssigneeRole: UserRole = item.currentAssigneeRole;

    if (nextTarget === 'HOD') {
      newStatus = 'ESCALATED_HOD';
      newAssigneeRole = 'HOD';
    } else if (nextTarget === 'PRINCIPAL') {
      newStatus = 'ESCALATED_PRINCIPAL';
      newAssigneeRole = 'PRINCIPAL';
    }

    item.status = newStatus;
    item.currentAssigneeRole = newAssigneeRole;
    item.escalationReason = reason;
    item.timeline.push({
      id: 'tml_' + Date.now(),
      actorId: actor.id,
      actorName: actor.name,
      actorRole: actor.role,
      action: `Escalated to ${nextTarget}`,
      comment: reason,
      timestamp: new Date().toISOString()
    });

    saveToStorage(STORAGE_KEYS.GRIEVANCES, all);

    const recipientUsers = this.getUsers().filter(u => {
      if (nextTarget === 'HOD') return u.role === 'HOD' && u.departmentId === item.departmentId;
      if (nextTarget === 'PRINCIPAL') return u.role === 'PRINCIPAL';
      return false;
    });

    recipientUsers.forEach(u => {
      this.createNotification(
        u.id,
        `Case Escalation: ${item.caseId}`,
        `${actor.name} escalated case ${item.caseId} to you: ${reason}`,
        'GRIEVANCE',
        { module: 'grievances', id: item.id },
        actor.name,
        actor.role
      );
    });

    return item;
  },

  returnGrievanceToHod(caseIdString: string, principal: User, instruction: string): Grievance | null {
    const all = this.getGrievances();
    const item = all.find(g => g.id === caseIdString || g.caseId === caseIdString);
    if (!item) return null;

    item.status = 'ESCALATED_HOD';
    item.currentAssigneeRole = 'HOD';
    item.timeline.push({
      id: 'tml_' + Date.now(),
      actorId: principal.id,
      actorName: principal.name,
      actorRole: 'PRINCIPAL',
      action: 'Returned to HOD for Reinvestigation',
      comment: instruction,
      timestamp: new Date().toISOString()
    });

    saveToStorage(STORAGE_KEYS.GRIEVANCES, all);

    // Notify HOD
    const hod = this.getUsers().find(u => u.role === 'HOD' && u.departmentId === item.departmentId);
    if (hod) {
      this.createNotification(
        hod.id,
        `Case ${item.caseId} Returned by Principal`,
        `Directives for further inquiry: ${instruction}`,
        'GRIEVANCE',
        { module: 'grievances', id: item.id },
        principal.name,
        principal.role
      );
    }

    return item;
  },

  resolveGrievance(caseIdString: string, resolver: User, resolutionSummary: string, internalNotes?: string): Grievance | null {
    const all = this.getGrievances();
    const item = all.find(g => g.id === caseIdString || g.caseId === caseIdString);
    if (!item) return null;

    item.status = 'RESOLVED';
    item.resolutionSummary = resolutionSummary;
    if (internalNotes) item.internalNotes = internalNotes;
    item.resolvedAt = new Date().toISOString();
    item.timeline.push({
      id: 'tml_' + Date.now(),
      actorId: resolver.id,
      actorName: resolver.name,
      actorRole: resolver.role,
      action: 'Case Formally Resolved & Closed',
      comment: resolutionSummary,
      timestamp: new Date().toISOString()
    });

    saveToStorage(STORAGE_KEYS.GRIEVANCES, all);

    this.createNotification(
      item.studentId,
      `Grievance Resolved: ${item.caseId}`,
      `Your case has been resolved by ${resolver.name}. Outcome: ${resolutionSummary}`,
      'GRIEVANCE',
      { module: 'grievances', id: item.id },
      resolver.name,
      resolver.role
    );

    return item;
  },

  addGrievanceInternalNote(caseIdString: string, actor: User, note: string): Grievance | null {
    const all = this.getGrievances();
    const item = all.find(g => g.id === caseIdString || g.caseId === caseIdString);
    if (!item) return null;

    const existing = item.internalNotes ? item.internalNotes + '\n' : '';
    item.internalNotes = `${existing}[${new Date().toLocaleDateString()} - ${actor.name} (${actor.role})]: ${note}`;

    saveToStorage(STORAGE_KEYS.GRIEVANCES, all);
    return item;
  },

  // ---- INITIALIZATION OF 4 EXACT ROLES (STUDENT, ADVISOR, HOD, PRINCIPAL) ----
  isSystemInitialized(): boolean {
    return localStorage.getItem(STORAGE_KEYS.SYSTEM_SEEDED) === 'true';
  },

  async initializeVerifiedCollegiateStructure(): Promise<void> {
    const departments = this.getDefaultDepartments();
    saveToStorage(STORAGE_KEYS.DEPARTMENTS, departments);

    const classes: CollegeClass[] = [
      { id: 'cls_cse_a', departmentId: 'dep_cse', name: 'CSE - Final Year (Sec A)', semester: 7, advisorName: 'Prof. Sandhya Menon' },
      { id: 'cls_cse_b', departmentId: 'dep_cse', name: 'CSE - Third Year (Sec B)', semester: 5, advisorName: 'Dr. K. Narayanan' },
      { id: 'cls_ece_a', departmentId: 'dep_ece', name: 'ECE - Final Year (Sec A)', semester: 7, advisorName: 'Prof. S. Venkatesh' },
      { id: 'cls_mech_a', departmentId: 'dep_mech', name: 'MECH - Third Year', semester: 5, advisorName: 'Prof. D. Rajasekar' },
    ];
    saveToStorage(STORAGE_KEYS.CLASSES, classes);

    const defaultPassword = 'Campus@2026';
    const salt1 = await generateSalt();
    const hash1 = await hashPassword(defaultPassword, salt1);

    const salt2 = await generateSalt();
    const hash2 = await hashPassword(defaultPassword, salt2);

    const salt3 = await generateSalt();
    const hash3 = await hashPassword(defaultPassword, salt3);

    const salt4 = await generateSalt();
    const hash4 = await hashPassword(defaultPassword, salt4);

    // EXACT 4 ROLES: STUDENT, ADVISOR, HOD, PRINCIPAL (No Administration portal accounts!)
    const defaultUsers: User[] = [
      {
        id: 'usr_student_1',
        name: 'Kavya Subramanian',
        email: 'kavya.cse@campusconnect.edu',
        role: 'STUDENT',
        rollNumber: '21CS1042',
        course: 'B.Tech',
        academicBatch: '2023–2027',
        departmentId: 'dep_cse',
        departmentName: 'Computer Science & Engineering',
        classId: 'cls_cse_a',
        className: 'CSE - Final Year (Sec A)',
        year: '4th Year',
        semester: 7,
        passwordHash: hash1,
        salt: salt1,
        isActive: true,
        createdAt: new Date().toISOString()
      },
      {
        id: 'usr_advisor_1',
        name: 'Prof. Sandhya Menon',
        email: 'advisor.csea@campusconnect.edu',
        role: 'ADVISOR',
        employeeId: 'EMP-CSE-ADV1',
        course: 'B.Tech',
        departmentId: 'dep_cse',
        departmentName: 'Computer Science & Engineering',
        classId: 'cls_cse_a',
        className: 'CSE - Final Year (Sec A)',
        passwordHash: hash2,
        salt: salt2,
        isActive: true,
        createdAt: new Date().toISOString()
      },
      {
        id: 'usr_hod_cse_1',
        name: 'Dr. Aruna Ramanathan',
        email: 'hod.cse@campusconnect.edu',
        role: 'HOD',
        employeeId: 'EMP-CSE-HOD',
        departmentId: 'dep_cse',
        departmentName: 'Computer Science & Engineering',
        passwordHash: hash3,
        salt: salt3,
        isActive: true,
        createdAt: new Date().toISOString()
      },
      {
        id: 'usr_principal_1',
        name: 'Dr. Elizabeth Sterling',
        email: 'principal@campusconnect.edu',
        role: 'PRINCIPAL',
        employeeId: 'EMP-PRIN-001',
        passwordHash: hash4,
        salt: salt4,
        isActive: true,
        createdAt: new Date().toISOString()
      }
    ];

    saveToStorage(STORAGE_KEYS.USERS, defaultUsers);
    localStorage.setItem(STORAGE_KEYS.SYSTEM_SEEDED, 'true');
  },

  resetAllDataClean(): void {
    Object.values(STORAGE_KEYS).forEach(k => localStorage.removeItem(k));
    this.initializeVerifiedCollegiateStructure();
  }
};
