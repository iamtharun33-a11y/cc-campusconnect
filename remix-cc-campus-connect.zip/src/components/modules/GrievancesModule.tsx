import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { storageService } from '../../services/storage';
import { Grievance, GrievanceCategory, GrievancePriority } from '../../types';
import { EmptyState } from '../common/EmptyState';
import {
  AlertCircle,
  Plus,
  ShieldAlert,
  ArrowUpRight,
  CheckCircle,
  FileText,
  Clock,
  User as UserIcon,
  MessageSquare
} from 'lucide-react';

export const GrievancesModule: React.FC = () => {
  const { currentUser } = useAuth();
  const [selectedCaseId, setSelectedCaseId] = useState<string | null>(null);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showEscalateModal, setShowEscalateModal] = useState(false);
  const [showResolveModal, setShowResolveModal] = useState(false);

  // Form states
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<GrievanceCategory>('ACADEMIC');
  const [priority, setPriority] = useState<GrievancePriority>('NORMAL');

  // Escalation & Resolution states
  const [escalateTarget, setEscalateTarget] = useState<'HOD' | 'PRINCIPAL'>('HOD');
  const [escalateReason, setEscalateReason] = useState('');
  const [resolutionSummary, setResolutionSummary] = useState('');
  const [internalNoteInput, setInternalNoteInput] = useState('');

  if (!currentUser) return null;

  const grievances = storageService.getGrievancesForUser(currentUser);
  const activeCase = grievances.find(g => g.id === selectedCaseId || g.caseId === selectedCaseId) || grievances[0];

  const handleCreateGrievance = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !description.trim()) return;

    const newCase = storageService.createGrievance(currentUser, {
      title,
      description,
      category,
      priority
    });

    setTitle('');
    setDescription('');
    setCategory('ACADEMIC');
    setPriority('NORMAL');
    setShowCreateModal(false);
    setSelectedCaseId(newCase.id);
  };

  const handleEscalate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeCase || !escalateReason.trim()) return;

    storageService.escalateGrievance(activeCase.id, currentUser, escalateTarget, escalateReason);
    setEscalateReason('');
    setShowEscalateModal(false);
  };

  const handleResolve = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeCase || !resolutionSummary.trim()) return;

    storageService.resolveGrievance(activeCase.id, currentUser, resolutionSummary);
    setResolutionSummary('');
    setShowResolveModal(false);
  };

  const handleAddNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeCase || !internalNoteInput.trim()) return;

    storageService.addGrievanceInternalNote(activeCase.id, currentUser, internalNoteInput);
    setInternalNoteInput('');
  };

  const canEscalateToHod = currentUser.role === 'ADVISOR' && activeCase?.status === 'ADVISOR_REVIEW';
  const canEscalateToPrincipal = currentUser.role === 'HOD' && (activeCase?.status === 'ADVISOR_REVIEW' || activeCase?.status === 'ESCALATED_HOD');
  const canResolve = currentUser.role !== 'STUDENT' && activeCase?.status !== 'RESOLVED' && activeCase?.status !== 'REJECTED';

  return (
    <div className="space-y-4">
      {/* Top Banner */}
      <div className="bg-white p-4 rounded-lg border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">Grievance Redressal & Escalation</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Strictly confidential collegiate disputes and student issues tracked through tiered administrative review.
          </p>
        </div>

        {currentUser.role === 'STUDENT' && (
          <button
            onClick={() => setShowCreateModal(true)}
            className="px-3.5 py-2 text-xs font-bold text-white bg-red-600 hover:bg-red-700 rounded-md transition-colors flex items-center gap-1.5 shadow-xs"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>File Confidential Grievance</span>
          </button>
        )}
      </div>

      {grievances.length === 0 ? (
        <EmptyState
          icon={AlertCircle}
          title="No Grievances on File"
          description={
            currentUser.role === 'STUDENT'
              ? 'You have not submitted any grievance petitions. If you encounter collegiate issues, file a confidential petition above.'
              : 'There are no active grievance cases pending review within your administrative purview.'
          }
          actionLabel={currentUser.role === 'STUDENT' ? 'File New Grievance' : undefined}
          onAction={currentUser.role === 'STUDENT' ? () => setShowCreateModal(true) : undefined}
        />
      ) : (
        <div className="bg-white rounded-lg border border-slate-200 min-h-[620px] flex flex-col md:flex-row overflow-hidden">
          {/* Left Cases List */}
          <div className="w-full md:w-80 border-r border-slate-200 flex flex-col bg-slate-50/40">
            <div className="p-3 border-b border-slate-200 font-bold text-xs text-slate-800 uppercase tracking-wider bg-white flex items-center justify-between">
              <span>Cases on File ({grievances.length})</span>
              <span className="text-[10px] text-slate-400 font-mono">Confidential</span>
            </div>

            <div className="flex-1 overflow-y-auto divide-y divide-slate-100">
              {grievances.map((g) => {
                const isSelected = activeCase?.id === g.id;
                return (
                  <button
                    key={g.id}
                    onClick={() => setSelectedCaseId(g.id)}
                    className={`w-full p-3 text-left transition-colors flex flex-col ${
                      isSelected ? 'bg-white border-l-2 border-red-600' : 'hover:bg-slate-100/60'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-1 text-[11px] font-mono">
                      <span className="font-bold text-slate-900">{g.caseId}</span>
                      <span className={`${
                        g.priority === 'CRITICAL' ? 'text-red-700 font-bold' : g.priority === 'HIGH' ? 'text-amber-700 font-bold' : 'text-slate-500'
                      }`}>
                        {g.priority}
                      </span>
                    </div>

                    <span className="text-xs font-semibold text-slate-800 truncate mt-1">{g.title}</span>

                    <div className="flex items-center justify-between text-[11px] text-slate-500 mt-1 font-mono">
                      <span>Status: {g.status.replace('_', ' ')}</span>
                      {g.isOverdue && (
                        <span className="text-red-600 font-bold">OVERDUE</span>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Right Case Detail & Escalation History */}
          <div className="flex-1 flex flex-col bg-white overflow-y-auto">
            {activeCase ? (
              <div className="p-6 space-y-6">
                {/* Case Header */}
                <div className="flex flex-wrap items-start justify-between gap-3 border-b border-slate-200 pb-4">
                  <div>
                    <div className="flex items-center gap-2 text-xs text-slate-500 font-mono">
                      <span className="font-bold text-slate-900">{activeCase.caseId}</span>
                      <span aria-hidden="true">·</span>
                      <span>Filed: {activeCase.createdAt.split('T')[0]}</span>
                      <span aria-hidden="true">·</span>
                      <span>Due: {activeCase.dueDate.split('T')[0]}</span>
                    </div>
                    <h2 className="text-base font-bold text-slate-900 mt-1">{activeCase.title}</h2>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Student: <strong>{activeCase.studentName}</strong> · Dept: {activeCase.departmentName} ({activeCase.className})
                    </p>
                  </div>

                  {/* Actions for Faculty / Heads */}
                  <div className="flex items-center gap-2">
                    {canEscalateToHod && (
                      <button
                        onClick={() => {
                          setEscalateTarget('HOD');
                          setShowEscalateModal(true);
                        }}
                        className="px-3 py-1.5 text-xs font-semibold text-amber-800 bg-amber-50 hover:bg-amber-100 border border-amber-200 rounded-md transition-colors flex items-center gap-1"
                      >
                        <ArrowUpRight className="w-3.5 h-3.5 text-amber-600" />
                        <span>Escalate to HOD</span>
                      </button>
                    )}

                    {canEscalateToPrincipal && (
                      <button
                        onClick={() => {
                          setEscalateTarget('PRINCIPAL');
                          setShowEscalateModal(true);
                        }}
                        className="px-3 py-1.5 text-xs font-semibold text-red-800 bg-red-50 hover:bg-red-100 border border-red-200 rounded-md transition-colors flex items-center gap-1"
                      >
                        <ShieldAlert className="w-3.5 h-3.5 text-red-600" />
                        <span>Escalate to Principal</span>
                      </button>
                    )}

                    {canResolve && (
                      <button
                        onClick={() => setShowResolveModal(true)}
                        className="px-3.5 py-1.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-md transition-colors flex items-center gap-1 shadow-xs"
                      >
                        <CheckCircle className="w-3.5 h-3.5" />
                        <span>Resolve Case</span>
                      </button>
                    )}
                  </div>
                </div>

                {/* Case Description */}
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-1">
                    Grievance Statement
                  </h4>
                  <div className="p-3.5 bg-slate-50 rounded-md border border-slate-200 text-xs text-slate-800 leading-relaxed whitespace-pre-line">
                    {activeCase.description}
                  </div>
                </div>

                {/* Resolution Summary (if resolved) */}
                {activeCase.resolutionSummary && (
                  <div className="p-4 bg-emerald-50/70 border border-emerald-200 rounded-md">
                    <div className="flex items-center gap-2 text-emerald-800 font-bold text-xs">
                      <CheckCircle className="w-4 h-4 text-emerald-600" />
                      <span>Formal Institutional Resolution</span>
                    </div>
                    <p className="text-xs text-emerald-900 mt-1.5 leading-relaxed">
                      {activeCase.resolutionSummary}
                    </p>
                    <div className="text-[10px] text-emerald-700 font-mono mt-2">
                      Resolved on: {activeCase.resolvedAt?.split('T')[0]}
                    </div>
                  </div>
                )}

                {/* Timeline / Audit Trail */}
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                    Case Lifecycle & Escalation History
                  </h4>
                  <div className="border border-slate-200 rounded-md divide-y divide-slate-100">
                    {activeCase.timeline.map((step) => (
                      <div key={step.id} className="p-3 text-xs flex items-start justify-between gap-3">
                        <div>
                          <div className="font-semibold text-slate-900 flex items-center gap-1.5">
                            <span>{step.action}</span>
                            <span className="text-[10px] font-mono text-slate-400">by {step.actorName} ({step.actorRole})</span>
                          </div>
                          {step.comment && (
                            <p className="text-slate-600 mt-1">{step.comment}</p>
                          )}
                        </div>
                        <span className="text-[11px] text-slate-400 font-mono shrink-0">
                          {new Date(step.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Internal Notes (for faculty/HOD/Principal only - requirement 168) */}
                {currentUser.role !== 'STUDENT' && (
                  <div className="pt-4 border-t border-slate-200">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-slate-600 mb-2 flex items-center gap-1.5">
                      <FileText className="w-3.5 h-3.5 text-slate-400" />
                      <span>Confidential Internal Notes (Staff-Only)</span>
                    </h4>
                    {activeCase.internalNotes && (
                      <div className="p-3 bg-amber-50/40 border border-amber-200 rounded-md text-xs text-amber-900 whitespace-pre-line mb-3 font-mono">
                        {activeCase.internalNotes}
                      </div>
                    )}
                    <form onSubmit={handleAddNote} className="flex gap-2">
                      <input
                        type="text"
                        value={internalNoteInput}
                        onChange={(e) => setInternalNoteInput(e.target.value)}
                        placeholder="Append private case deliberation note..."
                        className="flex-1 text-xs p-2 rounded-md border border-slate-300 focus:border-red-600 focus:outline-hidden"
                      />
                      <button
                        type="submit"
                        disabled={!internalNoteInput.trim()}
                        className="px-3 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors"
                      >
                        Add Note
                      </button>
                    </form>
                  </div>
                )}
              </div>
            ) : null}
          </div>
        </div>
      )}

      {/* New Grievance Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="w-full max-w-lg bg-white rounded-lg shadow-xl border border-slate-200 p-6">
            <h3 className="text-base font-bold text-slate-900">File Confidential Grievance</h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Strictly protected submission. Case routed directly to your assigned Class Advisor.
            </p>

            <form onSubmit={handleCreateGrievance} className="mt-4 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Grievance Title *</label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Concise summary of collegiate issue"
                  className="w-full text-xs p-2.5 rounded-md border border-slate-300 focus:border-red-600 focus:outline-hidden"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Category</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as GrievanceCategory)}
                    className="w-full text-xs p-2 rounded-md border border-slate-300 bg-white"
                  >
                    <option value="ACADEMIC">Academic / Evaluation</option>
                    <option value="FACULTY">Faculty Interaction</option>
                    <option value="DISCIPLINARY">Disciplinary</option>
                    <option value="HOSTEL">Hostel & Mess</option>
                    <option value="ADMINISTRATION">Administrative / Fees</option>
                    <option value="HARASSMENT_RAGGING">Zero-Tolerance Harassment</option>
                    <option value="OTHER">Other</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Priority</label>
                  <select
                    value={priority}
                    onChange={(e) => setPriority(e.target.value as GrievancePriority)}
                    className="w-full text-xs p-2 rounded-md border border-slate-300 bg-white"
                  >
                    <option value="NORMAL">Normal (7 Day SLA)</option>
                    <option value="HIGH">High (4 Day SLA)</option>
                    <option value="CRITICAL">Critical (2 Day SLA)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Detailed Description *</label>
                <textarea
                  required
                  rows={4}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Provide precise dates, details, and affected parties for impartial evaluation..."
                  className="w-full text-xs p-2.5 rounded-md border border-slate-300 focus:border-red-600 focus:outline-hidden"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-3.5 py-2 text-xs font-medium text-slate-600 hover:text-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-bold text-white bg-red-600 hover:bg-red-700 rounded-md transition-colors"
                >
                  Submit Grievance
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Escalation Modal */}
      {showEscalateModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-white rounded-lg shadow-xl border border-slate-200 p-6">
            <h3 className="text-base font-bold text-slate-900">Escalate Case {activeCase?.caseId}</h3>
            <p className="text-xs text-slate-500 mt-0.5">Transfer case authority to higher institutional governance tier.</p>

            <form onSubmit={handleEscalate} className="mt-4 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Escalate To</label>
                <div className="p-2 bg-slate-100 rounded text-xs font-bold text-slate-800">
                  {escalateTarget === 'HOD' ? 'Department Head (HOD)' : 'Executive Principal'}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Reason for Escalation *</label>
                <textarea
                  required
                  rows={3}
                  value={escalateReason}
                  onChange={(e) => setEscalateReason(e.target.value)}
                  placeholder="Explain why local resolution could not be achieved..."
                  className="w-full text-xs p-2.5 rounded-md border border-slate-300 focus:border-red-600 focus:outline-hidden"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setShowEscalateModal(false)}
                  className="px-3.5 py-2 text-xs font-medium text-slate-600 hover:text-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 rounded-md transition-colors"
                >
                  Confirm Escalation
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Resolution Modal */}
      {showResolveModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-white rounded-lg shadow-xl border border-slate-200 p-6">
            <h3 className="text-base font-bold text-slate-900">Formally Resolve Grievance</h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Recorded outcome will be published to student and logged in institutional audit registry.
            </p>

            <form onSubmit={handleResolve} className="mt-4 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Official Resolution Summary *</label>
                <textarea
                  required
                  rows={4}
                  value={resolutionSummary}
                  onChange={(e) => setResolutionSummary(e.target.value)}
                  placeholder="State the findings, corrective action taken, and closure statement..."
                  className="w-full text-xs p-2.5 rounded-md border border-slate-300 focus:border-emerald-600 focus:outline-hidden"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setShowResolveModal(false)}
                  className="px-3.5 py-2 text-xs font-medium text-slate-600 hover:text-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-md transition-colors"
                >
                  Close & Resolve Case
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
