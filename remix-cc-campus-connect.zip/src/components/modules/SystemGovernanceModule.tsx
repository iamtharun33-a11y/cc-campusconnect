import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { storageService } from '../../services/storage';
import { User, UserRole } from '../../types';
import { ShieldCheck, Database, RefreshCw, UserPlus, FileText, CheckCircle2, AlertTriangle } from 'lucide-react';

export const SystemGovernanceModule: React.FC = () => {
  const { currentUser, refreshCurrentUser } = useAuth();
  const [showAddUserModal, setShowAddUserModal] = useState(false);
  const [userList, setUserList] = useState<User[]>(storageService.getUsers());

  // Form states
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [role, setRole] = useState<UserRole>('ADVISOR');
  const [employeeId, setEmployeeId] = useState('');
  const [password, setPassword] = useState('Campus@2026');
  const [selectedDeptId, setSelectedDeptId] = useState('dep_cse');
  const [selectedClassId, setSelectedClassId] = useState('cls_cse_a');

  const auditLogs = storageService.getAuditLogs();
  const departments = storageService.getDepartments();
  const classes = storageService.getClasses();

  const handleProvisionUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim()) return;

    const dept = departments.find(d => d.id === selectedDeptId);
    const cls = classes.find(c => c.id === selectedClassId);

    try {
      await storageService.createUser({
        name: name.trim(),
        email: email.trim(),
        role,
        password: password || 'Campus@2026',
        employeeId: employeeId.trim() || `EMP-${Date.now().toString().slice(-4)}`,
        departmentId: role !== 'PRINCIPAL' ? dept?.id : undefined,
        departmentName: role !== 'PRINCIPAL' ? dept?.name : undefined,
        classId: role === 'ADVISOR' ? cls?.id : undefined,
        className: role === 'ADVISOR' ? cls?.name : undefined,
        isActive: true
      });

      setUserList(storageService.getUsers());
      setName('');
      setEmail('');
      setEmployeeId('');
      setShowAddUserModal(false);
    } catch (err: any) {
      alert(err.message || 'Provisioning failed');
    }
  };

  const handleResetData = async () => {
    if (confirm('Are you sure you want to reset and re-initialize institutional records to a clean verified state?')) {
      storageService.resetAllDataClean();
      refreshCurrentUser();
      window.location.reload();
    }
  };

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="bg-white p-5 rounded-lg border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-slate-900 tracking-tight">Institutional Governance & Audits</h1>
            <span className="px-2 py-0.5 text-[11px] font-bold bg-emerald-50 text-emerald-800 rounded border border-emerald-200 flex items-center gap-1 font-mono">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              RBAC VERIFIED
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Cryptographic audit registry, security policy enforcement, and certified faculty role provisioning.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowAddUserModal(true)}
            className="px-3.5 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-md transition-colors flex items-center gap-1.5 shadow-xs"
          >
            <UserPlus className="w-3.5 h-3.5" />
            <span>Provision Staff Account</span>
          </button>

          <button
            onClick={handleResetData}
            className="px-3 py-2 text-xs font-semibold text-red-700 bg-red-50 hover:bg-red-100 border border-red-200 rounded-md transition-colors flex items-center gap-1.5"
            title="Re-initialize collegiate structure"
          >
            <RefreshCw className="w-3.5 h-3.5 text-red-600" />
            <span>Reset Database</span>
          </button>
        </div>
      </div>

      {/* Compliance Checklist */}
      <div className="bg-white p-5 rounded-lg border border-slate-200">
        <h3 className="text-sm font-bold text-slate-900 mb-3">Institutional Policy & Compliance Matrix</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 text-xs">
          <div className="p-3 bg-slate-50 rounded-md border border-slate-200 flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-slate-800">Role-Based Access Control</p>
              <p className="text-[11px] text-slate-500 mt-0.5">Strict multi-tier enforcement for Student, Advisor, HOD, and Principal.</p>
            </div>
          </div>

          <div className="p-3 bg-slate-50 rounded-md border border-slate-200 flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-slate-800">Private Message Isolation</p>
              <p className="text-[11px] text-slate-500 mt-0.5">Direct chat records restricted to authorized participants only.</p>
            </div>
          </div>

          <div className="p-3 bg-slate-50 rounded-md border border-slate-200 flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-slate-800">Protected Campus Photo</p>
              <p className="text-[11px] text-slate-500 mt-0.5">Original collegiate architectural asset preserved without distortion.</p>
            </div>
          </div>

          <div className="p-3 bg-slate-50 rounded-md border border-slate-200 flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-slate-800">Grievance Confidentiality</p>
              <p className="text-[11px] text-slate-500 mt-0.5">Redressal cases isolated from public channels with SLA tracking.</p>
            </div>
          </div>

          <div className="p-3 bg-slate-50 rounded-md border border-slate-200 flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-slate-800">Anonymity Safeguard</p>
              <p className="text-[11px] text-slate-500 mt-0.5">Student suggestions submitted anonymously conceal identities completely.</p>
            </div>
          </div>

          <div className="p-3 bg-slate-50 rounded-md border border-slate-200 flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-slate-800">Verifiable Reports</p>
              <p className="text-[11px] text-slate-500 mt-0.5">Real-time CSV, Excel, and printable PDF documents matching query state.</p>
            </div>
          </div>
        </div>
      </div>

      {/* Two Columns: Provisioned Accounts & Audit Log */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Provisioned Directory */}
        <div className="bg-white p-5 rounded-lg border border-slate-200">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-slate-900">Provisioned Collegiate Accounts</h3>
            <span className="text-xs font-mono text-slate-400">{userList.length} Users</span>
          </div>

          <div className="max-h-80 overflow-y-auto divide-y divide-slate-100 text-xs">
            {userList.map((u: User) => (
              <div key={u.id} className="py-2.5 flex items-center justify-between">
                <div>
                  <p className="font-bold text-slate-800">{u.name}</p>
                  <p className="text-[11px] text-slate-500 font-mono">{u.email}</p>
                  <p className="text-[11px] text-slate-400">
                    {u.departmentName || u.className || 'Central Executive'}
                  </p>
                </div>
                <div className="text-right">
                  <span className="px-2 py-0.5 bg-slate-100 text-slate-700 font-mono font-bold text-[10px] rounded">
                    {u.role}
                  </span>
                  <p className="text-[10px] text-slate-400 font-mono mt-0.5">
                    {u.employeeId || u.rollNumber || 'ID-ACTIVE'}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Audit Registry */}
        <div className="bg-white p-5 rounded-lg border border-slate-200">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-slate-900">Immutable Audit Registry</h3>
            <span className="text-xs font-mono text-slate-400">{auditLogs.length} Events</span>
          </div>

          <div className="max-h-80 overflow-y-auto divide-y divide-slate-100 text-xs">
            {auditLogs.length === 0 ? (
              <p className="p-4 text-center text-slate-400">No events logged yet.</p>
            ) : (
              auditLogs.map((log) => (
                <div key={log.id} className="py-2.5">
                  <div className="flex items-center justify-between text-[11px] font-mono text-slate-500">
                    <span className="font-bold text-red-700">{log.action}</span>
                    <span>{new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                  </div>
                  <p className="text-slate-800 font-medium mt-0.5">{log.details}</p>
                  <p className="text-[10px] text-slate-400 font-mono mt-0.5">
                    Actor: {log.userName} ({log.userRole}) · Resource: {log.targetResource}
                  </p>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Provision Staff Modal */}
      {showAddUserModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-white rounded-lg shadow-xl border border-slate-200 p-6">
            <h3 className="text-base font-bold text-slate-900">Provision Faculty / Staff Account</h3>
            <p className="text-xs text-slate-500 mt-0.5">Authorized institutional provisioning with employee ID verification.</p>

            <form onSubmit={handleProvisionUser} className="mt-4 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Full Name *</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Dr. Ramesh Sundaram"
                  className="w-full text-xs p-2.5 rounded-md border border-slate-300 focus:border-red-600 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Institutional Email *</label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="e.g. ramesh.s@campusconnect.edu"
                  className="w-full text-xs p-2.5 rounded-md border border-slate-300 focus:border-red-600 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Institutional Role</label>
                <select
                  value={role}
                  onChange={(e) => setRole(e.target.value as UserRole)}
                  className="w-full text-xs p-2 rounded-md border border-slate-300 bg-white"
                >
                  <option value="ADVISOR">Faculty / Advisor</option>
                  <option value="HOD">Head of Department (HOD)</option>
                  <option value="PRINCIPAL">Executive Principal</option>
                </select>
              </div>

              {role !== 'PRINCIPAL' && (
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Academic Department</label>
                  <select
                    value={selectedDeptId}
                    onChange={(e) => setSelectedDeptId(e.target.value)}
                    className="w-full text-xs p-2 rounded-md border border-slate-300 bg-white"
                  >
                    {departments.map(d => (
                      <option key={d.id} value={d.id}>{d.name} ({d.code})</option>
                    ))}
                  </select>
                </div>
              )}

              {role === 'ADVISOR' && (
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Assigned Class / Section</label>
                  <select
                    value={selectedClassId}
                    onChange={(e) => setSelectedClassId(e.target.value)}
                    className="w-full text-xs p-2 rounded-md border border-slate-300 bg-white"
                  >
                    {classes.map(c => (
                      <option key={c.id} value={c.id}>{c.name}</option>
                    ))}
                  </select>
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Employee ID</label>
                <input
                  type="text"
                  value={employeeId}
                  onChange={(e) => setEmployeeId(e.target.value)}
                  placeholder="e.g. EMP-CSE-0042"
                  className="w-full text-xs p-2.5 rounded-md border border-slate-300 focus:border-red-600 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Initial Password</label>
                <input
                  type="text"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full text-xs p-2.5 rounded-md border border-slate-300 focus:border-red-600 focus:outline-hidden font-mono"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setShowAddUserModal(false)}
                  className="px-3.5 py-2 text-xs font-medium text-slate-600 hover:text-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-bold text-white bg-red-600 hover:bg-red-700 rounded-md transition-colors"
                >
                  Provision Account
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
