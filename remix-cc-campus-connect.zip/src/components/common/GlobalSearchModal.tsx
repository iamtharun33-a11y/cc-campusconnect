import React, { useState, useMemo } from 'react';
import { useAuth } from '../../context/AuthContext';
import { storageService } from '../../services/storage';
import { Search, X, Volume2, MessageSquare, AlertCircle, Lightbulb } from 'lucide-react';

interface GlobalSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectResult: (module: string, id?: string) => void;
}

export const GlobalSearchModal: React.FC<GlobalSearchModalProps> = ({
  isOpen,
  onClose,
  onSelectResult
}) => {
  const { currentUser } = useAuth();
  const [query, setQuery] = useState('');

  const searchResults = useMemo(() => {
    if (!currentUser || !query.trim()) return [];
    const q = query.toLowerCase().trim();

    // 1. Announcements
    const announcements = storageService.getAnnouncementsForUser(currentUser);
    const matchedAnnouncements = announcements
      .filter(a => a.title.toLowerCase().includes(q) || a.content.toLowerCase().includes(q) || a.category.toLowerCase().includes(q))
      .map(a => ({
        id: a.id,
        module: 'announcements',
        title: a.title,
        subtitle: `${a.category} · Published by ${a.publisherName}`,
        date: a.createdAt.split('T')[0],
        icon: Volume2,
        color: 'text-red-600'
      }));

    // 2. Suggestions
    const suggestions = storageService.getSuggestionsForUser(currentUser);
    const matchedSuggestions = suggestions
      .filter(s => s.title.toLowerCase().includes(q) || s.description.toLowerCase().includes(q) || s.referenceNo.toLowerCase().includes(q))
      .map(s => ({
        id: s.id,
        module: 'suggestions',
        title: `${s.referenceNo} — ${s.title}`,
        subtitle: `Status: ${s.status} · Dept: ${s.departmentName}`,
        date: s.createdAt.split('T')[0],
        icon: Lightbulb,
        color: 'text-emerald-600'
      }));

    // 3. Grievances
    const grievances = storageService.getGrievancesForUser(currentUser);
    const matchedGrievances = grievances
      .filter(g => g.title.toLowerCase().includes(q) || g.description.toLowerCase().includes(q) || g.caseId.toLowerCase().includes(q))
      .map(g => ({
        id: g.id,
        module: 'grievances',
        title: `${g.caseId} — ${g.title}`,
        subtitle: `Priority: ${g.priority} · Status: ${g.status}`,
        date: g.createdAt.split('T')[0],
        icon: AlertCircle,
        color: 'text-amber-600'
      }));

    // 4. Conversations
    const convos = storageService.getConversationsForUser(currentUser.id);
    const matchedConvos = convos
      .filter(c => c.participantNames.some(name => name.toLowerCase().includes(q)) || c.lastMessageSnippet.toLowerCase().includes(q))
      .map(c => ({
        id: c.id,
        module: 'messages',
        title: `Chat with ${c.participantNames.filter(n => n !== currentUser.name).join(', ')}`,
        subtitle: c.lastMessageSnippet,
        date: c.lastMessageAt.split('T')[0],
        icon: MessageSquare,
        color: 'text-blue-600'
      }));

    return [...matchedAnnouncements, ...matchedGrievances, ...matchedSuggestions, ...matchedConvos];
  }, [currentUser, query]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/40 backdrop-blur-xs flex items-start justify-center p-4 pt-20">
      <div className="w-full max-w-xl bg-white rounded-lg shadow-2xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        <div className="p-4 border-b border-slate-200 flex items-center gap-3">
          <Search className="w-5 h-5 text-slate-400 shrink-0" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search notices, messages, grievances, suggestions..."
            autoFocus
            className="flex-1 text-sm bg-transparent border-none outline-none text-slate-900 placeholder:text-slate-400"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="p-1 text-slate-400 hover:text-slate-600"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={onClose}
            className="text-xs font-semibold px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded transition-colors"
          >
            ESC
          </button>
        </div>

        <div className="max-h-96 overflow-y-auto p-2">
          {!query.trim() ? (
            <div className="p-6 text-center text-xs text-slate-400">
              Type keywords, Case IDs (e.g. GRV-2026), or Suggestion references (e.g. SUG-2026).
            </div>
          ) : searchResults.length === 0 ? (
            <div className="p-6 text-center text-xs text-slate-500">
              No matching records found for "{query}".
            </div>
          ) : (
            searchResults.map((item) => {
              const Icon = item.icon;
              return (
                <div
                  key={`${item.module}-${item.id}`}
                  onClick={() => {
                    onSelectResult(item.module, item.id);
                    onClose();
                  }}
                  className="p-3 rounded-md hover:bg-slate-50 cursor-pointer flex items-start gap-3 transition-colors border border-transparent hover:border-slate-200"
                >
                  <div className={`mt-0.5 p-1.5 rounded bg-slate-100 ${item.color}`}>
                    <Icon className="w-4 h-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <p className="text-xs font-semibold text-slate-900 truncate">{item.title}</p>
                      <span className="text-[11px] font-mono text-slate-400">{item.date}</span>
                    </div>
                    <p className="text-xs text-slate-500 truncate mt-0.5">{item.subtitle}</p>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
