import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, UserRole } from '../types';
import { storageService } from '../services/storage';

interface AuthContextType {
  currentUser: User | null;
  isLoading: boolean;
  login: (identifier: string, password: string, portalRole?: UserRole) => Promise<{ success: boolean; error?: string }>;
  registerStudent: (data: {
    name: string;
    email: string;
    rollNumber: string;
    departmentId: string;
    departmentName: string;
    classId: string;
    className: string;
    course?: string;
    academicBatch?: string;
    year: string;
    semester: number;
    section?: string;
    password: string;
  }) => Promise<User>;
  registerFaculty: (data: {
    name: string;
    email: string;
    employeeId: string;
    departmentId: string;
    departmentName: string;
    course?: string;
    classId?: string;
    className?: string;
    password: string;
  }) => Promise<User>;
  registerHod: (data: {
    name: string;
    email: string;
    employeeId: string;
    departmentId: string;
    departmentName: string;
    password: string;
  }) => Promise<User>;
  registerPrincipal: (data: {
    name: string;
    email: string;
    employeeId: string;
    password: string;
  }) => Promise<User>;
  logout: () => void;
  refreshCurrentUser: () => void;
  canPublishCollegeWide: boolean;
  canPublishDepartmentWide: boolean;
  canPublishClassWide: boolean;
  canModerateDiscussions: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const refreshCurrentUser = () => {
    const currentId = storageService.getCurrentUserId();
    if (currentId) {
      const user = storageService.getUserById(currentId);
      if (user && user.isActive) {
        setCurrentUser(user);
      } else {
        setCurrentUser(null);
        storageService.setCurrentUserId(null);
      }
    } else {
      setCurrentUser(null);
    }
  };

  useEffect(() => {
    const init = async () => {
      if (!storageService.isSystemInitialized()) {
        await storageService.initializeVerifiedCollegiateStructure();
      }
      refreshCurrentUser();
      setIsLoading(false);
    };
    init();
  }, []);

  const login = async (identifier: string, password: string, portalRole?: UserRole): Promise<{ success: boolean; error?: string }> => {
    const res = await storageService.authenticateUser(identifier, password, portalRole);
    if (res.success && res.user) {
      setCurrentUser(res.user);
      return { success: true };
    }
    return { success: false, error: res.error || 'Authentication failed' };
  };

  const registerStudent = async (data: {
    name: string;
    email: string;
    rollNumber: string;
    departmentId: string;
    departmentName: string;
    classId: string;
    className: string;
    course?: string;
    academicBatch?: string;
    year: string;
    semester: number;
    section?: string;
    password: string;
  }): Promise<User> => {
    const newUser = await storageService.createUser({
      name: data.name,
      email: data.email,
      rollNumber: data.rollNumber,
      role: 'STUDENT',
      departmentId: data.departmentId,
      departmentName: data.departmentName,
      classId: data.classId,
      className: data.className,
      course: data.course,
      academicBatch: data.academicBatch,
      year: data.year,
      semester: data.semester,
      section: data.section,
      password: data.password,
      isActive: true
    });

    // Automatically set authenticated session
    storageService.setCurrentUserId(newUser.id);
    setCurrentUser(newUser);
    return newUser;
  };

  const registerFaculty = async (data: {
    name: string;
    email: string;
    employeeId: string;
    departmentId: string;
    departmentName: string;
    course?: string;
    classId?: string;
    className?: string;
    password: string;
  }): Promise<User> => {
    const newUser = await storageService.createUser({
      name: data.name,
      email: data.email,
      employeeId: data.employeeId,
      role: 'ADVISOR',
      departmentId: data.departmentId,
      departmentName: data.departmentName,
      course: data.course,
      classId: data.classId,
      className: data.className,
      password: data.password,
      isActive: true
    });

    storageService.setCurrentUserId(newUser.id);
    setCurrentUser(newUser);
    return newUser;
  };

  const registerHod = async (data: {
    name: string;
    email: string;
    employeeId: string;
    departmentId: string;
    departmentName: string;
    password: string;
  }): Promise<User> => {
    const newUser = await storageService.createUser({
      name: data.name,
      email: data.email,
      employeeId: data.employeeId,
      role: 'HOD',
      departmentId: data.departmentId,
      departmentName: data.departmentName,
      password: data.password,
      isActive: true
    });

    storageService.setCurrentUserId(newUser.id);
    setCurrentUser(newUser);
    return newUser;
  };

  const registerPrincipal = async (data: {
    name: string;
    email: string;
    employeeId: string;
    password: string;
  }): Promise<User> => {
    const newUser = await storageService.createUser({
      name: data.name,
      email: data.email,
      employeeId: data.employeeId,
      role: 'PRINCIPAL',
      password: data.password,
      isActive: true
    });

    storageService.setCurrentUserId(newUser.id);
    setCurrentUser(newUser);
    return newUser;
  };

  const logout = () => {
    if (currentUser) {
      storageService.logAudit(currentUser.id, currentUser.name, currentUser.role, 'USER_LOGOUT', 'AUTH', `User logged out: ${currentUser.email}`);
    }
    storageService.setCurrentUserId(null);
    setCurrentUser(null);
  };

  const canPublishCollegeWide = currentUser?.role === 'PRINCIPAL';
  const canPublishDepartmentWide = currentUser?.role === 'PRINCIPAL' || currentUser?.role === 'HOD';
  const canPublishClassWide = currentUser?.role === 'PRINCIPAL' || currentUser?.role === 'HOD' || currentUser?.role === 'ADVISOR';
  const canModerateDiscussions = currentUser?.role === 'PRINCIPAL' || currentUser?.role === 'HOD' || currentUser?.role === 'ADVISOR';

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        isLoading,
        login,
        registerStudent,
        registerFaculty,
        registerHod,
        registerPrincipal,
        logout,
        refreshCurrentUser,
        canPublishCollegeWide,
        canPublishDepartmentWide,
        canPublishClassWide,
        canModerateDiscussions,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
