import React, { useState, useMemo } from 'react';
import { useAuth } from '../../context/AuthContext';
import { storageService } from '../../services/storage';
import { reportService } from '../../services/reports';
import { Download, FileText, FileSpreadsheet, Printer, X } from 'lucide-react';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultModule?: 'grievances' | 'suggestions' | 'announcements' | 'department';
}

export const ExportModal: React.FC<ExportModalProps> = ({
  isOpen,
  onClose,
  defaultModule = 'grievances'
}) => {
  const { currentUser } = useAuth();
  const [reportType, setReportType] = useState<'grievances' | 'suggestions' | 'announcements' | 'department'>(defaultModule);
  const [format, setFormat] = useState<'pdf' | 'xlsx' | 'csv'>('csv');
  const [dateFilter, setDateFilter] = useState<'all' | 'last30' | 'last90'>('all');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [sortBy, setSortBy] = useState<'NEWEST' | 'OLDEST' | 'TITLE' | 'PRIORITY'>('NEWEST');

  const matchingRecords = useMemo(() => {
    if (!currentUser) return [];

    let records: any[] = [];
    if (reportType === 'grievances') {
      records = storageService.getGrievancesForUser(currentUser);
    } else if (reportType === 'suggestions') {
      records = storageService.getSuggestionsForUser(currentUser);
    } else if (reportType === 'announcements') {
      records = storageService.getAnnouncementsForUser(currentUser);
    } else if (reportType === 'department') {
      records = storageService.getGrievancesForUser(currentUser);
    }

    if (dateFilter !== 'all') {
      const days = dateFilter === 'last30' ? 30 : 90;
      const cutoff = Date.now() - days * 24 * 60 * 60 * 1000;
      records = records.filter(r => new Date(r.createdAt).getTime() >= cutoff);
    }

    if (statusFilter !== 'ALL') {
      records = records.filter(r => {
        if (reportType === 'announcements') {
          if (statusFilter === 'HALF_DAY') return r.isHalfDayNotice;
          return r.category === statusFilter;
        }
        return r.status === statusFilter;
      });
    }

    // Sort matching records
    return [...records].sort((a, b) => {
      if (sortBy === 'NEWEST') return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      if (sortBy === 'OLDEST') return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
      if (sortBy === 'TITLE') return (a.title || '').localeCompare(b.title || '');
      if (sortBy === 'PRIORITY') {
        const priorityOrder: Record<string, number> = { CRITICAL: 3, URGENT: 3, HIGH: 2, NORMAL: 1, LOW: 0 };
        return (priorityOrder[b.priority] || 0) - (priorityOrder[a.priority] || 0);
      }
      return 0;
    });
  }, [currentUser, reportType, dateFilter, statusFilter, sortBy]);

  if (!isOpen || !currentUser) return null;

  const handleExport = () => {
    const timestamp = new Date().toISOString().split('T')[0];

    if (reportType === 'grievances' || reportType === 'department') {
      const { headers, rows } = reportService.formatGrievancesForExport(matchingRecords);
      const filename = `CC_Campus_Grievances_${timestamp}`;
      if (format === 'csv') {
        reportService.downloadCsv(filename, headers, rows);
      } else if (format === 'xlsx') {
        reportService.downloadXlsx(filename, 'Grievances', headers, rows);
      } else if (format === 'pdf') {
        reportService.printPdfReport(
          'Institutional Grievance Redressal Audit Report',
          `Filter: ${dateFilter.toUpperCase()} · Records: ${rows.length}`,
          headers,
          rows
        );
      }
    } else if (reportType === 'suggestions') {
      const { headers, rows } = reportService.formatSuggestionsForExport(matchingRecords);
      const filename = `CC_Campus_Suggestions_${timestamp}`;
      if (format === 'csv') {
        reportService.downloadCsv(filename, headers, rows);
      } else if (format === 'xlsx') {
        reportService.downloadXlsx(filename, 'Suggestions', headers, rows);
      } else if (format === 'pdf') {
        reportService.printPdfReport(
          'Student Suggestions & Institutional Feedback Report',
          `Filter: ${dateFilter.toUpperCase()} · Records: ${rows.length}`,
          headers,
          rows
        );
      }
    } else if (reportType === 'announcements') {
      const { headers, rows } = reportService.formatAnnouncementsForExport(matchingRecords);
      const filename = `CC_Campus_Announcements_${timestamp}`;
      if (format === 'csv') {
        reportService.downloadCsv(filename, headers, rows);
      } else if (format === 'xlsx') {
        reportService.downloadXlsx(filename, 'Announcements', headers, rows);
      } else if (format === 'pdf') {
        reportService.printPdfReport(
          'Official Collegiate Notices & Schedule Bulletins',
          `Filter: ${dateFilter.toUpperCase()} · Records: ${rows.length}`,
          headers,
          rows
        );
      }
    }

    storageService.logAudit(
      currentUser.id,
      currentUser.name,
      currentUser.role,
      'REPORT_EXPORTED',
      reportType.toUpperCase(),
      `Exported ${matchingRecords.length} records as ${format.toUpperCase()}`
    );

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="w-full max-w-lg bg-white rounded-lg shadow-xl border border-slate-200 overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div>
            <h3 className="text-base font-bold text-slate-900">Institutional Report Export</h3>
            <p className="text-xs text-slate-500 mt-0.5">Generate verified database export with role-authorized fields.</p>
          </div>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-slate-600 rounded">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5">
          {/* Module Selector */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-2">
              Report Subject
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setReportType('grievances')}
                className={`px-3 py-2 text-xs font-semibold rounded-md border text-center transition-colors ${
                  reportType === 'grievances'
                    ? 'bg-red-50 border-red-300 text-red-700'
                    : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                Grievances
              </button>
              <button
                type="button"
                onClick={() => setReportType('suggestions')}
                className={`px-3 py-2 text-xs font-semibold rounded-md border text-center transition-colors ${
                  reportType === 'suggestions'
                    ? 'bg-red-50 border-red-300 text-red-700'
                    : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                Suggestions
              </button>
              <button
                type="button"
                onClick={() => setReportType('announcements')}
                className={`px-3 py-2 text-xs font-semibold rounded-md border text-center transition-colors ${
                  reportType === 'announcements'
                    ? 'bg-red-50 border-red-300 text-red-700'
                    : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                Announcements
              </button>
            </div>
          </div>

          {/* Date Filter */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-2">
              Time Window
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setDateFilter('all')}
                className={`px-3 py-1.5 text-xs font-medium rounded-md border text-center ${
                  dateFilter === 'all'
                    ? 'bg-slate-800 text-white border-slate-800'
                    : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                }`}
              >
                All Time
              </button>
              <button
                type="button"
                onClick={() => setDateFilter('last30')}
                className={`px-3 py-1.5 text-xs font-medium rounded-md border text-center ${
                  dateFilter === 'last30'
                    ? 'bg-slate-800 text-white border-slate-800'
                    : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                }`}
              >
                Past 30 Days
              </button>
              <button
                type="button"
                onClick={() => setDateFilter('last90')}
                className={`px-3 py-1.5 text-xs font-medium rounded-md border text-center ${
                  dateFilter === 'last90'
                    ? 'bg-slate-800 text-white border-slate-800'
                    : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                }`}
              >
                Past 90 Days
              </button>
            </div>
          </div>

          {/* Category/Status Filter */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                Filter Status
              </label>
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="w-full text-xs p-2 rounded-md border border-slate-300 bg-white"
              >
                <option value="ALL">All Statuses</option>
                {reportType === 'grievances' && (
                  <>
                    <option value="ADVISOR_REVIEW">Under Advisor Review</option>
                    <option value="ESCALATED_HOD">Escalated to HOD</option>
                    <option value="ESCALATED_PRINCIPAL">Escalated to Principal</option>
                    <option value="RESOLVED">Resolved / Closed</option>
                  </>
                )}
                {reportType === 'suggestions' && (
                  <>
                    <option value="SUBMITTED">Newly Submitted</option>
                    <option value="UNDER_REVIEW">Under Review</option>
                    <option value="ACCEPTED">Accepted / Approved</option>
                    <option value="REJECTED">Declined</option>
                  </>
                )}
                {reportType === 'announcements' && (
                  <>
                    <option value="ACADEMIC">Academic</option>
                    <option value="EXAMINATION">Examination</option>
                    <option value="HALF_DAY">Half-Day Notices</option>
                    <option value="URGENT">Urgent Circulars</option>
                  </>
                )}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                Sort By
              </label>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="w-full text-xs p-2 rounded-md border border-slate-300 bg-white"
              >
                <option value="NEWEST">Newest First</option>
                <option value="OLDEST">Oldest First</option>
                <option value="TITLE">Title / Subject A-Z</option>
                {reportType === 'grievances' && <option value="PRIORITY">Highest Priority First</option>}
              </select>
            </div>
          </div>

          {/* Export Format */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-2">
              Export Format
            </label>
            <div className="grid grid-cols-3 gap-3">
              <button
                type="button"
                onClick={() => setFormat('csv')}
                className={`p-3 rounded-lg border flex flex-col items-center gap-1.5 text-center transition-all ${
                  format === 'csv'
                    ? 'border-red-600 bg-red-50/30 text-red-700'
                    : 'border-slate-200 hover:bg-slate-50 text-slate-600'
                }`}
              >
                <FileText className="w-5 h-5 text-slate-600" />
                <span className="text-xs font-bold">CSV</span>
                <span className="text-[10px] text-slate-400">RFC4180 Escaped</span>
              </button>

              <button
                type="button"
                onClick={() => setFormat('xlsx')}
                className={`p-3 rounded-lg border flex flex-col items-center gap-1.5 text-center transition-all ${
                  format === 'xlsx'
                    ? 'border-red-600 bg-red-50/30 text-red-700'
                    : 'border-slate-200 hover:bg-slate-50 text-slate-600'
                }`}
              >
                <FileSpreadsheet className="w-5 h-5 text-emerald-600" />
                <span className="text-xs font-bold">Excel / XLSX</span>
                <span className="text-[10px] text-slate-400">XML Spreadsheet</span>
              </button>

              <button
                type="button"
                onClick={() => setFormat('pdf')}
                className={`p-3 rounded-lg border flex flex-col items-center gap-1.5 text-center transition-all ${
                  format === 'pdf'
                    ? 'border-red-600 bg-red-50/30 text-red-700'
                    : 'border-slate-200 hover:bg-slate-50 text-slate-600'
                }`}
              >
                <Printer className="w-5 h-5 text-red-600" />
                <span className="text-xs font-bold">Printable PDF</span>
                <span className="text-[10px] text-slate-400">Formatted Report</span>
              </button>
            </div>
          </div>

          {/* Live Preview List with Condition & Status */}
          <div className="border border-slate-200 rounded-lg p-3 bg-slate-50/70 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-slate-700">Preview Filtered Records ({matchingRecords.length}):</span>
              <span className="text-[11px] text-slate-500 font-mono">Sorted by {sortBy}</span>
            </div>

            {matchingRecords.length === 0 ? (
              <p className="text-xs text-slate-400 py-4 text-center">No matching records found for selected filters.</p>
            ) : (
              <div className="max-h-36 overflow-y-auto divide-y divide-slate-200 bg-white rounded border border-slate-200 text-xs">
                {matchingRecords.slice(0, 10).map((item) => (
                  <div key={item.id} className="p-2.5 flex items-center justify-between gap-2">
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-slate-800 text-[11px]">
                          {item.caseId || item.referenceNo || item.id}
                        </span>
                        <span className="truncate text-slate-700">{item.title}</span>
                      </div>
                      <div className="text-[10px] text-slate-400 mt-0.5 font-mono">
                        Date: {item.createdAt?.split('T')[0]} {item.studentName ? `· Student: ${item.studentName}` : ''}
                      </div>
                    </div>
                    <div className="text-right shrink-0">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        item.status === 'RESOLVED' || item.status === 'ACCEPTED'
                          ? 'bg-emerald-100 text-emerald-800'
                          : item.status?.includes('ESCALATED') || item.priority === 'CRITICAL' || item.priority === 'HIGH'
                          ? 'bg-red-100 text-red-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}>
                        {item.status ? item.status.replace('_', ' ') : item.priority || 'ACTIVE'}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex items-center justify-end gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-600 hover:text-slate-800"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleExport}
            disabled={matchingRecords.length === 0}
            className="px-4 py-2 text-xs font-bold text-white bg-red-600 hover:bg-red-700 disabled:opacity-50 disabled:cursor-not-allowed rounded-md transition-colors flex items-center gap-2 shadow-xs"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Generate & Download</span>
          </button>
        </div>
      </div>
    </div>
  );
};
