import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { storageService } from '../../services/storage';
import { Announcement, NoticeAudience, NoticeCategory, NoticePriority } from '../../types';
import { EmptyState } from '../common/EmptyState';
import {
  Volume2,
  Clock,
  Plus,
  CheckCircle2,
  Calendar,
  AlertTriangle,
  Building,
  GraduationCap,
  Globe,
  Filter
} from 'lucide-react';

export const AnnouncementsModule: React.FC = () => {
  const { currentUser, canPublishCollegeWide, canPublishDepartmentWide, canPublishClassWide } = useAuth();
  const [filterCategory, setFilterCategory] = useState<string>('ALL');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showHalfDayModal, setShowHalfDayModal] = useState(false);

  // Form states
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [category, setCategory] = useState<NoticeCategory>('ACADEMIC');
  const [priority, setPriority] = useState<NoticePriority>('NORMAL');
  const [audience, setAudience] = useState<NoticeAudience>('COLLEGE_WIDE');
  const [effectiveDate, setEffectiveDate] = useState('');
  const [startTime, setStartTime] = useState('13:00');
  const [endTime, setEndTime] = useState('17:00');
  const [requiresAcknowledgement, setRequiresAcknowledgement] = useState(false);
  const [isDraft, setIsDraft] = useState(false);

  // Half-Day Notice Confirmation Modal state
  const [isConfirmingHalfDay, setIsConfirmingHalfDay] = useState(false);

  if (!currentUser) return null;

  const announcements = storageService.getAnnouncementsForUser(currentUser);

  const filteredNotices = announcements.filter(a => {
    if (filterCategory === 'ALL') return true;
    if (filterCategory === 'HALF_DAY') return a.isHalfDayNotice;
    return a.category === filterCategory;
  });

  const canPublishAny = canPublishCollegeWide || canPublishDepartmentWide || canPublishClassWide;

  const handleCreateNotice = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !content.trim()) return;

    // Audience scope checks
    let targetAudience = audience;
    let targetDeptId = currentUser.departmentId;
    let targetDeptName = currentUser.departmentName;
    let targetClassId = currentUser.classId;
    let targetClassName = currentUser.className;

    if (currentUser.role === 'HOD' && audience === 'COLLEGE_WIDE') {
      targetAudience = 'DEPARTMENT';
    } else if (currentUser.role === 'ADVISOR') {
      targetAudience = 'CLASS';
    }

    storageService.createAnnouncement({
      title,
      content,
      category,
      priority,
      audience: targetAudience,
      targetDepartmentId: targetDeptId,
      targetDepartmentName: targetDeptName,
      targetClassId: targetClassId,
      targetClassName: targetClassName,
      publisherId: currentUser.id,
      publisherName: currentUser.name,
      publisherRole: currentUser.role,
      isDraft,
      isArchived: false,
      isHalfDayNotice: category === 'HALF_DAY',
      effectiveDate: effectiveDate || new Date().toISOString().split('T')[0],
      startTime: category === 'HALF_DAY' ? startTime : undefined,
      endTime: category === 'HALF_DAY' ? endTime : undefined,
      requiresAcknowledgement
    });

    // Reset
    setTitle('');
    setContent('');
    setCategory('ACADEMIC');
    setPriority('NORMAL');
    setRequiresAcknowledgement(false);
    setIsDraft(false);
    setShowCreateModal(false);
    setShowHalfDayModal(false);
    setIsConfirmingHalfDay(false);
  };

  const handleAcknowledge = (noticeId: string) => {
    storageService.acknowledgeAnnouncement(noticeId, currentUser.id);
    // Force re-render via local state trigger
    setFilterCategory(prev => prev);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-lg border border-slate-200">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">Official College Notices</h1>
          <p className="text-xs text-slate-500 mt-1">
            Authoritative institutional directives, timetable amendments, and schedule circulars.
          </p>
        </div>

        {canPublishAny && (
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                setCategory('HALF_DAY');
                setTitle('Institutional Circular: Half-Day Working Schedule');
                setContent('Please be informed that academic sessions will conclude at midday on the specified date.');
                setEffectiveDate(new Date().toISOString().split('T')[0]);
                setShowHalfDayModal(true);
              }}
              className="px-3 py-2 text-xs font-semibold text-amber-700 bg-amber-50 hover:bg-amber-100 border border-amber-200 rounded-md transition-colors flex items-center gap-1.5"
            >
              <Clock className="w-3.5 h-3.5 text-amber-600" />
              <span>Issue Half-Day Notice</span>
            </button>

            <button
              onClick={() => setShowCreateModal(true)}
              className="px-3.5 py-2 text-xs font-bold text-white bg-red-600 hover:bg-red-700 rounded-md transition-colors flex items-center gap-1.5 shadow-xs"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Publish Notice</span>
            </button>
          </div>
        )}
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-1 overflow-x-auto pb-1 text-xs">
        {['ALL', 'HALF_DAY', 'ACADEMIC', 'EXAMINATION', 'TIMETABLE', 'HOLIDAY', 'URGENT'].map((cat) => (
          <button
            key={cat}
            onClick={() => setFilterCategory(cat)}
            className={`px-3 py-1.5 font-medium rounded-md whitespace-nowrap transition-colors ${
              filterCategory === cat
                ? 'bg-slate-900 text-white font-semibold'
                : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            {cat === 'ALL' ? 'All Notices' : cat.replace('_', ' ')}
          </button>
        ))}
      </div>

      {/* Notices Feed */}
      {filteredNotices.length === 0 ? (
        <EmptyState
          icon={Volume2}
          title="No Active Announcements"
          description={
            canPublishAny
              ? 'No announcements have been published in this scope yet. Click "Publish Notice" above to circulate the first official notice.'
              : 'There are no active notices published for your department or class at this time.'
          }
          actionLabel={canPublishAny ? 'Publish First Notice' : undefined}
          onAction={canPublishAny ? () => setShowCreateModal(true) : undefined}
        />
      ) : (
        <div className="space-y-4">
          {filteredNotices.map((notice) => {
            const hasAcknowledged = notice.acknowledgements?.includes(currentUser.id);
            return (
              <div
                key={notice.id}
                className={`bg-white rounded-lg border transition-shadow ${
                  notice.priority === 'URGENT'
                    ? 'border-red-300 ring-1 ring-red-100'
                    : notice.isHalfDayNotice
                    ? 'border-amber-300'
                    : 'border-slate-200 hover:border-slate-300'
                } p-5`}
              >
                {/* Header row with zero-pill metadata */}
                <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-3">
                  <div className="flex items-center gap-2 text-xs text-slate-500">
                    <span className="font-semibold text-slate-700">{notice.category.replace('_', ' ')}</span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono">{notice.createdAt.split('T')[0]}</span>
                    <span aria-hidden="true">·</span>
                    <span>Audience: {notice.audience.replace('_', ' ')}</span>
                    {notice.isDraft && (
                      <>
                        <span aria-hidden="true">·</span>
                        <span className="text-amber-700 font-bold">[DRAFT ONLY]</span>
                      </>
                    )}
                  </div>

                  {notice.priority !== 'NORMAL' && (
                    <span className={`text-[11px] font-bold font-mono uppercase tracking-wider ${
                      notice.priority === 'URGENT' ? 'text-red-700' : 'text-amber-700'
                    }`}>
                      {notice.priority} PRIORITY
                    </span>
                  )}
                </div>

                {/* Main Content */}
                <div className="mt-3">
                  <h3 className="text-base font-bold text-slate-900 leading-snug">{notice.title}</h3>
                  <p className="text-xs text-slate-700 mt-2 leading-relaxed whitespace-pre-line">{notice.content}</p>

                  {/* Half-Day Specific Details Box */}
                  {notice.isHalfDayNotice && (
                    <div className="mt-3 p-3 bg-amber-50/60 rounded-md border border-amber-200 text-xs text-amber-900 flex items-center gap-4">
                      <div className="flex items-center gap-1.5 font-medium">
                        <Calendar className="w-4 h-4 text-amber-700" />
                        <span>Date: <strong>{notice.effectiveDate}</strong></span>
                      </div>
                      {notice.startTime && notice.endTime && (
                        <div className="flex items-center gap-1.5 font-medium font-mono">
                          <Clock className="w-4 h-4 text-amber-700" />
                          <span>Working Hours: {notice.startTime} – {notice.endTime}</span>
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* Footer with Publisher and Acknowledgment */}
                <div className="mt-4 pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3 text-xs">
                  <div className="text-slate-500">
                    Published by <strong className="text-slate-800">{notice.publisherName}</strong> ({notice.publisherRole})
                  </div>

                  <div className="flex items-center gap-3">
                    {notice.requiresAcknowledgement && (
                      <div className="flex items-center gap-2">
                        <span className="text-[11px] text-slate-400 font-mono">
                          {notice.acknowledgements?.length || 0} acknowledgements
                        </span>
                        {currentUser.role === 'STUDENT' && (
                          <button
                            onClick={() => handleAcknowledge(notice.id)}
                            disabled={hasAcknowledged}
                            className={`px-2.5 py-1 text-xs font-semibold rounded flex items-center gap-1 transition-colors ${
                              hasAcknowledged
                                ? 'bg-emerald-50 text-emerald-700 border border-emerald-200 cursor-default'
                                : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                            }`}
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>{hasAcknowledged ? 'Acknowledged' : 'Acknowledge Notice'}</span>
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Standard Notice Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="w-full max-w-lg bg-white rounded-lg shadow-xl border border-slate-200 p-6">
            <h3 className="text-base font-bold text-slate-900">Publish Official College Notice</h3>
            <p className="text-xs text-slate-500 mt-0.5">Authoritative publishing logged with employee ID credentials.</p>

            <form onSubmit={handleCreateNotice} className="mt-4 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Notice Title *</label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. End Semester Examination Schedule Announcement"
                  className="w-full text-xs p-2.5 rounded-md border border-slate-300 focus:border-red-600 focus:outline-hidden"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Category</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as NoticeCategory)}
                    className="w-full text-xs p-2 rounded-md border border-slate-300 bg-white"
                  >
                    <option value="ACADEMIC">Academic</option>
                    <option value="EXAMINATION">Examination</option>
                    <option value="TIMETABLE">Timetable Change</option>
                    <option value="HOLIDAY">Holiday Notice</option>
                    <option value="ADMINISTRATIVE">Administrative</option>
                    <option value="URGENT">Urgent Circular</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Priority</label>
                  <select
                    value={priority}
                    onChange={(e) => setPriority(e.target.value as NoticePriority)}
                    className="w-full text-xs p-2 rounded-md border border-slate-300 bg-white"
                  >
                    <option value="NORMAL">Normal</option>
                    <option value="HIGH">High Priority</option>
                    <option value="URGENT">Urgent Action</option>
                  </select>
                </div>
              </div>

              {canPublishCollegeWide && (
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Target Audience</label>
                  <select
                    value={audience}
                    onChange={(e) => setAudience(e.target.value as NoticeAudience)}
                    className="w-full text-xs p-2 rounded-md border border-slate-300 bg-white"
                  >
                    <option value="COLLEGE_WIDE">College Wide (All Departments & Students)</option>
                    <option value="DEPARTMENT">Department Only</option>
                    <option value="CLASS">Specific Class / Section</option>
                  </select>
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Announcement Body *</label>
                <textarea
                  required
                  rows={4}
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="Detail the official instruction, schedule, or institutional policy..."
                  className="w-full text-xs p-2.5 rounded-md border border-slate-300 focus:border-red-600 focus:outline-hidden"
                />
              </div>

              <div className="flex items-center gap-4 text-xs">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={requiresAcknowledgement}
                    onChange={(e) => setRequiresAcknowledgement(e.target.checked)}
                    className="rounded text-red-600 focus:ring-red-500"
                  />
                  <span className="text-slate-700 font-medium">Require Read Acknowledgement</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isDraft}
                    onChange={(e) => setIsDraft(e.target.checked)}
                    className="rounded text-slate-600"
                  />
                  <span className="text-slate-500">Save as Draft Only</span>
                </label>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-3.5 py-2 text-xs font-medium text-slate-600 hover:text-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-bold text-white bg-red-600 hover:bg-red-700 rounded-md transition-colors"
                >
                  {isDraft ? 'Save Draft' : 'Publish Notice'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Half-Day Dedicated Notice Modal */}
      {showHalfDayModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="w-full max-w-lg bg-white rounded-lg shadow-xl border border-amber-300 p-6">
            <div className="flex items-center gap-2 text-amber-700 mb-1">
              <Clock className="w-5 h-5" />
              <h3 className="text-base font-bold text-slate-900">Publish Half-Day Institutional Notice</h3>
            </div>
            <p className="text-xs text-slate-500">
              Circulate formal half-day timing adjustment to faculty and students.
            </p>

            <form onSubmit={handleCreateNotice} className="mt-4 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Notice Title *</label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full text-xs p-2.5 rounded-md border border-slate-300 focus:border-amber-600 focus:outline-hidden"
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Effective Date *</label>
                  <input
                    type="date"
                    required
                    value={effectiveDate}
                    onChange={(e) => setEffectiveDate(e.target.value)}
                    className="w-full text-xs p-2 rounded-md border border-slate-300 bg-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Start Time</label>
                  <input
                    type="time"
                    value={startTime}
                    onChange={(e) => setStartTime(e.target.value)}
                    className="w-full text-xs p-2 rounded-md border border-slate-300 bg-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">End Time</label>
                  <input
                    type="time"
                    value={endTime}
                    onChange={(e) => setEndTime(e.target.value)}
                    className="w-full text-xs p-2 rounded-md border border-slate-300 bg-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Notice Details *</label>
                <textarea
                  required
                  rows={3}
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  className="w-full text-xs p-2.5 rounded-md border border-slate-300 focus:border-amber-600 focus:outline-hidden"
                />
              </div>

              {/* Requirement 144: Confirmation for high-impact schedule notices */}
              <div className="p-3 bg-amber-50 rounded-md border border-amber-200">
                <label className="flex items-start gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    required
                    checked={isConfirmingHalfDay}
                    onChange={(e) => setIsConfirmingHalfDay(e.target.checked)}
                    className="mt-0.5 rounded text-amber-600"
                  />
                  <span className="text-xs text-amber-900 leading-snug">
                    I confirm that this half-day schedule alteration has been formally ratified and authorized by institutional authorities.
                  </span>
                </label>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setShowHalfDayModal(false)}
                  className="px-3.5 py-2 text-xs font-medium text-slate-600 hover:text-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={!isConfirmingHalfDay}
                  className="px-4 py-2 text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 disabled:opacity-50 disabled:cursor-not-allowed rounded-md transition-colors"
                >
                  Confirm & Broadcast Notice
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
