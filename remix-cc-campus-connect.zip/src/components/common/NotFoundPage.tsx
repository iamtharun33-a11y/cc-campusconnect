import React from 'react';
import { AlertTriangle, Home, Lock, ArrowLeft } from 'lucide-react';

interface NotFoundPageProps {
  currentPath?: string;
  onNavigateHome: () => void;
  onNavigatePortals: () => void;
}

export const NotFoundPage: React.FC<NotFoundPageProps> = ({
  currentPath,
  onNavigateHome,
  onNavigatePortals
}) => {
  return (
    <div className="min-h-screen bg-slate-50 flex flex-col justify-center items-center px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full bg-white rounded-xl border border-slate-200 p-8 shadow-xl text-center space-y-5">
        <div className="w-14 h-14 rounded-full bg-red-50 text-red-600 flex items-center justify-center mx-auto">
          <AlertTriangle className="w-8 h-8 stroke-[1.75]" />
        </div>

        <div>
          <span className="text-xs font-mono font-bold text-red-600 uppercase tracking-widest">
            HTTP 404 — NOT FOUND
          </span>
          <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight mt-1">
            Route Does Not Exist
          </h1>
          <p className="text-xs text-slate-500 mt-2 leading-relaxed">
            The requested institutional path is not registered on the CC Campus Connect platform.
          </p>
          {currentPath && (
            <div className="mt-3 p-2 bg-slate-100 rounded font-mono text-[11px] text-slate-700 truncate">
              Requested URL: {currentPath}
            </div>
          )}
        </div>

        <div className="pt-2 flex flex-col sm:flex-row gap-2 justify-center">
          <button
            onClick={onNavigateHome}
            className="px-4 py-2.5 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-md transition-colors flex items-center justify-center gap-1.5"
          >
            <Home className="w-3.5 h-3.5" />
            <span>Return to Homepage</span>
          </button>
          <button
            onClick={onNavigatePortals}
            className="px-4 py-2.5 text-xs font-bold text-white bg-red-600 hover:bg-red-700 rounded-md transition-colors flex items-center justify-center gap-1.5 shadow-xs"
          >
            <Lock className="w-3.5 h-3.5" />
            <span>Four Portal Access</span>
          </button>
        </div>
      </div>
    </div>
  );
};
