import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { storageService } from '../../services/storage';
import { reportService } from '../../services/reports';
import { BarChart3, Download, FileSpreadsheet, Printer, ShieldCheck, CheckCircle2, AlertTriangle, Building, Clock } from 'lucide-react';

interface ReportsModuleProps {
  onOpenExportModal: () => void;
}

export const ReportsModule: React.FC<ReportsModuleProps> = ({ onOpenExportModal }) => {
  const { currentUser } = useAuth();
  if (!currentUser) return null;

  // Real database metrics (Zero fake metrics rule!)
  const notices = storageService.getAnnouncementsForUser(currentUser);
  const grievances = storageService.getGrievancesForUser(currentUser);
  const suggestions = storageService.getSuggestionsForUser(currentUser);
  const departments = storageService.getDepartments();

  const totalGrievances = grievances.length;
  const resolvedGrievances = grievances.filter(g => g.status === 'RESOLVED').length;
  const pendingGrievances = grievances.filter(g => g.status !== 'RESOLVED' && g.status !== 'REJECTED').length;
  const overdueGrievances = grievances.filter(g => g.isOverdue).length;
  const resolutionRate = totalGrievances > 0 ? Math.round((resolvedGrievances / totalGrievances) * 100) : 0;

  const totalSuggestions = suggestions.length;
  const approvedSuggestions = suggestions.filter(s => s.status === 'ACCEPTED' || s.status === 'IMPLEMENTED').length;
  const underReviewSuggestions = suggestions.filter(s => s.status === 'UNDER_REVIEW' || s.status === 'SUBMITTED').length;

  const publishedNotices = notices.filter(n => !n.isDraft).length;
  const halfDayNotices = notices.filter(n => n.isHalfDayNotice).length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-5 rounded-lg border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">Institutional Analytics & Reports</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Real-time audit metrics calculated from genuine authorized records in the central collegiate registry.
          </p>
        </div>

        <button
          onClick={onOpenExportModal}
          className="px-4 py-2 text-xs font-bold text-white bg-red-600 hover:bg-red-700 rounded-md transition-colors flex items-center gap-2 shadow-xs"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Generate Official Export (PDF / Excel / CSV)</span>
        </button>
      </div>

      {/* KPI Stats Grid (Tabular Numerals Enforced) */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-lg border border-slate-200">
          <div className="text-xs font-medium text-slate-500">Active Grievance Cases</div>
          <div className="text-2xl font-bold text-slate-900 font-mono tabular-nums mt-1">{pendingGrievances}</div>
          <div className="text-[11px] text-slate-400 mt-1">
            {overdueGrievances > 0 ? (
              <span className="text-red-600 font-bold">{overdueGrievances} Overdue SLA</span>
            ) : (
              'All cases within SLA'
            )}
          </div>
        </div>

        <div className="bg-white p-4 rounded-lg border border-slate-200">
          <div className="text-xs font-medium text-slate-500">Grievance Resolution Rate</div>
          <div className="text-2xl font-bold text-emerald-700 font-mono tabular-nums mt-1">{resolutionRate}%</div>
          <div className="text-[11px] text-slate-400 mt-1 font-mono">
            {resolvedGrievances} of {totalGrievances} resolved
          </div>
        </div>

        <div className="bg-white p-4 rounded-lg border border-slate-200">
          <div className="text-xs font-medium text-slate-500">Proposals & Feedback</div>
          <div className="text-2xl font-bold text-slate-900 font-mono tabular-nums mt-1">{totalSuggestions}</div>
          <div className="text-[11px] text-slate-400 mt-1 font-mono">
            {approvedSuggestions} approved / implemented
          </div>
        </div>

        <div className="bg-white p-4 rounded-lg border border-slate-200">
          <div className="text-xs font-medium text-slate-500">Official Notices Circulated</div>
          <div className="text-2xl font-bold text-slate-900 font-mono tabular-nums mt-1">{publishedNotices}</div>
          <div className="text-[11px] text-slate-400 mt-1 font-mono">
            {halfDayNotices} half-day notices
          </div>
        </div>
      </div>

      {/* Two Column Detailed Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Grievance Status & SLA Distribution */}
        <div className="bg-white p-5 rounded-lg border border-slate-200">
          <h3 className="text-sm font-bold text-slate-900 mb-4">Grievance Redressal Status</h3>

          <div className="space-y-3">
            {[
              { label: 'Initial Advisor Review', count: grievances.filter(g => g.status === 'ADVISOR_REVIEW').length },
              { label: 'Escalated to Department HOD', count: grievances.filter(g => g.status === 'ESCALATED_HOD').length },
              { label: 'Escalated to Principal', count: grievances.filter(g => g.status === 'ESCALATED_PRINCIPAL').length },
              { label: 'Formally Resolved', count: resolvedGrievances },
            ].map(row => (
              <div key={row.label} className="flex items-center justify-between text-xs py-1.5 border-b border-slate-100 last:border-none">
                <span className="text-slate-600">{row.label}</span>
                <span className="font-mono font-bold text-slate-900 tabular-nums">{row.count}</span>
              </div>
            ))}
          </div>

          <div className="mt-5 pt-4 border-t border-slate-100 flex items-center justify-between">
            <span className="text-xs text-slate-500">Need verifiable case record?</span>
            <button
              onClick={() => {
                const { headers, rows } = reportService.formatGrievancesForExport(grievances);
                reportService.downloadCsv(`CC_Grievance_Register_${Date.now()}`, headers, rows);
              }}
              className="text-xs font-semibold text-red-600 hover:text-red-700 flex items-center gap-1"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download CSV Register</span>
            </button>
          </div>
        </div>

        {/* Suggestion & Proposal Categories */}
        <div className="bg-white p-5 rounded-lg border border-slate-200">
          <h3 className="text-sm font-bold text-slate-900 mb-4">Campus Suggestions by Category</h3>

          <div className="space-y-3">
            {[
              { label: 'Campus Infrastructure & Labs', key: 'CAMPUS_INFRASTRUCTURE' },
              { label: 'Academic Curriculum & Seminars', key: 'ACADEMIC_CURRICULUM' },
              { label: 'Library & Digital Resources', key: 'LIBRARY_RESOURCES' },
              { label: 'Hostel & Dining Facilities', key: 'HOSTEL_MESS' },
              { label: 'Sports & Cultural Activities', key: 'SPORTS_CULTURE' },
            ].map(cat => {
              const count = suggestions.filter(s => s.category === cat.key).length;
              return (
                <div key={cat.key} className="flex items-center justify-between text-xs py-1.5 border-b border-slate-100 last:border-none">
                  <span className="text-slate-600">{cat.label}</span>
                  <span className="font-mono font-bold text-slate-900 tabular-nums">{count}</span>
                </div>
              );
            })}
          </div>

          <div className="mt-5 pt-4 border-t border-slate-100 flex items-center justify-between">
            <span className="text-xs text-slate-500">Need proposal archive?</span>
            <button
              onClick={() => {
                const { headers, rows } = reportService.formatSuggestionsForExport(suggestions);
                reportService.downloadCsv(`CC_Suggestions_Register_${Date.now()}`, headers, rows);
              }}
              className="text-xs font-semibold text-red-600 hover:text-red-700 flex items-center gap-1"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download Suggestions CSV</span>
            </button>
          </div>
        </div>
      </div>

      {/* Institutional Department Audit Overview */}
      <div className="bg-white p-5 rounded-lg border border-slate-200">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-sm font-bold text-slate-900">Academic Department Breakdown</h3>
            <p className="text-xs text-slate-500">Departmental coverage and leadership assignments.</p>
          </div>
          <span className="text-xs font-mono text-slate-400">{departments.length} Academic Departments</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-700 font-semibold border-y border-slate-200">
              <tr>
                <th className="py-2.5 px-3">Code</th>
                <th className="py-2.5 px-3">Department Name</th>
                <th className="py-2.5 px-3">Head of Department</th>
                <th className="py-2.5 px-3 text-right">Classes Enrolled</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {departments.map((dept) => {
                const deptClasses = storageService.getClasses().filter(c => c.departmentId === dept.id);
                return (
                  <tr key={dept.id} className="hover:bg-slate-50/70">
                    <td className="py-2.5 px-3 font-mono font-bold text-slate-900">{dept.code}</td>
                    <td className="py-2.5 px-3 text-slate-800 font-medium">{dept.name}</td>
                    <td className="py-2.5 px-3 text-slate-600">{dept.hodName || 'Pending Assignment'}</td>
                    <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-700">{deptClasses.length}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
