import React from 'react';
import { useAuth } from '../../context/AuthContext';
import { storageService } from '../../services/storage';
import { Users, AlertCircle, Volume2, MessageSquare, ArrowUpRight, CheckCircle2 } from 'lucide-react';

interface AdvisorPortalProps {
  onNavigate: (tab: string) => void;
}

export const AdvisorPortal: React.FC<AdvisorPortalProps> = ({ onNavigate }) => {
  const { currentUser } = useAuth();
  if (!currentUser) return null;

  const classStudents = storageService.getUsers().filter(u => u.role === 'STUDENT' && u.classId === currentUser.classId);
  const classGrievances = storageService.getGrievancesForUser(currentUser);
  const classNotices = storageService.getAnnouncementsForUser(currentUser);
  const conversations = storageService.getConversationsForUser(currentUser.id);

  const pendingGrievances = classGrievances.filter(g => g.status === 'ADVISOR_REVIEW');

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="bg-white p-6 rounded-lg border border-slate-200 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs text-red-600 font-bold uppercase tracking-wider">
            <Users className="w-4 h-4" />
            <span>Class Advisory Command Desk</span>
          </div>
          <h1 className="text-xl font-bold text-slate-900 mt-1">
            {currentUser.name}
          </h1>
          <p className="text-xs text-slate-500 mt-1 font-mono">
            Class: <strong>{currentUser.className || 'Assigned Class'}</strong> · Dept: {currentUser.departmentName}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onNavigate('announcements')}
            className="px-3.5 py-2 text-xs font-bold text-white bg-red-600 hover:bg-red-700 rounded-md transition-colors shadow-xs"
          >
            Publish Class Notice
          </button>
          <button
            onClick={() => onNavigate('messages')}
            className="px-3.5 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors"
          >
            Advisory Inbox
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-lg border border-slate-200">
          <p className="text-xs text-slate-500 font-medium">Enrolled Students</p>
          <p className="text-2xl font-bold text-slate-900 font-mono tabular-nums mt-1">{classStudents.length}</p>
          <p className="text-[11px] text-slate-400 mt-1 font-mono">{currentUser.className}</p>
        </div>

        <div className="bg-white p-4 rounded-lg border border-slate-200">
          <p className="text-xs text-slate-500 font-medium">Pending Case Reviews</p>
          <p className="text-2xl font-bold text-amber-700 font-mono tabular-nums mt-1">{pendingGrievances.length}</p>
          <button
            onClick={() => onNavigate('grievances')}
            className="text-[11px] text-amber-800 font-semibold hover:underline mt-1 block"
          >
            Review Class Cases &rarr;
          </button>
        </div>

        <div className="bg-white p-4 rounded-lg border border-slate-200">
          <p className="text-xs text-slate-500 font-medium">Active Student Inquiries</p>
          <p className="text-2xl font-bold text-slate-900 font-mono tabular-nums mt-1">{conversations.length}</p>
          <p className="text-[11px] text-slate-400 mt-1 font-mono">Role-restricted threads</p>
        </div>

        <div className="bg-white p-4 rounded-lg border border-slate-200">
          <p className="text-xs text-slate-500 font-medium">Class Notices</p>
          <p className="text-2xl font-bold text-slate-900 font-mono tabular-nums mt-1">{classNotices.length}</p>
          <p className="text-[11px] text-slate-400 mt-1 font-mono">Circulars circulated</p>
        </div>
      </div>

      {/* Two Column Section: Class Grievances & Enrolled Roster */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Urgent Grievance Queue */}
        <div className="bg-white p-5 rounded-lg border border-slate-200">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-amber-600" />
              <span>Grievance Queue (Your Section)</span>
            </h3>
            <button
              onClick={() => onNavigate('grievances')}
              className="text-xs font-semibold text-red-600 hover:text-red-700"
            >
              Manage &rarr;
            </button>
          </div>

          {classGrievances.length === 0 ? (
            <p className="text-xs text-slate-400 py-6 text-center">No student grievances currently pending for this section.</p>
          ) : (
            <div className="space-y-3">
              {classGrievances.map((g) => (
                <div key={g.id} className="p-3 bg-slate-50 rounded-md border border-slate-200 text-xs">
                  <div className="flex items-center justify-between font-mono">
                    <span className="font-bold text-slate-900">{g.caseId}</span>
                    <span className="text-slate-500">Student: {g.studentName}</span>
                  </div>
                  <h4 className="text-xs font-bold text-slate-800 mt-1">{g.title}</h4>
                  <div className="flex items-center justify-between text-[11px] text-slate-500 mt-2 font-mono">
                    <span>Priority: {g.priority}</span>
                    <span className="font-semibold text-amber-800">Status: {g.status}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Enrolled Students Roster */}
        <div className="bg-white p-5 rounded-lg border border-slate-200">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Users className="w-4 h-4 text-slate-600" />
              <span>Class Roster & Quick Advisories</span>
            </h3>
            <span className="text-xs font-mono text-slate-400">{classStudents.length} Students</span>
          </div>

          <div className="divide-y divide-slate-100 max-h-72 overflow-y-auto text-xs">
            {classStudents.length === 0 ? (
              <p className="text-xs text-slate-400 py-6 text-center">No students registered in this section yet.</p>
            ) : (
              classStudents.map((s) => (
                <div key={s.id} className="py-2.5 flex items-center justify-between">
                  <div>
                    <p className="font-bold text-slate-800">{s.name}</p>
                    <p className="text-[11px] text-slate-400 font-mono">Roll: {s.rollNumber || '—'} · {s.email}</p>
                  </div>
                  <button
                    onClick={() => {
                      onNavigate('messages');
                      const msg = storageService.sendPrivateMessage(currentUser, s.id, 'Hello, do you have any advisory questions?');
                    }}
                    className="text-xs text-red-600 font-semibold hover:text-red-800"
                  >
                    Direct Message
                  </button>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
