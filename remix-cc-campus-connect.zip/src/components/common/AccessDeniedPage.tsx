import React from 'react';
import { ShieldAlert, Home, ArrowLeft, LogOut } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

interface AccessDeniedPageProps {
  requiredRole?: string;
  onNavigateHome: () => void;
  onNavigateDashboard: () => void;
}

export const AccessDeniedPage: React.FC<AccessDeniedPageProps> = ({
  requiredRole,
  onNavigateHome,
  onNavigateDashboard
}) => {
  const { currentUser, logout } = useAuth();

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col justify-center items-center px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full bg-white rounded-xl border border-red-200 p-8 shadow-xl text-center space-y-5">
        <div className="w-14 h-14 rounded-full bg-red-100 text-red-700 flex items-center justify-center mx-auto">
          <ShieldAlert className="w-8 h-8 stroke-[1.75]" />
        </div>

        <div>
          <span className="text-xs font-mono font-bold text-red-700 uppercase tracking-widest">
            HTTP 403 — ACCESS FORBIDDEN
          </span>
          <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight mt-1">
            Unauthorized Scope
          </h1>
          <p className="text-xs text-slate-600 mt-2 leading-relaxed">
            Your current authenticated account ({currentUser?.role || 'Guest'}) does not have permission to access this protected institutional area.
          </p>
          {requiredRole && (
            <div className="mt-3 p-2 bg-red-50 border border-red-200 rounded font-mono text-[11px] text-red-800">
              Required Permission: {requiredRole}
            </div>
          )}
        </div>

        <div className="pt-2 flex flex-col sm:flex-row gap-2 justify-center">
          <button
            onClick={onNavigateDashboard}
            className="px-4 py-2.5 text-xs font-bold text-white bg-red-600 hover:bg-red-700 rounded-md transition-colors flex items-center justify-center gap-1.5 shadow-xs"
          >
            <span>My Authorized Dashboard</span>
          </button>
          <button
            onClick={() => {
              logout();
              onNavigateHome();
            }}
            className="px-4 py-2.5 text-xs font-bold text-slate-700 hover:bg-slate-100 border border-slate-300 rounded-md transition-colors flex items-center justify-center gap-1.5"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Sign Out</span>
          </button>
        </div>
      </div>
    </div>
  );
};
