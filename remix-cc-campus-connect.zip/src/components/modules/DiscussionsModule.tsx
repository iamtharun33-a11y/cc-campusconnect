import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { storageService } from '../../services/storage';
import { Announcement, AnnouncementComment } from '../../types';
import { EmptyState } from '../common/EmptyState';
import { MessagesSquare, Send, ShieldAlert, Globe, MessageCircle } from 'lucide-react';

export const DiscussionsModule: React.FC = () => {
  const { currentUser, canModerateDiscussions } = useAuth();
  const [selectedAnnouncementId, setSelectedAnnouncementId] = useState<string | null>(null);
  const [commentText, setCommentText] = useState('');
  const [refreshKey, setRefreshKey] = useState(0);

  if (!currentUser) return null;

  const announcements = storageService.getAnnouncementsForUser(currentUser).filter(a => !a.isDraft);
  const activeNotice = announcements.find(a => a.id === selectedAnnouncementId) || announcements[0];

  const comments = activeNotice ? storageService.getCommentsForAnnouncement(activeNotice.id) : [];

  const handlePostComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim() || !activeNotice) return;

    storageService.addComment(activeNotice.id, currentUser, commentText);
    setCommentText('');
    setRefreshKey(prev => prev + 1);
  };

  const handleModerateComment = (commentId: string) => {
    if (!confirm('Are you sure you want to moderate/remove this comment from the public thread?')) return;
    storageService.moderateComment(commentId, currentUser);
    setRefreshKey(prev => prev + 1);
  };

  return (
    <div className="space-y-4">
      {/* Top Banner with Public Indicator Warning */}
      <div className="bg-white p-4 rounded-lg border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-slate-900 tracking-tight">Public Announcement Discussions</h1>
            <span className="px-2 py-0.5 text-[11px] font-bold bg-slate-100 text-slate-700 rounded font-mono flex items-center gap-1">
              <Globe className="w-3 h-3 text-slate-500" />
              PUBLIC FORUM
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Open academic exchange and clarifying Q&A on published institutional notices. Comments are visible to the college audience.
          </p>
        </div>

        <div className="text-xs text-amber-700 bg-amber-50 px-3 py-2 rounded-md border border-amber-200">
          <strong>Note:</strong> Not for private grievances or confidential advisories.
        </div>
      </div>

      {announcements.length === 0 ? (
        <EmptyState
          icon={MessagesSquare}
          title="No Published Announcements for Discussion"
          description="Public discussions open once official notices are circulated by the Principal or Department heads."
        />
      ) : (
        <div className="bg-white rounded-lg border border-slate-200 min-h-[580px] flex flex-col md:flex-row overflow-hidden">
          {/* Left: Notice Threads List */}
          <div className="w-full md:w-80 border-r border-slate-200 flex flex-col bg-slate-50/40">
            <div className="p-3 border-b border-slate-200 font-bold text-xs text-slate-800 uppercase tracking-wider bg-white">
              Notice Threads ({announcements.length})
            </div>
            <div className="flex-1 overflow-y-auto divide-y divide-slate-100">
              {announcements.map((ann) => {
                const isSelected = activeNotice?.id === ann.id;
                const threadComments = storageService.getCommentsForAnnouncement(ann.id);
                return (
                  <button
                    key={ann.id}
                    onClick={() => setSelectedAnnouncementId(ann.id)}
                    className={`w-full p-3 text-left transition-colors flex flex-col ${
                      isSelected ? 'bg-white border-l-2 border-red-600' : 'hover:bg-slate-100/60'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-1 text-[11px] text-slate-400 font-mono">
                      <span>{ann.category}</span>
                      <span>{ann.createdAt.split('T')[0]}</span>
                    </div>
                    <span className="text-xs font-semibold text-slate-900 truncate mt-1">{ann.title}</span>
                    <div className="flex items-center gap-1 text-[11px] text-slate-500 mt-1 font-mono">
                      <MessageCircle className="w-3 h-3 text-slate-400" />
                      <span>{threadComments.length} comments</span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Right: Active Notice & Discussion Feed */}
          <div className="flex-1 flex flex-col bg-white">
            {activeNotice && (
              <>
                {/* Notice Context Header */}
                <div className="p-4 border-b border-slate-200 bg-slate-50/50">
                  <div className="flex items-center gap-2 text-xs text-slate-500">
                    <span className="font-semibold text-slate-800">{activeNotice.category}</span>
                    <span aria-hidden="true">·</span>
                    <span>Publisher: {activeNotice.publisherName} ({activeNotice.publisherRole})</span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono">{activeNotice.createdAt.split('T')[0]}</span>
                  </div>
                  <h2 className="text-sm font-bold text-slate-900 mt-1">{activeNotice.title}</h2>
                  <p className="text-xs text-slate-600 mt-1.5 leading-relaxed bg-white p-3 rounded border border-slate-200">
                    {activeNotice.content}
                  </p>
                </div>

                {/* Public Comments Feed */}
                <div className="flex-1 overflow-y-auto p-4 space-y-3">
                  <div className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                    Public Discussion Feed ({comments.length})
                  </div>

                  {comments.length === 0 ? (
                    <div className="p-8 text-center text-xs text-slate-400">
                      No comments have been posted to this announcement thread yet. Be the first to start the discussion below.
                    </div>
                  ) : (
                    comments.map((cmt) => (
                      <div key={cmt.id} className="p-3 bg-slate-50 rounded-md border border-slate-200">
                        <div className="flex items-center justify-between text-xs">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-slate-900">{cmt.userName}</span>
                            <span className="text-[10px] font-mono text-slate-500">({cmt.userRole})</span>
                            <span aria-hidden="true" className="text-slate-300">·</span>
                            <span className="text-[11px] text-slate-400 font-mono">
                              {new Date(cmt.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </span>
                          </div>

                          {canModerateDiscussions && (
                            <button
                              onClick={() => handleModerateComment(cmt.id)}
                              className="text-[11px] text-red-600 hover:text-red-800 flex items-center gap-1"
                              title="Moderate/Remove comment"
                            >
                              <ShieldAlert className="w-3 h-3" />
                              <span>Moderate</span>
                            </button>
                          )}
                        </div>
                        <p className="text-xs text-slate-700 mt-1.5 leading-relaxed">{cmt.content}</p>
                      </div>
                    ))
                  )}
                </div>

                {/* Comment Composer */}
                <form onSubmit={handlePostComment} className="p-3 border-t border-slate-200 bg-white flex items-center gap-2">
                  <input
                    type="text"
                    value={commentText}
                    onChange={(e) => setCommentText(e.target.value)}
                    placeholder="Contribute a public comment or inquiry regarding this announcement..."
                    className="flex-1 text-xs p-2.5 rounded-md border border-slate-300 focus:border-red-600 focus:outline-hidden"
                  />
                  <button
                    type="submit"
                    disabled={!commentText.trim()}
                    className="px-3.5 py-2.5 bg-red-600 hover:bg-red-700 disabled:opacity-40 text-white text-xs font-semibold rounded-md transition-colors flex items-center gap-1.5"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Post Comment</span>
                  </button>
                </form>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
