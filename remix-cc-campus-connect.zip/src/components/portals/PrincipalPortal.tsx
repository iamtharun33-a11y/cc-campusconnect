import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { storageService } from '../../services/storage';
import { Grievance, Department, User } from '../../types';
import {
  ShieldCheck,
  AlertCircle,
  Building,
  Volume2,
  FileSpreadsheet,
  Download,
  Clock,
  Users,
  Send,
  Calendar,
  CheckCircle2,
  XCircle,
  ArrowRight,
  Database,
  UserPlus,
  LogOut,
  X,
  MessageSquare
} from 'lucide-react';

interface PrincipalPortalProps {
  onNavigate: (tab: string) => void;
  onOpenExport: () => void;
}

export const PrincipalPortal: React.FC<PrincipalPortalProps> = ({ onNavigate, onOpenExport }) => {
  const { currentUser, logout } = useAuth();
  const [adjudicateGrievance, setAdjudicateGrievance] = useState<Grievance | null>(null);
  const [adjudicationAction, setAdjudicationAction] = useState<'RESOLVE' | 'RETURN_HOD'>('RESOLVE');
  const [adjudicationText, setAdjudicationText] = useState('');
  const [showProfileModal, setShowProfileModal] = useState(false);

  if (!currentUser) return null;

  const allUsers = storageService.getUsers();
  const allStudents = allUsers.filter(u => u.role === 'STUDENT');
  const allFaculty = allUsers.filter(u => u.role === 'ADVISOR' || u.role === 'HOD');
  const allGrievances = storageService.getGrievances();
  const allSuggestions = storageService.getSuggestions();
  const departments = storageService.getDepartments();

  const escalatedToPrincipal = allGrievances.filter(g => g.status === 'ESCALATED_PRINCIPAL');
  const activeGrievances = allGrievances.filter(g => g.status !== 'RESOLVED' && g.status !== 'REJECTED');
  const overdueCases = allGrievances.filter(g => g.isOverdue);

  const handleConfirmAdjudication = () => {
    if (!adjudicateGrievance || !adjudicationText.trim()) return;

    if (adjudicationAction === 'RESOLVE') {
      storageService.resolveGrievance(adjudicateGrievance.id, currentUser, adjudicationText.trim());
    } else {
      storageService.returnGrievanceToHod(adjudicateGrievance.id, currentUser, adjudicationText.trim());
    }

    setAdjudicateGrievance(null);
    setAdjudicationText('');
  };

  return (
    <div className="space-y-6">
      {/* 1. Principal Executive Command Banner */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs text-red-600 font-bold uppercase tracking-wider">
            <ShieldCheck className="w-4 h-4" />
            <span>Office of the Principal · Supreme Collegiate Executive Authority</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 mt-1 tracking-tight">
            {currentUser.name}
          </h1>
          <p className="text-xs text-slate-500 mt-1 font-mono">
            Employee ID: <strong className="text-slate-800">{currentUser.employeeId || 'EMP-PRIN-001'}</strong> · College Executive Leadership
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => onNavigate('announcements')}
            className="px-3.5 py-2 text-xs font-bold text-white bg-red-600 hover:bg-red-700 rounded-lg transition-colors flex items-center gap-1.5 shadow-xs"
          >
            <Send className="w-3.5 h-3.5" />
            <span>Broadcast College Notice</span>
          </button>

          <button
            onClick={onOpenExport}
            className="px-3.5 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors flex items-center gap-1.5 border border-slate-200"
          >
            <Download className="w-3.5 h-3.5 text-slate-500" />
            <span>Executive Reports</span>
          </button>

          <button
            onClick={() => onNavigate('system')}
            className="px-3.5 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors flex items-center gap-1.5 border border-slate-200"
          >
            <Database className="w-3.5 h-3.5 text-slate-500" />
            <span>Governance & Audits</span>
          </button>

          <button
            onClick={() => setShowProfileModal(true)}
            className="px-3 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-slate-50 hover:bg-slate-100 rounded-lg transition-colors border border-slate-200"
          >
            Principal Profile
          </button>
        </div>
      </div>

      {/* 2. College Institutional KPI Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="bg-white p-3.5 rounded-xl border border-slate-200">
          <p className="text-[11px] text-slate-500 font-medium">Departments</p>
          <p className="text-xl font-bold text-slate-900 font-mono tabular-nums mt-1">{departments.length}</p>
          <p className="text-[10px] text-slate-400 mt-0.5">Governed units</p>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-slate-200">
          <p className="text-[11px] text-slate-500 font-medium">College Students</p>
          <p className="text-xl font-bold text-slate-900 font-mono tabular-nums mt-1">{allStudents.length}</p>
          <p className="text-[10px] text-slate-400 mt-0.5">Enrolled campus-wide</p>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-slate-200">
          <p className="text-[11px] text-slate-500 font-medium">Faculty & HODs</p>
          <p className="text-xl font-bold text-slate-900 font-mono tabular-nums mt-1">{allFaculty.length}</p>
          <p className="text-[10px] text-slate-400 mt-0.5">Academic staff</p>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-slate-200">
          <p className="text-[11px] text-red-600 font-medium">Supreme Cases</p>
          <p className="text-xl font-bold text-red-700 font-mono tabular-nums mt-1">{escalatedToPrincipal.length}</p>
          <p className="text-[10px] text-red-600 font-semibold mt-0.5">Pending ruling</p>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-slate-200">
          <p className="text-[11px] text-slate-500 font-medium">Active Petitions</p>
          <p className="text-xl font-bold text-slate-900 font-mono tabular-nums mt-1">{activeGrievances.length}</p>
          <p className="text-[10px] text-amber-600 font-medium mt-0.5">{overdueCases.length} overdue SLA</p>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-slate-200">
          <p className="text-[11px] text-slate-500 font-medium">Proposals & Feedback</p>
          <p className="text-xl font-bold text-slate-900 font-mono tabular-nums mt-1">{allSuggestions.length}</p>
          <p className="text-[10px] text-slate-400 mt-0.5">Campus initiatives</p>
        </div>
      </div>

      {/* 3. Two Column Grid: Supreme Adjudication Queue & Department Leadership */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Supreme Escalation Grievance Queue */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-red-600" />
              <span>Grievances Escalated to Principal</span>
            </h3>
            <button
              onClick={() => onNavigate('grievances')}
              className="text-xs font-semibold text-red-600 hover:text-red-700"
            >
              All Grievances &rarr;
            </button>
          </div>

          {escalatedToPrincipal.length === 0 ? (
            <div className="py-8 text-center text-slate-400 text-xs">
              <CheckCircle2 className="w-8 h-8 mx-auto text-emerald-500 mb-2 opacity-80" />
              <p className="font-semibold text-slate-700">No Supreme Cases Pending</p>
              <p className="text-[11px] mt-0.5">No grievance petitions currently require executive ruling by the Principal.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {escalatedToPrincipal.map((g) => (
                <div key={g.id} className="p-3.5 bg-red-50/50 rounded-xl border border-red-200 text-xs">
                  <div className="flex items-center justify-between font-mono">
                    <span className="font-bold text-slate-900">{g.caseId}</span>
                    <span className="text-red-700 font-bold uppercase">{g.priority} PRIORITY</span>
                  </div>
                  <h4 className="font-bold text-slate-800 mt-1">{g.title}</h4>
                  <p className="text-slate-600 text-[11px] mt-1 leading-relaxed">{g.description}</p>
                  
                  {g.escalationReason && (
                    <div className="mt-2 p-2 bg-white rounded border border-red-200 text-[11px] text-red-900">
                      <strong>HOD Escalation Note:</strong> {g.escalationReason}
                    </div>
                  )}

                  <div className="flex items-center justify-between text-[11px] text-slate-500 mt-3 pt-2 border-t border-red-100 font-mono">
                    <span>Dept: {g.departmentName} · Student: {g.studentName}</span>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => {
                          setAdjudicateGrievance(g);
                          setAdjudicationAction('RETURN_HOD');
                          setAdjudicationText('');
                        }}
                        className="text-amber-800 font-semibold hover:underline"
                      >
                        Return to HOD
                      </button>
                      <button
                        onClick={() => {
                          setAdjudicateGrievance(g);
                          setAdjudicationAction('RESOLVE');
                          setAdjudicationText('');
                        }}
                        className="px-2.5 py-1 text-xs font-bold text-white bg-red-600 hover:bg-red-700 rounded shadow-xs"
                      >
                        Executive Ruling
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Academic Departments Leadership Roster */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Building className="w-4 h-4 text-slate-700" />
              <span>Departmental Leadership & Head Oversight</span>
            </h3>
            <button
              onClick={() => onNavigate('messages')}
              className="text-xs font-semibold text-red-600 hover:text-red-700"
            >
              Message HODs &rarr;
            </button>
          </div>

          <div className="divide-y divide-slate-100 max-h-80 overflow-y-auto text-xs">
            {departments.map((dept) => {
              const deptStudentsCount = allStudents.filter(s => s.departmentId === dept.id).length;
              return (
                <div key={dept.id} className="py-3 flex items-center justify-between">
                  <div>
                    <p className="font-bold text-slate-800">{dept.name}</p>
                    <p className="text-[11px] text-slate-500">
                      HOD: <strong>{dept.hodName || 'Dr. Aruna Ramanathan'}</strong> · Code: <span className="font-mono">{dept.code}</span> · {deptStudentsCount} Students
                    </p>
                  </div>
                  <button
                    onClick={() => onNavigate('messages')}
                    className="px-2.5 py-1 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded border border-slate-200 flex items-center gap-1 transition-colors"
                  >
                    <MessageSquare className="w-3 h-3 text-slate-500" />
                    <span>Contact</span>
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* ADJUDICATION MODAL */}
      {adjudicateGrievance && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-white rounded-xl shadow-xl border border-slate-200 p-6">
            <div className="flex items-center gap-2 text-red-600 font-bold text-xs uppercase">
              <ShieldCheck className="w-4 h-4" />
              <span>{adjudicationAction === 'RESOLVE' ? 'Executive Resolution Decree' : 'Remand Case to HOD'}</span>
            </div>
            <h3 className="text-base font-bold text-slate-900 mt-1">
              Case {adjudicateGrievance.caseId}
            </h3>
            <p className="text-xs text-slate-600 mt-1">{adjudicateGrievance.title}</p>

            <div className="mt-4 space-y-3 text-xs">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setAdjudicationAction('RESOLVE')}
                  className={`flex-1 py-1.5 px-3 rounded text-xs font-semibold border ${
                    adjudicationAction === 'RESOLVE'
                      ? 'bg-red-50 text-red-700 border-red-300'
                      : 'bg-white text-slate-600 border-slate-200'
                  }`}
                >
                  Final Resolution
                </button>
                <button
                  type="button"
                  onClick={() => setAdjudicationAction('RETURN_HOD')}
                  className={`flex-1 py-1.5 px-3 rounded text-xs font-semibold border ${
                    adjudicationAction === 'RETURN_HOD'
                      ? 'bg-amber-50 text-amber-800 border-amber-300'
                      : 'bg-white text-slate-600 border-slate-200'
                  }`}
                >
                  Remand to HOD
                </button>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  {adjudicationAction === 'RESOLVE' ? 'Official Executive Decree / Settlement Terms *' : 'Directive Instructions for HOD Reinvestigation *'}
                </label>
                <textarea
                  rows={4}
                  required
                  value={adjudicationText}
                  onChange={(e) => setAdjudicationText(e.target.value)}
                  placeholder="Enter the official decree from the Office of the Principal..."
                  className="w-full p-2.5 rounded-lg border border-slate-300 focus:border-red-600 focus:outline-hidden"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setAdjudicateGrievance(null)}
                  className="px-3.5 py-2 font-medium text-slate-600 hover:text-slate-900"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleConfirmAdjudication}
                  className="px-4 py-2 font-bold text-white bg-red-600 hover:bg-red-700 rounded-lg shadow-xs"
                >
                  {adjudicationAction === 'RESOLVE' ? 'Issue Final Ruling' : 'Dispatch Directives to HOD'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* PRINCIPAL PROFILE MODAL */}
      {showProfileModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-white rounded-xl shadow-xl border border-slate-200 p-6">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-red-600" />
                <h3 className="text-base font-bold text-slate-900">Principal Executive Profile</h3>
              </div>
              <button
                onClick={() => setShowProfileModal(false)}
                className="p-1 text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="mt-4 space-y-3 text-xs">
              <div className="flex items-center justify-between py-1.5 border-b border-slate-100">
                <span className="text-slate-500">Principal Name</span>
                <span className="font-bold text-slate-900">{currentUser.name}</span>
              </div>
              <div className="flex items-center justify-between py-1.5 border-b border-slate-100">
                <span className="text-slate-500">Designation</span>
                <span className="font-mono font-bold text-red-700">HEAD OF INSTITUTION / PRINCIPAL</span>
              </div>
              <div className="flex items-center justify-between py-1.5 border-b border-slate-100">
                <span className="text-slate-500">Employee ID</span>
                <span className="font-mono text-slate-700">{currentUser.employeeId || 'EMP-PRIN-001'}</span>
              </div>
              <div className="flex items-center justify-between py-1.5 border-b border-slate-100">
                <span className="text-slate-500">Official Email</span>
                <span className="font-mono text-slate-700">{currentUser.email}</span>
              </div>
              <div className="flex items-center justify-between py-1.5">
                <span className="text-slate-500">Session Status</span>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-50 text-emerald-800 border border-emerald-200">
                  Supreme Executive Session Active
                </span>
              </div>

              <div className="pt-4 mt-2 border-t border-slate-200 flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => setShowProfileModal(false)}
                  className="px-3.5 py-2 font-medium text-slate-600 hover:text-slate-800"
                >
                  Close
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowProfileModal(false);
                    logout();
                    window.location.href = '/';
                  }}
                  className="px-4 py-2 font-bold text-red-700 hover:text-white hover:bg-red-600 border border-red-200 hover:border-red-600 rounded-lg transition-colors flex items-center gap-1.5"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Secure Sign Out</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
