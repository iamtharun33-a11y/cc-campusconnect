export type UserRole = 'STUDENT' | 'ADVISOR' | 'HOD' | 'PRINCIPAL';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  passwordHash: string;
  salt: string;
  departmentId?: string;
  departmentName?: string;
  classId?: string;
  className?: string;
  rollNumber?: string; // Student register number
  employeeId?: string; // Faculty staff ID
  course?: string; // Program / Degree (e.g. B.Tech, B.E., M.Tech, MCA, MBA)
  academicBatch?: string; // Academic admission batch (e.g. 2023-2027)
  year?: string;
  semester?: number;
  section?: string; // Section (e.g. Section A, Section B, Section C, Custom)
  phone?: string;
  isActive: boolean;
  failedLoginAttempts?: number;
  lockedUntil?: string | null;
  createdAt: string;
}

export interface Department {
  id: string;
  name: string;
  code: string;
  hodId?: string;
  hodName?: string;
}

export interface CollegeClass {
  id: string;
  departmentId: string;
  name: string; // e.g. "Year 3 - CSE Section A"
  semester: number;
  advisorId?: string;
  advisorName?: string;
}

export type NoticeAudience = 'COLLEGE_WIDE' | 'DEPARTMENT' | 'CLASS';
export type NoticeCategory = 'ACADEMIC' | 'HALF_DAY' | 'EXAMINATION' | 'TIMETABLE' | 'HOLIDAY' | 'ADMINISTRATIVE' | 'URGENT';
export type NoticePriority = 'NORMAL' | 'HIGH' | 'URGENT';

export interface Announcement {
  id: string;
  title: string;
  content: string;
  category: NoticeCategory;
  priority: NoticePriority;
  audience: NoticeAudience;
  targetDepartmentId?: string;
  targetDepartmentName?: string;
  targetClassId?: string;
  targetClassName?: string;
  publisherId: string;
  publisherName: string;
  publisherRole: UserRole;
  isDraft: boolean;
  isArchived: boolean;
  isHalfDayNotice?: boolean;
  effectiveDate?: string;
  startTime?: string;
  endTime?: string;
  requiresAcknowledgement?: boolean;
  acknowledgements?: string[];
  createdAt: string;
  updatedAt: string;
}

export interface AnnouncementComment {
  id: string;
  announcementId: string;
  userId: string;
  userName: string;
  userRole: UserRole;
  content: string;
  isModerated?: boolean;
  createdAt: string;
}

export interface Conversation {
  id: string;
  participantIds: string[];
  participantNames: string[];
  participantRoles: UserRole[];
  lastMessageSnippet: string;
  lastMessageAt: string;
  unreadCountByUser: Record<string, number>;
  createdAt: string;
}

export interface PrivateMessage {
  id: string;
  conversationId: string;
  senderId: string;
  senderName: string;
  senderRole: UserRole;
  recipientId: string;
  content: string;
  isRead: boolean;
  createdAt: string;
}

export type SuggestionStatus = 'SUBMITTED' | 'UNDER_REVIEW' | 'ACCEPTED' | 'REJECTED' | 'IMPLEMENTED' | 'CLOSED';
export type SuggestionCategory = 'CAMPUS_INFRASTRUCTURE' | 'ACADEMIC_CURRICULUM' | 'LIBRARY_RESOURCES' | 'HOSTEL_MESS' | 'SPORTS_CULTURE' | 'OTHER';

export interface FollowUpRequest {
  id: string;
  caseId: string; // References Grievance ID or Suggestion Ref
  caseType: 'GRIEVANCE' | 'SUGGESTION';
  caseTitle: string;
  senderId: string;
  senderName: string;
  senderRole: 'HOD' | 'PRINCIPAL';
  recipientId: string;
  recipientName: string;
  recipientRole: 'ADVISOR' | 'HOD';
  departmentId: string;
  departmentName: string;
  pendingIssue: string; // Reason or action that is pending
  responseDeadline: string; // Required date for explanation / update
  requestedAction: string; // Directive from HOD or Principal
  status: 'PENDING_EXPLANATION' | 'REPLIED' | 'ACTION_IN_PROGRESS' | 'RESOLVED';
  
  // Follow-up Response:
  delayReason?: string; // Reason for delay if any
  statusUpdate?: string;
  correctiveActionPlan?: string;
  expectedCompletionDate?: string;
  repliedAt?: string;
  createdAt: string;
}

export interface Suggestion {
  id: string;
  referenceNo: string;
  title: string;
  description: string;
  category: SuggestionCategory;
  status: SuggestionStatus;
  isAnonymous: boolean;
  studentId: string;
  studentName?: string;
  departmentId: string;
  departmentName: string;
  reviewerId?: string;
  reviewerName?: string;
  reviewerRole?: UserRole;
  internalNotes?: string;
  officialResponse?: string;
  followUpRequests?: FollowUpRequest[];
  createdAt: string;
  updatedAt: string;
}

export type GrievanceStatus = 'SUBMITTED' | 'ADVISOR_REVIEW' | 'ESCALATED_HOD' | 'ESCALATED_PRINCIPAL' | 'RESOLVED' | 'REJECTED';
export type GrievancePriority = 'NORMAL' | 'HIGH' | 'CRITICAL';
export type GrievanceCategory = 'ACADEMIC' | 'FACULTY' | 'DISCIPLINARY' | 'HOSTEL' | 'ADMINISTRATION' | 'HARASSMENT_RAGGING' | 'OTHER';

export interface GrievanceTimelineItem {
  id: string;
  actorId: string;
  actorName: string;
  actorRole: UserRole;
  action: string;
  comment?: string;
  timestamp: string;
}

export interface Grievance {
  id: string;
  caseId: string;
  title: string;
  description: string;
  category: GrievanceCategory;
  priority: GrievancePriority;
  status: GrievanceStatus;
  studentId: string;
  studentName: string;
  departmentId: string;
  departmentName: string;
  classId: string;
  className: string;
  currentAssigneeRole: UserRole;
  currentAssigneeId?: string;
  currentAssigneeName?: string;
  assignedAdvisorId?: string;
  assignedAdvisorName?: string;
  dueDate: string;
  isOverdue: boolean;
  escalationReason?: string;
  internalNotes?: string;
  resolutionSummary?: string;
  timeline: GrievanceTimelineItem[];
  followUpRequests?: FollowUpRequest[];
  createdAt: string;
  resolvedAt?: string;
}

export interface NotificationItem {
  id: string;
  userId: string;
  title: string;
  message: string;
  senderName?: string;
  senderRole?: UserRole;
  type: 'MESSAGE' | 'ANNOUNCEMENT' | 'GRIEVANCE' | 'SUGGESTION' | 'FOLLOW_UP' | 'SYSTEM';
  linkTarget?: {
    module: 'messages' | 'announcements' | 'grievances' | 'suggestions' | 'discussions' | 'follow_ups';
    id?: string;
  };
  isRead: boolean;
  createdAt: string;
}

export interface AuditLog {
  id: string;
  userId: string;
  userName: string;
  userRole: UserRole;
  action: string;
  targetResource: string;
  details: string;
  timestamp: string;
}
