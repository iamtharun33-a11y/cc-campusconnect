import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Header } from './components/layout/Header';
import { Sidebar } from './components/layout/Sidebar';
import { LandingPage } from './components/landing/LandingPage';
import { StudentPortal } from './components/portals/StudentPortal';
import { AdvisorPortal } from './components/portals/AdvisorPortal';
import { HodPortal } from './components/portals/HodPortal';
import { PrincipalPortal } from './components/portals/PrincipalPortal';
import { AnnouncementsModule } from './components/modules/AnnouncementsModule';
import { MessagingModule } from './components/modules/MessagingModule';
import { DiscussionsModule } from './components/modules/DiscussionsModule';
import { GrievancesModule } from './components/modules/GrievancesModule';
import { SuggestionsModule } from './components/modules/SuggestionsModule';
import { ReportsModule } from './components/modules/ReportsModule';
import { SystemGovernanceModule } from './components/modules/SystemGovernanceModule';
import { GlobalSearchModal } from './components/common/GlobalSearchModal';
import { NotificationCenter } from './components/common/NotificationCenter';
import { ExportModal } from './components/common/ExportModal';
import { NotFoundPage } from './components/common/NotFoundPage';
import { AccessDeniedPage } from './components/common/AccessDeniedPage';
import { UserRole } from './types';
import { X } from 'lucide-react';

interface ParsedRoute {
  type: 'landing' | 'portal_access' | 'login' | 'register' | 'dashboard' | 'not_found';
  role?: UserRole;
  tab?: string;
  rawPath: string;
}

function parseBrowserUrl(): ParsedRoute {
  const pathname = window.location.pathname.toLowerCase();
  const searchParams = new URLSearchParams(window.location.search);
  const portalParam = searchParams.get('portal')?.toUpperCase() as UserRole | undefined;
  const tabParam = searchParams.get('tab') || 'overview';

  // Normalize path without trailing slash
  const clean = pathname === '/' ? '/' : pathname.replace(/\/+$/, '');

  if (clean === '' || clean === '/' || clean === '/home') {
    return { type: 'landing', rawPath: pathname };
  }

  if (clean === '/portals' || clean === '/four-portal-access' || clean === '/portal-access') {
    return { type: 'portal_access', rawPath: pathname };
  }

  // Login routes
  if (clean === '/login') {
    return { type: 'login', role: portalParam || 'STUDENT', rawPath: pathname };
  }
  if (clean.startsWith('/login/')) {
    const roleSlug = clean.replace('/login/', '');
    let role: UserRole = 'STUDENT';
    if (roleSlug === 'faculty' || roleSlug === 'advisor') role = 'ADVISOR';
    else if (roleSlug === 'hod' || roleSlug === 'head-of-department') role = 'HOD';
    else if (roleSlug === 'principal') role = 'PRINCIPAL';
    else if (roleSlug === 'admin' || roleSlug === 'management') role = 'PRINCIPAL';
    return { type: 'login', role, rawPath: pathname };
  }

  // Register routes
  if (clean === '/register') {
    return { type: 'register', role: portalParam || 'STUDENT', rawPath: pathname };
  }
  if (clean.startsWith('/register/')) {
    const roleSlug = clean.replace('/register/', '');
    let role: UserRole = 'STUDENT';
    if (roleSlug === 'faculty' || roleSlug === 'advisor') role = 'ADVISOR';
    else if (roleSlug === 'hod' || roleSlug === 'head-of-department') role = 'HOD';
    else if (roleSlug === 'principal') role = 'PRINCIPAL';
    return { type: 'register', role, rawPath: pathname };
  }

  // Dashboard / Portal routes
  if (clean === '/dashboard' || clean === '/portal') {
    return { type: 'dashboard', tab: tabParam, rawPath: pathname };
  }
  if (clean.startsWith('/dashboard/')) {
    const tab = clean.replace('/dashboard/', '');
    return { type: 'dashboard', tab, rawPath: pathname };
  }

  return { type: 'not_found', rawPath: pathname };
}

const MainApplication: React.FC = () => {
  const { currentUser, isLoading } = useAuth();
  const [route, setRoute] = useState<ParsedRoute>(parseBrowserUrl());
  const [activeTab, setActiveTab] = useState<string>('overview');

  // Modals & mobile drawer
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [isExportOpen, setIsExportOpen] = useState(false);
  const [isMobileNavOpen, setIsMobileNavOpen] = useState(false);

  // Sync route on popstate (browser back/forward)
  useEffect(() => {
    const onPopState = () => {
      const parsed = parseBrowserUrl();
      setRoute(parsed);
      if (parsed.tab) setActiveTab(parsed.tab);
    };
    window.addEventListener('popstate', onPopState);
    return () => window.removeEventListener('popstate', onPopState);
  }, []);

  const navigateTo = (path: string, replace = false) => {
    if (replace) {
      window.history.replaceState({}, '', path);
    } else {
      window.history.pushState({}, '', path);
    }
    const parsed = parseBrowserUrl();
    setRoute(parsed);
    if (parsed.tab) setActiveTab(parsed.tab);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <div className="w-10 h-10 border-3 border-red-600 border-t-transparent rounded-full animate-spin" />
          <p className="text-xs font-mono font-semibold text-slate-500">Loading CC Campus Connect...</p>
        </div>
      </div>
    );
  }

  // 1. Genuine 404 Route Not Found Page (Requirement 1.B)
  if (route.type === 'not_found') {
    return (
      <NotFoundPage
        currentPath={route.rawPath}
        onNavigateHome={() => navigateTo('/')}
        onNavigatePortals={() => navigateTo('/portals')}
      />
    );
  }

  // 2. If authenticated user attempts to visit public login/register/portals, redirect them to dashboard
  if (currentUser && (route.type === 'landing' || route.type === 'portal_access' || route.type === 'login' || route.type === 'register')) {
    // Keep user in their authorized dashboard
    return renderAuthenticatedDashboard();
  }

  // 3. If unauthenticated user attempts to visit dashboard directly, redirect to login
  if (!currentUser && route.type === 'dashboard') {
    return (
      <LandingPage
        initialView="portal_login"
        initialPortalRole="STUDENT"
        onEnterPortal={() => navigateTo('/dashboard')}
        onUpdateRoute={(p) => navigateTo(p)}
      />
    );
  }

  // 4. Public views: Landing, Portals Access, Portal Login, Portal Register
  if (!currentUser) {
    let initialView: 'home' | 'portal_access' | 'portal_login' | 'portal_register' = 'home';
    if (route.type === 'portal_access') initialView = 'portal_access';
    else if (route.type === 'login') initialView = 'portal_login';
    else if (route.type === 'register') initialView = 'portal_register';

    return (
      <LandingPage
        initialView={initialView}
        initialPortalRole={route.role || 'STUDENT'}
        onEnterPortal={() => navigateTo('/dashboard')}
        onUpdateRoute={(p) => navigateTo(p)}
      />
    );
  }

  // 5. Authenticated Dashboard Function
  function renderAuthenticatedDashboard() {
    if (!currentUser) return null;

    const renderActiveModule = () => {
      switch (activeTab) {
        case 'overview': {
          switch (currentUser.role) {
            case 'STUDENT':
              return <StudentPortal onNavigate={(tab) => { setActiveTab(tab); navigateTo(`/dashboard?tab=${tab}`); }} />;
            case 'ADVISOR':
              return <AdvisorPortal onNavigate={(tab) => { setActiveTab(tab); navigateTo(`/dashboard?tab=${tab}`); }} />;
            case 'HOD':
              return <HodPortal onNavigate={(tab) => { setActiveTab(tab); navigateTo(`/dashboard?tab=${tab}`); }} onOpenExport={() => setIsExportOpen(true)} />;
            case 'PRINCIPAL':
              return <PrincipalPortal onNavigate={(tab) => { setActiveTab(tab); navigateTo(`/dashboard?tab=${tab}`); }} onOpenExport={() => setIsExportOpen(true)} />;
            default:
              return <StudentPortal onNavigate={(tab) => { setActiveTab(tab); navigateTo(`/dashboard?tab=${tab}`); }} />;
          }
        }
        case 'announcements':
          return <AnnouncementsModule />;
        case 'messages':
          return <MessagingModule />;
        case 'discussions':
          return <DiscussionsModule />;
        case 'grievances':
          return <GrievancesModule />;
        case 'suggestions':
          return <SuggestionsModule />;
        case 'reports':
          return <ReportsModule onOpenExportModal={() => setIsExportOpen(true)} />;
        case 'system':
          if (currentUser.role === 'STUDENT' || currentUser.role === 'ADVISOR') {
            return (
              <AccessDeniedPage
                requiredRole="Principal or Department Head"
                onNavigateHome={() => navigateTo('/')}
                onNavigateDashboard={() => { setActiveTab('overview'); navigateTo('/dashboard'); }}
              />
            );
          }
          return <SystemGovernanceModule />;
        default:
          return <AnnouncementsModule />;
      }
    };

    return (
      <div className="min-h-screen bg-slate-50 flex flex-col font-sans text-slate-900">
        <Header
          onOpenSearch={() => setIsSearchOpen(true)}
          onOpenNotifications={() => setIsNotificationsOpen(true)}
          onOpenExport={() => setIsExportOpen(true)}
          onNavigateHome={() => navigateTo('/')}
          onToggleMobileNav={() => setIsMobileNavOpen(!isMobileNavOpen)}
        />

        <div className="flex-1 flex max-w-7xl w-full mx-auto relative">
          {/* Desktop Sidebar */}
          <div className="hidden lg:block">
            <Sidebar
              activeTab={activeTab}
              onSelectTab={(tab) => {
                setActiveTab(tab);
                navigateTo(`/dashboard?tab=${tab}`);
              }}
            />
          </div>

          {/* Mobile Navigation Drawer */}
          {isMobileNavOpen && (
            <div className="fixed inset-0 z-50 lg:hidden bg-slate-900/40 backdrop-blur-xs flex">
              <div className="w-64 bg-white h-full shadow-2xl flex flex-col">
                <div className="p-4 border-b border-slate-200 flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                    Navigation Menu
                  </span>
                  <button
                    onClick={() => setIsMobileNavOpen(false)}
                    className="p-1 text-slate-400 hover:text-slate-700 rounded"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
                <div className="flex-1 overflow-y-auto">
                  <Sidebar
                    activeTab={activeTab}
                    onSelectTab={(tab) => {
                      setActiveTab(tab);
                      navigateTo(`/dashboard?tab=${tab}`);
                      setIsMobileNavOpen(false);
                    }}
                  />
                </div>
              </div>
            </div>
          )}

          {/* Main Content Viewport */}
          <main className="flex-1 p-4 sm:p-6 lg:p-8 min-w-0 overflow-y-auto">
            {renderActiveModule()}
          </main>
        </div>

        {/* Global Modals */}
        <GlobalSearchModal
          isOpen={isSearchOpen}
          onClose={() => setIsSearchOpen(false)}
          onSelectResult={(module) => {
            setActiveTab(module);
            navigateTo(`/dashboard?tab=${module}`);
          }}
        />

        <NotificationCenter
          isOpen={isNotificationsOpen}
          onClose={() => setIsNotificationsOpen(false)}
          onNavigate={(module) => {
            setActiveTab(module);
            navigateTo(`/dashboard?tab=${module}`);
          }}
        />

        <ExportModal
          isOpen={isExportOpen}
          onClose={() => setIsExportOpen(false)}
          defaultModule={activeTab === 'suggestions' ? 'suggestions' : activeTab === 'announcements' ? 'announcements' : 'grievances'}
        />
      </div>
    );
  }

  return renderAuthenticatedDashboard();
};

export default function App() {
  return (
    <AuthProvider>
      <MainApplication />
    </AuthProvider>
  );
}
