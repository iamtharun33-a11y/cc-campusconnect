import React from 'react';
import { useAuth } from '../../context/AuthContext';
import { storageService } from '../../services/storage';
import { EmptyState } from '../common/EmptyState';
import {
  GraduationCap,
  Volume2,
  MessageSquare,
  AlertCircle,
  Lightbulb,
  CheckCircle2,
  Clock,
  ArrowRight,
  ShieldCheck
} from 'lucide-react';

interface StudentPortalProps {
  onNavigate: (tab: string) => void;
}

export const StudentPortal: React.FC<StudentPortalProps> = ({ onNavigate }) => {
  const { currentUser } = useAuth();
  if (!currentUser) return null;

  const notices = storageService.getAnnouncementsForUser(currentUser).slice(0, 3);
  const grievances = storageService.getGrievancesForUser(currentUser);
  const suggestions = storageService.getSuggestionsForUser(currentUser);
  const conversations = storageService.getConversationsForUser(currentUser.id);

  // Class Advisor
  const allowedRecipients = storageService.getAuthorizedRecipientsForUser(currentUser);
  const assignedAdvisor = allowedRecipients.find(r => r.role === 'ADVISOR');

  return (
    <div className="space-y-6">
      {/* Student Welcome Card */}
      <div className="bg-white p-6 rounded-lg border border-slate-200 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs text-red-600 font-bold uppercase tracking-wider">
            <GraduationCap className="w-4 h-4" />
            <span>Enrolled Student Portal</span>
          </div>
          <h1 className="text-xl font-bold text-slate-900 mt-1">
            Welcome back, {currentUser.name}
          </h1>
          <p className="text-xs text-slate-500 mt-1 font-mono">
            Roll No: <strong>{currentUser.rollNumber || '21CS1042'}</strong> · Class: {currentUser.className} · {currentUser.departmentName}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onNavigate('grievances')}
            className="px-3.5 py-2 text-xs font-semibold text-amber-800 bg-amber-50 hover:bg-amber-100 border border-amber-200 rounded-md transition-colors"
          >
            File Grievance
          </button>
          <button
            onClick={() => onNavigate('suggestions')}
            className="px-3.5 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors"
          >
            Submit Suggestion
          </button>
        </div>
      </div>

      {/* 4 Metric Cards: Interconnectedness between Student, Advisor, HOD, and Principal */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-lg border border-slate-200 flex items-center justify-between">
          <div>
            <p className="text-xs text-slate-500 font-medium">Class Advisor</p>
            <p className="text-sm font-bold text-slate-900 mt-1 truncate">
              {assignedAdvisor ? assignedAdvisor.name : 'Prof. Sandhya Menon'}
            </p>
            <button
              onClick={() => onNavigate('messages')}
              className="text-xs text-red-600 font-semibold mt-1 inline-flex items-center gap-1 hover:underline"
            >
              <span>Private Chat</span> &rarr;
            </button>
          </div>
          <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-600 shrink-0">
            <MessageSquare className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white p-4 rounded-lg border border-slate-200 flex items-center justify-between">
          <div>
            <p className="text-xs text-slate-500 font-medium">Department HOD & Principal</p>
            <p className="text-sm font-bold text-slate-900 mt-1">
              1 HOD · 1 Principal
            </p>
            <p className="text-[11px] text-slate-400 font-mono mt-0.5">
              {currentUser.departmentName || 'Dept'} Office Active
            </p>
          </div>
          <div className="w-10 h-10 rounded-full bg-purple-50 text-purple-700 flex items-center justify-center shrink-0">
            <ShieldCheck className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white p-4 rounded-lg border border-slate-200 flex items-center justify-between">
          <div>
            <p className="text-xs text-slate-500 font-medium">My Active Grievances</p>
            <p className="text-2xl font-bold text-slate-900 font-mono tabular-nums mt-0.5">
              {grievances.filter(g => g.status !== 'RESOLVED' && g.status !== 'REJECTED').length}
            </p>
            <button
              onClick={() => onNavigate('grievances')}
              className="text-xs text-slate-500 font-medium hover:text-slate-800 mt-1 inline-block"
            >
              View Case Timelines &rarr;
            </button>
          </div>
          <div className="w-10 h-10 rounded-full bg-amber-50 text-amber-700 flex items-center justify-center shrink-0">
            <AlertCircle className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white p-4 rounded-lg border border-slate-200 flex items-center justify-between">
          <div>
            <p className="text-xs text-slate-500 font-medium">My Campus Proposals</p>
            <p className="text-2xl font-bold text-slate-900 font-mono tabular-nums mt-0.5">
              {suggestions.length}
            </p>
            <button
              onClick={() => onNavigate('suggestions')}
              className="text-xs text-slate-500 font-medium hover:text-slate-800 mt-1 inline-block"
            >
              Track Status &rarr;
            </button>
          </div>
          <div className="w-10 h-10 rounded-full bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0">
            <Lightbulb className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Two Column Layout: Latest Announcements & Grievance Status */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Latest Announcements */}
        <div className="bg-white p-5 rounded-lg border border-slate-200">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Volume2 className="w-4 h-4 text-red-600" />
              <span>Official Notices For You</span>
            </h3>
            <button
              onClick={() => onNavigate('announcements')}
              className="text-xs font-semibold text-red-600 hover:text-red-700 flex items-center gap-1"
            >
              <span>All Notices</span> &rarr;
            </button>
          </div>

          {notices.length === 0 ? (
            <p className="text-xs text-slate-400 py-6 text-center">No new announcements circulated today.</p>
          ) : (
            <div className="space-y-3">
              {notices.map((n) => (
                <div key={n.id} className="p-3.5 bg-slate-50 rounded-md border border-slate-200">
                  <div className="flex items-center justify-between text-[11px] text-slate-500 font-mono">
                    <span className="font-semibold text-slate-700">{n.category.replace('_', ' ')}</span>
                    <span>{n.createdAt.split('T')[0]}</span>
                  </div>
                  <h4 className="text-xs font-bold text-slate-900 mt-1">{n.title}</h4>
                  <p className="text-xs text-slate-600 line-clamp-2 mt-1 leading-relaxed">{n.content}</p>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Confidential Grievances Tracker */}
        <div className="bg-white p-5 rounded-lg border border-slate-200">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-amber-600" />
              <span>Grievance Redressal Status</span>
            </h3>
            <button
              onClick={() => onNavigate('grievances')}
              className="text-xs font-semibold text-red-600 hover:text-red-700"
            >
              View Cases &rarr;
            </button>
          </div>

          {grievances.length === 0 ? (
            <div className="p-6 text-center text-xs text-slate-400">
              No active grievances filed. Your collegiate record is in good standing.
            </div>
          ) : (
            <div className="space-y-3">
              {grievances.slice(0, 3).map((g) => (
                <div key={g.id} className="p-3 bg-slate-50 rounded-md border border-slate-200 flex items-center justify-between text-xs">
                  <div>
                    <span className="font-mono font-bold text-slate-900">{g.caseId}</span>
                    <p className="text-xs font-semibold text-slate-800 truncate mt-0.5">{g.title}</p>
                    <span className="text-[11px] text-slate-500 font-mono">
                      Status: {g.status.replace('_', ' ')}
                    </span>
                  </div>
                  <span className={`text-[11px] font-mono font-bold px-2 py-0.5 rounded ${
                    g.status === 'RESOLVED' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                  }`}>
                    {g.status}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
