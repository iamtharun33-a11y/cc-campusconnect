import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../../context/AuthContext';
import { storageService } from '../../services/storage';
import { Conversation, PrivateMessage, User } from '../../types';
import { EmptyState } from '../common/EmptyState';
import { MessageSquare, Send, User as UserIcon, Plus, ShieldCheck, CheckCheck } from 'lucide-react';

export const MessagingModule: React.FC = () => {
  const { currentUser } = useAuth();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeConversationId, setActiveConversationId] = useState<string | null>(null);
  const [messages, setMessages] = useState<PrivateMessage[]>([]);
  const [inputText, setInputText] = useState('');
  const [showNewConvoModal, setShowNewConvoModal] = useState(false);
  const [selectedRecipientId, setSelectedRecipientId] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  if (!currentUser) return null;

  const allowedRecipients = storageService.getAuthorizedRecipientsForUser(currentUser);

  const refreshConvos = () => {
    const list = storageService.getConversationsForUser(currentUser.id);
    setConversations(list);
    if (!activeConversationId && list.length > 0) {
      setActiveConversationId(list[0].id);
    }
  };

  useEffect(() => {
    refreshConvos();
  }, [currentUser]);

  useEffect(() => {
    if (activeConversationId) {
      try {
        const msgs = storageService.getMessagesInConversation(activeConversationId, currentUser.id);
        setMessages(msgs);
      } catch (err) {
        console.error(err);
      }
    } else {
      setMessages([]);
    }
  }, [activeConversationId, currentUser]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const activeConvo = conversations.find(c => c.id === activeConversationId);
  const otherParticipantName = activeConvo?.participantNames.find(n => n !== currentUser.name) || 'Conversation';
  const otherParticipantRole = activeConvo?.participantRoles.find((_, idx) => activeConvo.participantNames[idx] !== currentUser.name);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    let recipientId = '';
    if (activeConvo) {
      recipientId = activeConvo.participantIds.find(id => id !== currentUser.id) || '';
    } else if (selectedRecipientId) {
      recipientId = selectedRecipientId;
    }

    if (!recipientId) return;

    try {
      const newMsg = storageService.sendPrivateMessage(currentUser, recipientId, inputText);
      setInputText('');
      refreshConvos();
      setActiveConversationId(newMsg.conversationId);
      const msgs = storageService.getMessagesInConversation(newMsg.conversationId, currentUser.id);
      setMessages(msgs);
    } catch (err: any) {
      alert(err.message || 'Failed to send message');
    }
  };

  const handleStartNewConversation = (recipient: User) => {
    setSelectedRecipientId(recipient.id);
    // Check if convo already exists
    const existing = conversations.find(c => c.participantIds.includes(recipient.id));
    if (existing) {
      setActiveConversationId(existing.id);
      setShowNewConvoModal(false);
    } else {
      // Create with initial hello or prompt composer
      setShowNewConvoModal(false);
      const initial = prompt(`Enter first message to ${recipient.name} (${recipient.role}):`);
      if (initial && initial.trim()) {
        const msg = storageService.sendPrivateMessage(currentUser, recipient.id, initial.trim());
        refreshConvos();
        setActiveConversationId(msg.conversationId);
      }
    }
  };

  return (
    <div className="space-y-4">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-lg border border-slate-200">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">Private Role Messaging</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            End-to-end authorized collegiate communication strictly isolated between permitted roles.
          </p>
        </div>

        <button
          onClick={() => setShowNewConvoModal(true)}
          disabled={allowedRecipients.length === 0}
          className="px-3 py-2 text-xs font-semibold text-white bg-red-600 hover:bg-red-700 disabled:opacity-50 disabled:cursor-not-allowed rounded-md transition-colors flex items-center gap-1.5 shadow-xs"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>New Private Thread</span>
        </button>
      </div>

      {/* Main Messaging Layout */}
      <div className="bg-white rounded-lg border border-slate-200 h-[620px] flex overflow-hidden">
        {/* Left Sidebar: Conversations list */}
        <div className="w-80 border-r border-slate-200 flex flex-col bg-slate-50/40">
          <div className="p-3 border-b border-slate-200 flex items-center justify-between bg-white">
            <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">
              Inbox ({conversations.length})
            </span>
            <span className="text-[11px] text-slate-400 font-mono">Role Scoped</span>
          </div>

          <div className="flex-1 overflow-y-auto divide-y divide-slate-100">
            {conversations.length === 0 ? (
              <div className="p-6 text-center text-xs text-slate-400">
                No active conversations yet. Click "New Private Thread" above to message an authorized contact.
              </div>
            ) : (
              conversations.map((c) => {
                const partnerName = c.participantNames.find(n => n !== currentUser.name) || 'User';
                const partnerRole = c.participantRoles.find((_, i) => c.participantNames[i] !== currentUser.name);
                const isSelected = c.id === activeConversationId;
                const unread = c.unreadCountByUser?.[currentUser.id] || 0;

                return (
                  <button
                    key={c.id}
                    onClick={() => setActiveConversationId(c.id)}
                    className={`w-full p-3 text-left transition-colors flex items-start gap-2.5 ${
                      isSelected ? 'bg-white border-l-2 border-red-600' : 'hover:bg-slate-100/60'
                    }`}
                  >
                    <div className="w-8 h-8 rounded bg-slate-200 text-slate-700 flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
                      {partnerName.charAt(0)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-1">
                        <span className="text-xs font-semibold text-slate-900 truncate">{partnerName}</span>
                        <span className="text-[10px] text-slate-400 font-mono shrink-0">
                          {new Date(c.lastMessageAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                      <div className="flex items-center justify-between gap-1 mt-0.5">
                        <span className="text-[11px] text-slate-500 truncate">{c.lastMessageSnippet}</span>
                        {unread > 0 && (
                          <span className="px-1.5 py-0.2 bg-red-600 text-white font-mono text-[10px] font-bold rounded-full">
                            {unread}
                          </span>
                        )}
                      </div>
                      <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                        Role: {partnerRole}
                      </div>
                    </div>
                  </button>
                );
              })
            )}
          </div>
        </div>

        {/* Right Pane: Active Thread History & Composer */}
        <div className="flex-1 flex flex-col bg-white">
          {activeConvo ? (
            <>
              {/* Thread Header */}
              <div className="px-5 py-3.5 border-b border-slate-200 flex items-center justify-between bg-slate-50/50">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded bg-red-100 text-red-700 flex items-center justify-center font-bold text-xs">
                    {otherParticipantName.charAt(0)}
                  </div>
                  <div>
                    <h3 className="text-xs font-bold text-slate-900 leading-tight">{otherParticipantName}</h3>
                    <p className="text-[11px] text-slate-500 font-mono">
                      Authorized Contact · Role: {otherParticipantRole}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 text-[11px] text-emerald-700 bg-emerald-50 px-2 py-1 rounded border border-emerald-200">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>Confidential Channel</span>
                </div>
              </div>

              {/* Message List */}
              <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-slate-50/30">
                {messages.length === 0 ? (
                  <div className="p-8 text-center text-xs text-slate-400">
                    No messages in this conversation yet. Send the first message below.
                  </div>
                ) : (
                  messages.map((m) => {
                    const isMe = m.senderId === currentUser.id;
                    return (
                      <div
                        key={m.id}
                        className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
                      >
                        <div
                          className={`max-w-md px-3.5 py-2.5 rounded-lg text-xs leading-relaxed ${
                            isMe
                              ? 'bg-red-600 text-white rounded-br-2xs'
                              : 'bg-white border border-slate-200 text-slate-800 rounded-bl-2xs shadow-2xs'
                          }`}
                        >
                          <p className="whitespace-pre-wrap">{m.content}</p>
                        </div>
                        <div className="flex items-center gap-1 mt-1 text-[10px] text-slate-400 font-mono px-1">
                          <span>{new Date(m.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                          {isMe && (
                            <span className="flex items-center">
                              <CheckCheck className={`w-3 h-3 ${m.isRead ? 'text-blue-500' : 'text-slate-300'}`} />
                            </span>
                          )}
                        </div>
                      </div>
                    );
                  })
                )}
                <div ref={messagesEndRef} />
              </div>

              {/* Message Composer */}
              <form onSubmit={handleSendMessage} className="p-3 border-t border-slate-200 bg-white flex items-center gap-2">
                <input
                  type="text"
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  placeholder={`Write private message to ${otherParticipantName}...`}
                  className="flex-1 text-xs p-2.5 rounded-md border border-slate-300 focus:border-red-600 focus:outline-hidden"
                />
                <button
                  type="submit"
                  disabled={!inputText.trim()}
                  className="p-2.5 bg-red-600 hover:bg-red-700 disabled:opacity-40 disabled:cursor-not-allowed text-white rounded-md transition-colors"
                >
                  <Send className="w-4 h-4" />
                </button>
              </form>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center p-8">
              <EmptyState
                icon={MessageSquare}
                title="No Conversation Selected"
                description="Select an ongoing conversation from the left, or initiate a new secure message with an authorized contact."
                actionLabel={allowedRecipients.length > 0 ? 'Start New Thread' : undefined}
                onAction={() => setShowNewConvoModal(true)}
              />
            </div>
          )}
        </div>
      </div>

      {/* Authorized Recipients Modal */}
      {showNewConvoModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-white rounded-lg shadow-xl border border-slate-200 p-5">
            <h3 className="text-base font-bold text-slate-900">Select Authorized Recipient</h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Institutional policy restricts private communications to verified role counterparts.
            </p>

            <div className="mt-4 divide-y divide-slate-100 max-h-72 overflow-y-auto">
              {allowedRecipients.length === 0 ? (
                <p className="text-xs text-slate-400 p-4 text-center">
                  No authorized recipients found for your role profile.
                </p>
              ) : (
                allowedRecipients.map(r => (
                  <div
                    key={r.id}
                    onClick={() => handleStartNewConversation(r)}
                    className="py-2.5 px-2 hover:bg-slate-50 cursor-pointer rounded flex items-center justify-between"
                  >
                    <div>
                      <p className="text-xs font-bold text-slate-900">{r.name}</p>
                      <p className="text-[11px] text-slate-500 font-mono">
                        {r.role} · {r.departmentName || r.className || 'Administration'}
                      </p>
                    </div>
                    <span className="text-xs text-red-600 font-semibold">Message &rarr;</span>
                  </div>
                ))
              )}
            </div>

            <div className="mt-4 pt-3 border-t border-slate-100 text-right">
              <button
                onClick={() => setShowNewConvoModal(false)}
                className="px-3.5 py-1.5 text-xs font-semibold text-slate-600 hover:text-slate-800"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
