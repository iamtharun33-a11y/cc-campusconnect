import React from 'react';
import { useAuth } from '../../context/AuthContext';
import { storageService } from '../../services/storage';
import {
  LayoutDashboard,
  Volume2,
  MessageSquare,
  MessagesSquare,
  AlertCircle,
  Lightbulb,
  BarChart3,
  Database,
  Building2,
  GraduationCap
} from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  onSelectTab: (tab: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ activeTab, onSelectTab }) => {
  const { currentUser } = useAuth();
  if (!currentUser) return null;

  // Unread messages count
  const conversations = storageService.getConversationsForUser(currentUser.id);
  const unreadMsgCount = conversations.reduce((acc, c) => acc + (c.unreadCountByUser?.[currentUser.id] || 0), 0);

  // Active grievances count
  const grievances = storageService.getGrievancesForUser(currentUser);
  const activeGrievanceCount = grievances.filter(g => g.status !== 'RESOLVED' && g.status !== 'REJECTED').length;

  const navItems = [
    {
      id: 'overview',
      label: 'Command Center',
      icon: LayoutDashboard,
      badge: null
    },
    {
      id: 'announcements',
      label: 'Official Announcements',
      icon: Volume2,
      badge: null
    },
    {
      id: 'messages',
      label: 'Private Messaging',
      icon: MessageSquare,
      badge: unreadMsgCount > 0 ? unreadMsgCount : null,
      badgeColor: 'bg-red-600 text-white'
    },
    {
      id: 'discussions',
      label: 'Public Discussions',
      icon: MessagesSquare,
      badge: null
    },
    {
      id: 'grievances',
      label: 'Grievance Redressal',
      icon: AlertCircle,
      badge: activeGrievanceCount > 0 ? activeGrievanceCount : null,
      badgeColor: 'bg-amber-100 text-amber-800'
    },
    {
      id: 'suggestions',
      label: 'Campus Suggestions',
      icon: Lightbulb,
      badge: null
    },
    {
      id: 'reports',
      label: 'Reports & Analytics',
      icon: BarChart3,
      badge: null
    },
    ...(currentUser.role === 'PRINCIPAL' || currentUser.role === 'HOD'
      ? [
          {
            id: 'system',
            label: 'Governance & Audits',
            icon: Database,
            badge: null
          }
        ]
      : [])
  ];

  return (
    <aside className="w-64 bg-white border-r border-slate-200 shrink-0 flex flex-col min-h-[calc(100vh-4rem)]">
      {/* Role Scope Info Banner */}
      <div className="p-4 border-b border-slate-100 bg-slate-50/70">
        <div className="flex items-center gap-2">
          {currentUser.role === 'STUDENT' ? (
            <GraduationCap className="w-4 h-4 text-red-600" />
          ) : (
            <Building2 className="w-4 h-4 text-red-600" />
          )}
          <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">
            {currentUser.role} PORTAL
          </span>
        </div>
        <p className="text-[11px] text-slate-500 mt-1 truncate">
          {currentUser.departmentName || 'CC Campus Central Office'}
        </p>
        {currentUser.className && (
          <p className="text-[11px] font-mono text-slate-400 mt-0.5 truncate">
            {currentUser.className}
          </p>
        )}
      </div>

      {/* Navigation Links */}
      <nav className="p-3 space-y-1 flex-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onSelectTab(item.id)}
              className={`w-full flex items-center justify-between px-3 py-2 text-xs font-medium rounded-md transition-colors ${
                isActive
                  ? 'bg-red-50 text-red-700 font-semibold border-l-2 border-red-600 pl-2.5'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <Icon className={`w-4 h-4 ${isActive ? 'text-red-600' : 'text-slate-400'}`} />
                <span>{item.label}</span>
              </div>
              {item.badge !== null && (
                <span
                  className={`px-1.5 py-0.5 font-mono text-[10px] font-bold rounded-sm ${
                    item.badgeColor || 'bg-slate-100 text-slate-700'
                  }`}
                >
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Platform Verification Footer */}
      <div className="p-3 border-t border-slate-100 text-[11px] text-slate-400 font-mono">
        <div className="flex items-center justify-between">
          <span>CC Campus Connect</span>
          <span className="text-slate-500 font-semibold">v3.2</span>
        </div>
        <div className="text-[10px] text-slate-400 mt-0.5">Role Scoped Access Enforced</div>
      </div>
    </aside>
  );
};
