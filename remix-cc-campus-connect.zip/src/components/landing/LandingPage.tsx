import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { storageService } from '../../services/storage';
import { UserRole } from '../../types';
import campusHeroImage from '../../assets/images/campus_hero_building_1791701638530.jpg';
import {
  GraduationCap,
  Users,
  Building2,
  ShieldCheck,
  ArrowRight,
  Lock,
  UserPlus,
  BookOpen,
  Volume2,
  Clock,
  AlertCircle,
  CheckCircle2,
  HelpCircle,
  ChevronDown,
  ChevronUp,
  FileText,
  Mail,
  Eye,
  EyeOff,
  ShieldAlert,
  Sparkles,
  PlusCircle
} from 'lucide-react';

interface LandingPageProps {
  onEnterPortal: (tab?: string) => void;
  initialView?: 'home' | 'portal_access' | 'portal_login' | 'portal_register';
  initialPortalRole?: UserRole;
  onUpdateRoute?: (path: string) => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  onEnterPortal,
  initialView = 'home',
  initialPortalRole = 'STUDENT',
  onUpdateRoute
}) => {
  const { currentUser, login, registerStudent, registerFaculty, registerHod, registerPrincipal } = useAuth();
  
  // View states: 'home' | 'portal_access' | 'portal_login' | 'portal_register'
  const [activeView, setActiveView] = useState<'home' | 'portal_access' | 'portal_login' | 'portal_register'>(initialView);
  const [selectedPortalRole, setSelectedPortalRole] = useState<UserRole>(initialPortalRole);

  useEffect(() => {
    setActiveView(initialView);
  }, [initialView]);

  useEffect(() => {
    setSelectedPortalRole(initialPortalRole);
  }, [initialPortalRole]);

  const setViewAndUrl = (view: 'home' | 'portal_access' | 'portal_login' | 'portal_register', role?: UserRole) => {
    setActiveView(view);
    if (role) setSelectedPortalRole(role);

    if (onUpdateRoute) {
      if (view === 'home') onUpdateRoute('/');
      else if (view === 'portal_access') onUpdateRoute('/portals');
      else if (view === 'portal_login') onUpdateRoute(`/login/${(role || selectedPortalRole).toLowerCase()}`);
      else if (view === 'portal_register') onUpdateRoute(`/register/${(role || selectedPortalRole).toLowerCase()}`);
    }
  };

  // Login form state
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [authError, setAuthError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Dynamic Registration Form States (Requirement 2)
  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regIdNumber, setRegIdNumber] = useState(''); // Roll number or Staff ID
  
  // Department: Select from dynamic catalog OR type custom
  const [selectedDeptId, setSelectedDeptId] = useState('dep_cse');
  const [isCustomDept, setIsCustomDept] = useState(false);
  const [customDeptName, setCustomDeptName] = useState('');
  const [customDeptCode, setCustomDeptCode] = useState('');

  // Course / Programme
  const [courseProgram, setCourseProgram] = useState('B.Tech');
  const [isCustomCourse, setIsCustomCourse] = useState(false);
  const [customCourseName, setCustomCourseName] = useState('');

  // Academic Batch & Year
  const [academicBatch, setAcademicBatch] = useState('2023–2027');
  const [regYear, setRegYear] = useState('4th Year');
  const [regSemester, setRegSemester] = useState(7);

  // Section
  const [sectionChoice, setSectionChoice] = useState('Section A');
  const [isCustomSection, setIsCustomSection] = useState(false);
  const [customSectionName, setCustomSectionName] = useState('');

  // Password fields
  const [regPassword, setRegPassword] = useState('');
  const [regConfirmPassword, setRegConfirmPassword] = useState('');
  const [regError, setRegError] = useState('');

  // FAQ Accordion state
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  // Policy modal states
  const [showPrivacyModal, setShowPrivacyModal] = useState(false);
  const [showTermsModal, setShowTermsModal] = useState(false);

  const departments = storageService.getDepartments();

  // Synchronize semester suggestions when year changes
  const handleYearChange = (year: string) => {
    setRegYear(year);
    if (year === '1st Year') setRegSemester(1);
    else if (year === '2nd Year') setRegSemester(3);
    else if (year === '3rd Year') setRegSemester(5);
    else if (year === '4th Year') setRegSemester(7);
    else if (year === '5th Year') setRegSemester(9);
  };

  const portalCards = [
    {
      role: 'STUDENT' as UserRole,
      title: 'Student Portal',
      icon: GraduationCap,
      description: 'Authorized hub for collegiate circulars, confidential grievance filing, private class advisory, and campus suggestions.',
      audience: 'Registered Undergraduate & Postgraduate Students',
      canRegister: true,
      badgeColor: 'text-red-700 bg-red-50 border-red-200'
    },
    {
      role: 'ADVISOR' as UserRole,
      title: 'Faculty / Advisor Portal',
      icon: Users,
      description: 'Class advisory command desk: manage section rosters, broadcast section circulars, review student grievances, and escalate to HOD.',
      audience: 'Appointed Class Advisors & Academic Faculty',
      canRegister: true,
      badgeColor: 'text-blue-700 bg-blue-50 border-blue-200'
    },
    {
      role: 'HOD' as UserRole,
      title: 'HOD (Head of Department) Portal',
      icon: Building2,
      description: 'Departmental command center: student directory, advisor oversight, class & section management, suggestions review, and academic performance tracking.',
      audience: 'Appointed Department Heads (HODs)',
      canRegister: true,
      badgeColor: 'text-amber-700 bg-amber-50 border-amber-200'
    },
    {
      role: 'PRINCIPAL' as UserRole,
      title: 'Principal Portal',
      icon: ShieldCheck,
      description: 'Supreme collegiate executive command: broadcast college-wide circulars, issue half-day notices, adjudicate escalated grievances, and institutional governance.',
      audience: 'Head of Institution / Principal Office',
      canRegister: true,
      badgeColor: 'text-purple-700 bg-purple-50 border-purple-200'
    }
  ];

  const handleOpenPortalLogin = (role: UserRole) => {
    setSelectedPortalRole(role);
    setIdentifier('');
    setPassword('');
    setAuthError('');
    setViewAndUrl('portal_login', role);
  };

  const handleOpenPortalRegister = (role: UserRole) => {
    setSelectedPortalRole(role);
    setRegName('');
    setRegEmail('');
    setRegIdNumber('');
    setRegPassword('');
    setRegConfirmPassword('');
    setRegError('');
    setViewAndUrl('portal_register', role);
  };

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setIsSubmitting(true);

    try {
      const res = await login(identifier, password, selectedPortalRole);
      if (res.success) {
        onEnterPortal('overview');
      } else {
        setAuthError(res.error || 'Authentication failed. Please verify credentials.');
      }
    } catch (err: any) {
      setAuthError(err.message || 'Server error occurred during login');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setRegError('');

    if (regPassword.length < 8) {
      setRegError('Password must contain at least 8 characters for security compliance.');
      return;
    }

    if (regPassword !== regConfirmPassword) {
      setRegError('Passwords do not match. Please re-enter.');
      return;
    }

    // Resolve Department dynamically (Requirement 2.A)
    let finalDeptId = selectedDeptId;
    let finalDeptName = '';
    if (isCustomDept) {
      if (!customDeptName.trim()) {
        setRegError('Please enter your custom Department name.');
        return;
      }
      const newDept = storageService.findOrCreateDepartment(customDeptName, customDeptCode);
      finalDeptId = newDept.id;
      finalDeptName = newDept.name;
    } else {
      const matched = departments.find(d => d.id === selectedDeptId);
      finalDeptName = matched ? matched.name : 'General Department';
    }

    // Resolve Course
    const finalCourse = isCustomCourse ? customCourseName.trim() || 'Degree Programme' : courseProgram;

    // Resolve Section (Requirement 2.C)
    const finalSection = isCustomSection ? customSectionName.trim() || 'Section A' : sectionChoice;

    // Resolve Class Name
    const classNameComputed = `${finalCourse} - ${regYear} (${finalSection})`;
    const resolvedClass = storageService.findOrCreateClass(finalDeptId, classNameComputed, Number(regSemester));

    setIsSubmitting(true);
    try {
      if (selectedPortalRole === 'STUDENT') {
        await registerStudent({
          name: regName.trim(),
          email: regEmail.trim(),
          rollNumber: regIdNumber.trim(),
          departmentId: finalDeptId,
          departmentName: finalDeptName,
          classId: resolvedClass.id,
          className: resolvedClass.name,
          course: finalCourse,
          academicBatch,
          year: regYear,
          semester: Number(regSemester),
          section: finalSection,
          password: regPassword
        });
        onEnterPortal('overview');
      } else if (selectedPortalRole === 'ADVISOR') {
        await registerFaculty({
          name: regName.trim(),
          email: regEmail.trim(),
          employeeId: regIdNumber.trim(),
          departmentId: finalDeptId,
          departmentName: finalDeptName,
          course: finalCourse,
          classId: resolvedClass.id,
          className: resolvedClass.name,
          password: regPassword
        });
        onEnterPortal('overview');
      } else if (selectedPortalRole === 'HOD') {
        await registerHod({
          name: regName.trim(),
          email: regEmail.trim(),
          employeeId: regIdNumber.trim() || `EMP-HOD-${Date.now().toString().slice(-4)}`,
          departmentId: finalDeptId,
          departmentName: finalDeptName,
          password: regPassword
        });
        onEnterPortal('overview');
      } else if (selectedPortalRole === 'PRINCIPAL') {
        await registerPrincipal({
          name: regName.trim(),
          email: regEmail.trim(),
          employeeId: regIdNumber.trim() || `EMP-PRIN-${Date.now().toString().slice(-4)}`,
          password: regPassword
        });
        onEnterPortal('overview');
      }
    } catch (err: any) {
      setRegError(err.message || 'Registration failed');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans selection:bg-red-500 selection:text-white">
      {/* 1. Public Top Navigation Bar */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setViewAndUrl('home')}
              className="flex items-center gap-2.5 text-left focus:outline-hidden"
            >
              <div className="w-8 h-8 rounded-md bg-red-600 flex items-center justify-center text-white font-bold text-base shadow-xs shrink-0">
                CC
              </div>
              <div>
                <span className="text-base font-bold tracking-tight text-slate-900">
                  CC Campus Connect
                </span>
                <span className="hidden sm:inline-block text-[11px] text-slate-400 ml-2 font-mono">
                  Enterprise Institutional Platform
                </span>
              </div>
            </button>
          </div>

          <div className="flex items-center gap-3">
            <nav className="hidden md:flex items-center gap-6 text-xs font-semibold text-slate-600 mr-2">
              <a href="#about" onClick={() => setViewAndUrl('home')} className="hover:text-red-600 transition-colors">About</a>
              <a href="#workflow" onClick={() => setViewAndUrl('home')} className="hover:text-red-600 transition-colors">How It Works</a>
              <a href="#portals" onClick={() => setViewAndUrl('portal_access')} className="hover:text-red-600 transition-colors">Four Portals</a>
              <a href="#faq" onClick={() => setViewAndUrl('home')} className="hover:text-red-600 transition-colors">FAQ</a>
            </nav>

            {currentUser ? (
              <button
                onClick={() => onEnterPortal('overview')}
                className="px-4 py-2 text-xs font-bold text-white bg-red-600 hover:bg-red-700 rounded-md transition-colors flex items-center gap-1.5 shadow-xs"
              >
                <span>Go to {currentUser.role} Portal</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            ) : (
              <button
                onClick={() => setViewAndUrl('portal_access')}
                className="px-4 py-2 text-xs font-bold text-white bg-red-600 hover:bg-red-700 rounded-md transition-colors flex items-center gap-1.5 shadow-xs"
              >
                <Lock className="w-3.5 h-3.5" />
                <span>Four Portal Access</span>
              </button>
            )}
          </div>
        </div>
      </header>

      {/* 2. DEDICATED PORTAL VIEWS */}
      {activeView === 'portal_login' ? (
        /* DEDICATED PORTAL LOGIN SCREEN */
        <div className="flex-1 max-w-lg w-full mx-auto p-4 sm:p-6 lg:p-8 flex flex-col justify-center">
          <button
            onClick={() => setViewAndUrl('portal_access')}
            className="text-xs font-semibold text-slate-500 hover:text-slate-900 mb-6 flex items-center gap-1 self-start"
          >
            &larr; Back to Portal Selection
          </button>

          <div className="bg-white rounded-xl border border-slate-200 p-6 sm:p-8 shadow-xl">
            <div className="flex items-center gap-2.5 text-xs font-bold uppercase tracking-wider text-red-600 mb-1">
              <Lock className="w-4 h-4" />
              <span>{selectedPortalRole} PORTAL AUTHENTICATION</span>
            </div>
            <h2 className="text-xl font-bold text-slate-900 tracking-tight">
              Sign In to {selectedPortalRole === 'ADVISOR' ? 'Faculty / Advisor' : selectedPortalRole === 'HOD' ? 'Head of Department (HOD)' : selectedPortalRole === 'PRINCIPAL' ? 'Executive Principal' : 'Student'} Portal
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              {selectedPortalRole === 'STUDENT'
                ? 'Enter your institutional email or Student Register Number.'
                : selectedPortalRole === 'HOD'
                ? 'Enter your Department Head institutional email or Staff ID.'
                : 'Enter your verified institutional staff email or employee identifier.'}
            </p>

            {authError && (
              <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded-md text-xs text-red-700 flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                <span>{authError}</span>
              </div>
            )}

            <form onSubmit={handleLoginSubmit} className="mt-6 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  {selectedPortalRole === 'STUDENT' ? 'Institutional Email or Register No. *' : 'Institutional Email or Staff ID *'}
                </label>
                <input
                  type="text"
                  required
                  value={identifier}
                  onChange={(e) => setIdentifier(e.target.value)}
                  placeholder={
                    selectedPortalRole === 'STUDENT' 
                      ? 'kavya.cse@campusconnect.edu or 21CS1042' 
                      : selectedPortalRole === 'HOD'
                      ? 'hod.cse@campusconnect.edu or EMP-CSE-HOD'
                      : selectedPortalRole === 'PRINCIPAL'
                      ? 'principal@campusconnect.edu or EMP-PRIN-001'
                      : 'advisor.csea@campusconnect.edu or EMP-CSE-ADV1'
                  }
                  className="w-full text-xs p-2.5 rounded-md border border-slate-300 focus:border-red-600 focus:ring-1 focus:ring-red-600 focus:outline-hidden"
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-semibold text-slate-700">Password *</label>
                  <button
                    type="button"
                    onClick={() => alert('Password Recovery: Please contact the Principal Office or Institutional Registrar for credential reset.')}
                    className="text-[11px] text-red-600 hover:underline"
                  >
                    Forgot password?
                  </button>
                </div>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter secure password"
                    className="w-full text-xs p-2.5 pr-10 rounded-md border border-slate-300 focus:border-red-600 focus:ring-1 focus:ring-red-600 focus:outline-hidden"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-2.5 text-xs font-bold text-white bg-red-600 hover:bg-red-700 disabled:opacity-50 rounded-md transition-colors flex items-center justify-center gap-2 shadow-xs"
                >
                  <Lock className="w-3.5 h-3.5" />
                  <span>{isSubmitting ? 'Authenticating...' : 'Sign In to Portal'}</span>
                </button>
              </div>
            </form>

            <div className="mt-6 pt-4 border-t border-slate-100 text-center text-xs text-slate-600">
              <span>Don't have an account for this portal? </span>
              <button
                onClick={() => handleOpenPortalRegister(selectedPortalRole)}
                className="font-bold text-red-600 hover:underline"
              >
                Register here &rarr;
              </button>
            </div>
          </div>
        </div>
      ) : activeView === 'portal_register' ? (
        /* DEDICATED DYNAMIC REGISTRATION SCREEN (Requirement 2) */
        <div className="flex-1 max-w-2xl w-full mx-auto p-4 sm:p-6 lg:p-8 flex flex-col justify-center">
          <button
            onClick={() => setViewAndUrl('portal_access')}
            className="text-xs font-semibold text-slate-500 hover:text-slate-900 mb-6 flex items-center gap-1 self-start"
          >
            &larr; Back to Portal Selection
          </button>

          <div className="bg-white rounded-xl border border-slate-200 p-6 sm:p-8 shadow-xl">
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-red-600 mb-1">
              <UserPlus className="w-4 h-4" />
              <span>
                {selectedPortalRole === 'STUDENT'
                  ? 'STUDENT REGISTRATION'
                  : selectedPortalRole === 'ADVISOR'
                  ? 'FACULTY / ADVISOR ONBOARDING'
                  : selectedPortalRole === 'HOD'
                  ? 'HEAD OF DEPARTMENT (HOD) REGISTRATION'
                  : 'EXECUTIVE PRINCIPAL REGISTRATION'}
              </span>
            </div>
            <h2 className="text-xl font-bold text-slate-900 tracking-tight">
              Register {selectedPortalRole === 'STUDENT' ? 'Student' : selectedPortalRole === 'ADVISOR' ? 'Faculty / Advisor' : selectedPortalRole === 'HOD' ? 'Head of Department (HOD)' : 'Executive Principal'} Profile
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              {selectedPortalRole === 'PRINCIPAL'
                ? 'Register the supreme executive head of the institution into the central institutional platform.'
                : selectedPortalRole === 'HOD'
                ? 'Register your Head of Department account with departmental administrative oversight.'
                : 'Register your dynamic department, course, batch, and section into the central institutional database.'}
            </p>

            {regError && (
              <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded-md text-xs text-red-700 flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                <span>{regError}</span>
              </div>
            )}

            <form onSubmit={handleRegisterSubmit} className="mt-6 space-y-4">
              {/* Full Name */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Full Legal Name *</label>
                <input
                  type="text"
                  required
                  value={regName}
                  onChange={(e) => setRegName(e.target.value)}
                  placeholder="e.g. Kavya Subramanian"
                  className="w-full text-xs p-2.5 rounded-md border border-slate-300 focus:border-red-600 focus:outline-hidden"
                />
              </div>

              {/* Email & Register No / Staff ID */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Institutional Email *</label>
                  <input
                    type="email"
                    required
                    value={regEmail}
                    onChange={(e) => setRegEmail(e.target.value)}
                    placeholder="kavya.cse@campusconnect.edu"
                    className="w-full text-xs p-2.5 rounded-md border border-slate-300 focus:border-red-600 focus:outline-hidden"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    {selectedPortalRole === 'STUDENT'
                      ? 'Student Register / Roll No. *'
                      : selectedPortalRole === 'HOD'
                      ? 'HOD Faculty Staff ID *'
                      : selectedPortalRole === 'PRINCIPAL'
                      ? 'Executive Employee ID / Office Ref *'
                      : 'Faculty Employee ID *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={regIdNumber}
                    onChange={(e) => setRegIdNumber(e.target.value)}
                    placeholder={
                      selectedPortalRole === 'STUDENT'
                        ? '21CS1042'
                        : selectedPortalRole === 'HOD'
                        ? 'EMP-CSE-HOD'
                        : selectedPortalRole === 'PRINCIPAL'
                        ? 'EMP-PRIN-001'
                        : 'EMP-CSE-0042'
                    }
                    className="w-full text-xs p-2.5 rounded-md border border-slate-300 focus:border-red-600 focus:outline-hidden"
                  />
                </div>
              </div>

              {/* Requirement 2.A: Dynamic Department Field (or Executive Notice for Principal) */}
              {selectedPortalRole === 'PRINCIPAL' ? (
                <div className="p-3.5 bg-purple-50/70 rounded-lg border border-purple-200 text-xs">
                  <div className="flex items-center gap-2 text-purple-950 font-bold">
                    <ShieldCheck className="w-4 h-4 text-purple-700" />
                    <span>Collegiate Jurisdiction: Institution-Wide Executive Office</span>
                  </div>
                  <p className="text-[11px] text-purple-800 mt-1 leading-relaxed">
                    The Principal holds executive governance authority over all campus departments, academic faculties, student cohorts, circulars, and institutional policies.
                  </p>
                </div>
              ) : (
                <div className="p-3.5 bg-slate-50/70 rounded-lg border border-slate-200 space-y-3">
                  <div className="flex items-center justify-between">
                    <label className="block text-xs font-bold text-slate-800">
                      {selectedPortalRole === 'HOD' ? 'Department Governed by HOD *' : 'Academic Department *'}
                    </label>
                    <button
                      type="button"
                      onClick={() => setIsCustomDept(!isCustomDept)}
                      className="text-[11px] font-semibold text-red-600 hover:underline flex items-center gap-1"
                    >
                      <PlusCircle className="w-3.5 h-3.5" />
                      <span>{isCustomDept ? 'Choose from List' : '+ Enter Custom Department'}</span>
                    </button>
                  </div>

                  {!isCustomDept ? (
                    <select
                      value={selectedDeptId}
                      onChange={(e) => {
                        if (e.target.value === 'CUSTOM_DEPT') {
                          setIsCustomDept(true);
                        } else {
                          setSelectedDeptId(e.target.value);
                        }
                      }}
                      className="w-full text-xs p-2.5 rounded-md border border-slate-300 bg-white"
                    >
                      {departments.map(d => (
                        <option key={d.id} value={d.id}>{d.name} ({d.code})</option>
                      ))}
                      <option value="CUSTOM_DEPT">+ Enter Other / New Department...</option>
                    </select>
                  ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                      <div className="sm:col-span-2">
                        <input
                          type="text"
                          required
                          value={customDeptName}
                          onChange={(e) => setCustomDeptName(e.target.value)}
                          placeholder="Enter your exact department name (e.g. Oceanography & Marine)"
                          className="w-full text-xs p-2.5 rounded-md border border-red-300 bg-white focus:border-red-600 focus:outline-hidden"
                        />
                      </div>
                      <div>
                        <input
                          type="text"
                          value={customDeptCode}
                          onChange={(e) => setCustomDeptCode(e.target.value.toUpperCase())}
                          placeholder="Code (e.g. OCN)"
                          className="w-full text-xs p-2.5 rounded-md border border-slate-300 bg-white font-mono focus:border-red-600 focus:outline-hidden"
                        />
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Requirement 2.B: Dynamic Course & Academic Batch (For Student & Advisor) */}
              {(selectedPortalRole === 'STUDENT' || selectedPortalRole === 'ADVISOR') && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-xs font-semibold text-slate-700">Course / Programme *</label>
                      <button
                        type="button"
                        onClick={() => setIsCustomCourse(!isCustomCourse)}
                        className="text-[10px] text-red-600 hover:underline"
                      >
                        {isCustomCourse ? 'Preset' : '+ Custom'}
                      </button>
                    </div>
                    {!isCustomCourse ? (
                      <select
                        value={courseProgram}
                        onChange={(e) => {
                          if (e.target.value === 'CUSTOM_COURSE') setIsCustomCourse(true);
                          else setCourseProgram(e.target.value);
                        }}
                        className="w-full text-xs p-2 rounded-md border border-slate-300 bg-white"
                      >
                        <option value="B.Tech">B.Tech (Bachelor of Technology)</option>
                        <option value="B.E.">B.E. (Bachelor of Engineering)</option>
                        <option value="M.Tech">M.Tech (Master of Technology)</option>
                        <option value="M.E.">M.E. (Master of Engineering)</option>
                        <option value="MCA">MCA (Master of Computer Applications)</option>
                        <option value="MBA">MBA (Master of Business Administration)</option>
                        <option value="B.Sc">B.Sc (Bachelor of Science)</option>
                        <option value="M.Sc">M.Sc (Master of Science)</option>
                        <option value="BCA">BCA (Bachelor of Computer Apps)</option>
                        <option value="Ph.D">Ph.D Research Scholar</option>
                        <option value="CUSTOM_COURSE">+ Custom Course...</option>
                      </select>
                    ) : (
                      <input
                        type="text"
                        required
                        value={customCourseName}
                        onChange={(e) => setCustomCourseName(e.target.value)}
                        placeholder="e.g. Integrated M.Sc Data Science"
                        className="w-full text-xs p-2 rounded-md border border-red-300 bg-white focus:outline-hidden"
                      />
                    )}
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Academic Batch *</label>
                    <select
                      value={academicBatch}
                      onChange={(e) => setAcademicBatch(e.target.value)}
                      className="w-full text-xs p-2 rounded-md border border-slate-300 bg-white font-mono"
                    >
                      <option value="2024–2028">2024–2028 Batch</option>
                      <option value="2023–2027">2023–2027 Batch</option>
                      <option value="2022–2026">2022–2026 Batch</option>
                      <option value="2021–2025">2021–2025 Batch</option>
                      <option value="2025–2029">2025–2029 Batch</option>
                      <option value="2026–2030">2026–2030 Batch</option>
                    </select>
                  </div>
                </div>
              )}

              {/* Requirement 2.B & 2.C: Year, Semester & Section */}
              {selectedPortalRole === 'STUDENT' && (
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Year of Study</label>
                    <select
                      value={regYear}
                      onChange={(e) => handleYearChange(e.target.value)}
                      className="w-full text-xs p-2 rounded-md border border-slate-300 bg-white"
                    >
                      <option value="1st Year">1st Year</option>
                      <option value="2nd Year">2nd Year</option>
                      <option value="3rd Year">3rd Year</option>
                      <option value="4th Year">4th Year</option>
                      <option value="5th Year">5th Year</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Semester</label>
                    <select
                      value={regSemester}
                      onChange={(e) => setRegSemester(Number(e.target.value))}
                      className="w-full text-xs p-2 rounded-md border border-slate-300 bg-white font-mono"
                    >
                      {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(s => (
                        <option key={s} value={s}>Semester {s}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-xs font-semibold text-slate-700">Section *</label>
                      <button
                        type="button"
                        onClick={() => setIsCustomSection(!isCustomSection)}
                        className="text-[10px] text-red-600 hover:underline"
                      >
                        {isCustomSection ? 'Preset' : '+ Custom'}
                      </button>
                    </div>
                    {!isCustomSection ? (
                      <select
                        value={sectionChoice}
                        onChange={(e) => {
                          if (e.target.value === 'CUSTOM_SECTION') setIsCustomSection(true);
                          else setSectionChoice(e.target.value);
                        }}
                        className="w-full text-xs p-2 rounded-md border border-slate-300 bg-white"
                      >
                        <option value="Section A">Section A</option>
                        <option value="Section B">Section B</option>
                        <option value="Section C">Section C</option>
                        <option value="Section D">Section D</option>
                        <option value="Section E">Section E</option>
                        <option value="Section F">Section F</option>
                        <option value="CUSTOM_SECTION">+ Custom Section / Shift...</option>
                      </select>
                    ) : (
                      <input
                        type="text"
                        required
                        value={customSectionName}
                        onChange={(e) => setCustomSectionName(e.target.value)}
                        placeholder="e.g. Section Alpha or Shift 1"
                        className="w-full text-xs p-2 rounded-md border border-red-300 bg-white focus:outline-hidden"
                      />
                    )}
                  </div>
                </div>
              )}

              {/* Password Fields */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Password (min 8 chars) *</label>
                  <input
                    type="password"
                    required
                    value={regPassword}
                    onChange={(e) => setRegPassword(e.target.value)}
                    placeholder="Create strong password"
                    className="w-full text-xs p-2.5 rounded-md border border-slate-300 focus:border-red-600 focus:outline-hidden"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Confirm Password *</label>
                  <input
                    type="password"
                    required
                    value={regConfirmPassword}
                    onChange={(e) => setRegConfirmPassword(e.target.value)}
                    placeholder="Repeat password"
                    className="w-full text-xs p-2.5 rounded-md border border-slate-300 focus:border-red-600 focus:outline-hidden"
                  />
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-2.5 text-xs font-bold text-white bg-red-600 hover:bg-red-700 disabled:opacity-50 rounded-md transition-colors flex items-center justify-center gap-2 shadow-xs"
                >
                  <UserPlus className="w-3.5 h-3.5" />
                  <span>{isSubmitting ? 'Registering...' : 'Complete Profile Registration'}</span>
                </button>
              </div>
            </form>

            <div className="mt-6 pt-4 border-t border-slate-100 text-center text-xs text-slate-600">
              <span>Already registered? </span>
              <button
                onClick={() => handleOpenPortalLogin(selectedPortalRole)}
                className="font-bold text-red-600 hover:underline"
              >
                Sign in to your portal &rarr;
              </button>
            </div>
          </div>
        </div>
      ) : activeView === 'portal_access' ? (
        /* DEDICATED FOUR PORTAL ACCESS SELECTION SECTION */
        <div className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-10">
          <div className="text-center max-w-2xl mx-auto mb-10">
            <button
              onClick={() => setViewAndUrl('home')}
              className="text-xs font-semibold text-slate-500 hover:text-slate-900 mb-4 inline-flex items-center gap-1"
            >
              &larr; Back to Homepage
            </button>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              Select Your Authorized Institutional Portal
            </h1>
            <p className="text-xs sm:text-sm text-slate-600 mt-2 leading-relaxed">
              Every portal enforces role-specific permissions backed by cryptographic authentication and institutional scope boundaries.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {portalCards.map((portal) => {
              const Icon = portal.icon;
              return (
                <div
                  key={portal.role}
                  className="bg-white rounded-xl border border-slate-200 p-6 flex flex-col justify-between hover:border-red-600 hover:shadow-xl transition-all"
                >
                  <div>
                    <div className="w-12 h-12 rounded-lg bg-red-50 text-red-600 flex items-center justify-center mb-4">
                      <Icon className="w-6 h-6 stroke-[1.75]" />
                    </div>

                    <h3 className="text-base font-bold text-slate-900">{portal.title}</h3>

                    <p className="text-xs text-slate-500 mt-2 leading-relaxed">
                      {portal.description}
                    </p>

                    <div className="mt-4 pt-3 border-t border-slate-100">
                      <p className="text-[11px] font-mono text-slate-500 leading-tight">
                        <strong>Authorized:</strong> {portal.audience}
                      </p>
                    </div>
                  </div>

                  <div className="mt-6 pt-4 border-t border-slate-100 space-y-2">
                    <button
                      onClick={() => handleOpenPortalLogin(portal.role)}
                      className="w-full py-2.5 text-xs font-bold text-white bg-red-600 hover:bg-red-700 rounded-md transition-colors flex items-center justify-center gap-1.5 shadow-xs"
                    >
                      <Lock className="w-3.5 h-3.5" />
                      <span>Sign In</span>
                    </button>

                    {portal.canRegister ? (
                      <button
                        onClick={() => handleOpenPortalRegister(portal.role)}
                        className="w-full py-2 text-xs font-semibold text-slate-700 hover:text-slate-900 hover:bg-slate-100 rounded-md transition-colors text-center"
                      >
                        Self-Registration &rarr;
                      </button>
                    ) : (
                      <div className="text-center py-1.5 text-[11px] font-mono text-slate-400">
                        Privileged Provisioning Only
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ) : (
        /* STANDARD PUBLIC HOMEPAGE */
        <main className="flex-1">
          {/* Hero Section */}
          <section className="bg-white border-b border-slate-200">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 lg:py-16">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
                <div className="lg:col-span-6 space-y-5">
                  <div className="flex items-center gap-2 text-xs text-red-600 font-bold uppercase tracking-wider">
                    <span className="w-2 h-2 rounded-full bg-red-600" />
                    <span>Collegiate Institutional Management System</span>
                  </div>

                  <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-slate-900 tracking-tight leading-tight">
                    Unified Communication, Circulars & Governance for Campus Life.
                  </h1>

                  <p className="text-sm text-slate-600 leading-relaxed max-w-xl">
                    CC Campus Connect delivers dedicated portals for students, faculty advisors, department heads, and executive leadership. Featuring authoritative announcements, confidential grievance redressal with SLA tracking, and isolated private messaging.
                  </p>

                  <div className="pt-2 flex flex-wrap items-center gap-3">
                    <button
                      onClick={() => setViewAndUrl('portal_access')}
                      className="px-5 py-3 text-sm font-bold text-white bg-red-600 hover:bg-red-700 rounded-lg transition-colors flex items-center gap-2 shadow-sm"
                    >
                      <Lock className="w-4 h-4" />
                      <span>Four Portal Access</span>
                    </button>

                    <a
                      href="#workflow"
                      className="px-4 py-3 text-sm font-semibold text-slate-700 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors"
                    >
                      Explore Workflow &rarr;
                    </a>
                  </div>

                  <div className="pt-2 flex flex-wrap items-center gap-4 text-xs text-slate-500 font-mono">
                    <span>4 Scoped Portals</span>
                    <span aria-hidden="true">·</span>
                    <span>Role-Isolated Messaging</span>
                    <span aria-hidden="true">·</span>
                    <span>Confidential Redressal</span>
                  </div>
                </div>

                {/* Preserved Protected Campus Architectural Photo with Graceful Dual-Path Fallback (Requirement 1.C) */}
                <div className="lg:col-span-6">
                  <div className="relative rounded-xl overflow-hidden border border-slate-200 shadow-xl bg-slate-100 group">
                    <img
                      src={campusHeroImage || '/campus_hero.jpg'}
                      onError={(e) => {
                        const target = e.currentTarget;
                        if (target.src !== window.location.origin + '/campus_hero.jpg') {
                          target.src = '/campus_hero.jpg';
                        }
                      }}
                      alt="University Campus Library and Academic Grounds"
                      className="w-full h-[320px] sm:h-[380px] object-cover transition-transform duration-700 group-hover:scale-102"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950/85 via-slate-950/20 to-transparent flex items-end p-6">
                      <div className="text-white">
                        <p className="text-xs font-mono uppercase tracking-widest text-red-400 font-bold">
                          Collegiate Central Registry
                        </p>
                        <p className="text-sm font-semibold text-slate-100 mt-0.5">
                          Veritas et Scientia · Campus Headquarters & Library
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* Quick Four Portal Highlights Grid */}
          <section id="portals" className="py-12 bg-slate-50 border-b border-slate-200">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="text-center max-w-2xl mx-auto mb-10">
                <h2 className="text-2xl font-bold text-slate-900 tracking-tight">
                  Institutional Portals
                </h2>
                <p className="text-xs text-slate-500 mt-1">
                  Click any portal to log in with your verified institutional account.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {portalCards.map((portal) => {
                  const Icon = portal.icon;
                  return (
                    <div
                      key={portal.role}
                      onClick={() => handleOpenPortalLogin(portal.role)}
                      className="bg-white rounded-lg border border-slate-200 p-6 hover:border-red-600 hover:shadow-lg transition-all cursor-pointer flex flex-col justify-between group"
                    >
                      <div>
                        <div className="w-10 h-10 rounded-md bg-red-50 text-red-600 flex items-center justify-center mb-4 group-hover:bg-red-600 group-hover:text-white transition-colors">
                          <Icon className="w-5 h-5" />
                        </div>
                        <h3 className="text-base font-bold text-slate-900">{portal.title}</h3>
                        <p className="text-xs text-slate-500 mt-2 leading-relaxed">
                          {portal.description}
                        </p>
                      </div>
                      <div className="mt-6 pt-4 border-t border-slate-100 flex items-center gap-2">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleOpenPortalLogin(portal.role);
                          }}
                          className="flex-1 py-2 text-xs font-bold text-white bg-red-600 hover:bg-red-700 rounded-md transition-colors text-center shadow-xs"
                        >
                          Sign In
                        </button>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleOpenPortalRegister(portal.role);
                          }}
                          className="flex-1 py-2 text-xs font-semibold text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors text-center"
                        >
                          Register
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </section>

          {/* SECTION 6: PROFESSIONAL HOMEPAGE AND WEBSITE WORKFLOW SECTION */}

          {/* 6.1 About the Platform */}
          <section id="about" className="py-16 bg-white border-b border-slate-200">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
                <div className="lg:col-span-5">
                  <div className="text-xs font-bold font-mono text-red-600 uppercase tracking-widest mb-1">
                    Institutional Mandate
                  </div>
                  <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight leading-tight">
                    About CC Campus Connect
                  </h2>
                  <p className="text-xs sm:text-sm text-slate-600 mt-3 leading-relaxed">
                    Traditional college administration suffers from scattered WhatsApp groups, informal notices, unverified rumors, and lack of accountability in grievance redressal.
                  </p>
                  <p className="text-xs sm:text-sm text-slate-600 mt-3 leading-relaxed">
                    CC Campus Connect resolves these systemic problems by introducing an authoritative, role-governed digital ecosystem where every notice is certified, every grievance has a binding SLA, and communication respects institutional hierarchy.
                  </p>
                </div>

                <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="p-4 bg-slate-50 rounded-lg border border-slate-200">
                    <Volume2 className="w-5 h-5 text-red-600 mb-2" />
                    <h4 className="text-xs font-bold text-slate-900">Official Notices vs. Chat</h4>
                    <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                      Official college directives are separated from chatter. High-impact half-day notices require executive confirmation and record timestamps.
                    </p>
                  </div>

                  <div className="p-4 bg-slate-50 rounded-lg border border-slate-200">
                    <ShieldAlert className="w-5 h-5 text-amber-600 mb-2" />
                    <h4 className="text-xs font-bold text-slate-900">Binding Grievance SLAs</h4>
                    <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                      Petitions are confidential. Cases auto-escalate from Class Advisor to HOD and Principal if unresolved within specified due dates.
                    </p>
                  </div>

                  <div className="p-4 bg-slate-50 rounded-lg border border-slate-200">
                    <Lock className="w-5 h-5 text-blue-600 mb-2" />
                    <h4 className="text-xs font-bold text-slate-900">Cryptographic Privacy</h4>
                    <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                      Passwords hashed with salted SHA-256; private messaging is participant-only; and suggestions support guaranteed anonymous submissions.
                    </p>
                  </div>

                  <div className="p-4 bg-slate-50 rounded-lg border border-slate-200">
                    <FileText className="w-5 h-5 text-emerald-600 mb-2" />
                    <h4 className="text-xs font-bold text-slate-900">Verifiable Audit Exports</h4>
                    <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                      Generates real CSV, Microsoft Excel (XML), and formal printable PDF audit summaries directly from database records.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* 6.2 How It Works (Visual 8-Step Interactive Workflow) */}
          <section id="workflow" className="py-16 bg-slate-50 border-b border-slate-200">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="text-center max-w-2xl mx-auto mb-12">
                <span className="text-xs font-mono font-bold text-red-600 uppercase tracking-widest">
                  End-to-End Governance Lifecycle
                </span>
                <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight mt-1">
                  How Campus Connect Operates
                </h2>
                <p className="text-xs text-slate-500 mt-1">
                  A predictable, secure eight-step institutional workflow from entry to session termination.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {[
                  { step: '01', title: 'Portal Selection', desc: 'Visitor clicks "Four Portal Access" and selects their designated collegiate role.' },
                  { step: '02', title: 'Authentication', desc: 'Secure login via institutional email / register number with salted password verification.' },
                  { step: '03', title: 'Scope Enforcement', desc: 'Server validates active role and binds session exclusively to the authorized portal.' },
                  { step: '04', title: 'Command Dashboard', desc: 'User lands in their dedicated workspace displaying genuine database records.' },
                  { step: '05', title: 'Official Bulletins', desc: 'Publish or read official circulars, timetable adjustments, and half-day decrees.' },
                  { step: '06', title: 'Private & Case Flow', desc: 'Consult authorized mentors privately or submit confidential petitions with SLA tracking.' },
                  { step: '07', title: 'Direct Notifications', desc: 'Click any notification to automatically open its full record and update unread count.' },
                  { step: '08', title: 'Session Invalidation', desc: 'Explicit logout invalidates session token and returns to public landing page.' },
                ].map((s) => (
                  <div key={s.step} className="p-5 bg-white rounded-lg border border-slate-200 shadow-2xs">
                    <span className="text-xs font-mono font-bold text-red-600">{s.step}</span>
                    <h3 className="text-xs font-bold text-slate-900 mt-1">{s.title}</h3>
                    <p className="text-[11px] text-slate-500 mt-1.5 leading-relaxed">{s.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          </section>

          {/* 6.3 Portal Responsibilities Matrix */}
          <section className="py-16 bg-white border-b border-slate-200">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="text-center max-w-2xl mx-auto mb-10">
                <span className="text-xs font-mono font-bold text-red-600 uppercase tracking-widest">
                  Permission Boundaries
                </span>
                <h2 className="text-2xl font-bold text-slate-900 tracking-tight mt-1">
                  Portal Responsibilities & Scopes
                </h2>
              </div>

              <div className="overflow-x-auto border border-slate-200 rounded-lg">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-700 font-semibold border-b border-slate-200">
                    <tr>
                      <th className="py-3 px-4">Functional Area</th>
                      <th className="py-3 px-4">Student</th>
                      <th className="py-3 px-4">Faculty / Advisor</th>
                      <th className="py-3 px-4">HOD (Department Head)</th>
                      <th className="py-3 px-4">Principal (Executive Authority)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-slate-600">
                    <tr>
                      <td className="py-3 px-4 font-semibold text-slate-800">Official Notices</td>
                      <td className="py-3 px-4">Read & Acknowledge</td>
                      <td className="py-3 px-4">Publish Class Notices</td>
                      <td className="py-3 px-4">Publish Dept Circulars</td>
                      <td className="py-3 px-4 font-bold text-red-600">College-Wide & Half-Day</td>
                    </tr>
                    <tr>
                      <td className="py-3 px-4 font-semibold text-slate-800">Private Messaging</td>
                      <td className="py-3 px-4">Assigned Advisor only</td>
                      <td className="py-3 px-4">Assigned Students, HOD, Principal</td>
                      <td className="py-3 px-4">Advisors & Principal</td>
                      <td className="py-3 px-4">All HODs & Advisors</td>
                    </tr>
                    <tr>
                      <td className="py-3 px-4 font-semibold text-slate-800">Grievances</td>
                      <td className="py-3 px-4">Submit & Track</td>
                      <td className="py-3 px-4">First-Level Review / Escalate</td>
                      <td className="py-3 px-4">Departmental Adjudication</td>
                      <td className="py-3 px-4 font-bold text-red-600">Supreme Adjudication</td>
                    </tr>
                    <tr>
                      <td className="py-3 px-4 font-semibold text-slate-800">Suggestions</td>
                      <td className="py-3 px-4">Submit (Anonymous opt.)</td>
                      <td className="py-3 px-4">Review & Note</td>
                      <td className="py-3 px-4">Approve / Decline (Dept)</td>
                      <td className="py-3 px-4">Campus Strategy Review</td>
                    </tr>
                    <tr>
                      <td className="py-3 px-4 font-semibold text-slate-800">Audit Reports</td>
                      <td className="py-3 px-4">Restricted</td>
                      <td className="py-3 px-4">Section CSV Export</td>
                      <td className="py-3 px-4">Department Exports</td>
                      <td className="py-3 px-4 font-bold text-red-600">Full PDF / Excel / CSV</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </section>

          {/* 6.4 Frequently Asked Questions */}
          <section id="faq" className="py-16 bg-slate-50 border-b border-slate-200">
            <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="text-center mb-10">
                <span className="text-xs font-mono font-bold text-red-600 uppercase tracking-widest">
                  Help & Guidance
                </span>
                <h2 className="text-2xl font-bold text-slate-900 tracking-tight mt-1">
                  Frequently Asked Questions
                </h2>
              </div>

              <div className="space-y-3">
                {[
                  {
                    q: 'How do students register for the platform?',
                    a: 'Students navigate to "Four Portal Access", select "Student Portal", and click "Self-Registration". You select your department, course, academic batch, and section (or enter custom ones). Passwords must be at least 8 characters long.'
                  },
                  {
                    q: 'Can students from all engineering, science, and management departments register?',
                    a: 'Yes. CC Campus Connect dynamically supports all institutional departments (CSE, IT, AI&DS, ECE, EEE, MECH, Civil, Chemical, Biomedical, Aerospace, MCA, MBA, and custom departments).'
                  },
                  {
                    q: 'Why is self-registration disabled for Principal and HOD portals?',
                    a: 'Executive and Department Head accounts have access to high-impact college circulars, faculty oversight, and institutional audit records. For security compliance, these accounts cannot be self-registered publicly and are provisioned through executive administrative onboarding.'
                  },
                  {
                    q: 'How does the Half-Day Notice system work?',
                    a: 'When institutional leadership declares a half-day schedule adjustment, the Principal specifies the effective date, start and end working hours, and confirms the decree. The system broadcasts an immediate notice to all faculty and students.'
                  },
                  {
                    q: 'Are grievance submissions visible to other students?',
                    a: 'No. Grievances are strictly confidential. A filed petition is visible only to the submitting student, the assigned Class Advisor, and escalating authorities (HOD and Principal). Private case notes remain isolated from public channels.'
                  },
                  {
                    q: 'What happens when I click a notification?',
                    a: 'Clicking any notification opens the complete message detail view automatically, updates your unread counter in the persistent database, and provides a direct button to navigate to the associated record (announcement, case, or message).'
                  },
                  {
                    q: 'How can I switch portals once logged in?',
                    a: 'For security and role isolation, portal switching is intentionally prohibited while authenticated. To enter another portal, you must explicitly click "Log Out" in the header to terminate your session, then authenticate into the target portal.'
                  }
                ].map((item, idx) => {
                  const isOpen = openFaq === idx;
                  return (
                    <div key={idx} className="bg-white rounded-lg border border-slate-200 overflow-hidden">
                      <button
                        onClick={() => setOpenFaq(isOpen ? null : idx)}
                        className="w-full p-4 text-left flex items-center justify-between text-xs font-bold text-slate-900 hover:bg-slate-50 transition-colors"
                      >
                        <span>{item.q}</span>
                        {isOpen ? <ChevronUp className="w-4 h-4 text-slate-400 shrink-0" /> : <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />}
                      </button>
                      {isOpen && (
                        <div className="px-4 pb-4 text-xs text-slate-600 leading-relaxed border-t border-slate-100 pt-2">
                          {item.a}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </section>

          {/* 6.5 Professional Footer */}
          <footer className="bg-slate-900 text-white py-12 text-xs">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8 pb-8 border-b border-slate-800">
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded bg-red-600 text-white font-bold flex items-center justify-center text-xs">CC</div>
                    <span className="font-bold text-sm">CC Campus Connect</span>
                  </div>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    Enterprise collegiate management platform uniting leadership, faculty, and student discourse under rigorous governance.
                  </p>
                </div>

                <div>
                  <h4 className="font-bold text-xs uppercase tracking-wider text-slate-200 mb-3">Institutional Portals</h4>
                  <ul className="space-y-1.5 text-slate-400 text-[11px]">
                    <li><button onClick={() => handleOpenPortalLogin('STUDENT')} className="hover:text-white">Student Portal</button></li>
                    <li><button onClick={() => handleOpenPortalLogin('ADVISOR')} className="hover:text-white">Faculty / Advisor Portal</button></li>
                    <li><button onClick={() => handleOpenPortalLogin('HOD')} className="hover:text-white">Head of Department (HOD)</button></li>
                    <li><button onClick={() => handleOpenPortalLogin('PRINCIPAL')} className="hover:text-white">Executive Principal Portal</button></li>
                  </ul>
                </div>

                <div>
                  <h4 className="font-bold text-xs uppercase tracking-wider text-slate-200 mb-3">Governance & Policies</h4>
                  <ul className="space-y-1.5 text-slate-400 text-[11px]">
                    <li><button onClick={() => setShowPrivacyModal(true)} className="hover:text-white">Privacy & Data Protection</button></li>
                    <li><button onClick={() => setShowTermsModal(true)} className="hover:text-white">Collegiate Terms of Service</button></li>
                    <li><a href="#workflow" className="hover:text-white">Workflow Architecture</a></li>
                    <li><a href="#faq" className="hover:text-white">Frequently Asked Questions</a></li>
                  </ul>
                </div>

                <div>
                  <h4 className="font-bold text-xs uppercase tracking-wider text-slate-200 mb-3">Campus Central Office</h4>
                  <p className="text-[11px] text-slate-400 leading-relaxed font-mono">
                    Registrar Office, Building A<br />
                    University Academic Enclave<br />
                    Support: admin@campusconnect.edu<br />
                    Emergency Redressal Desk: Room 104
                  </p>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row items-center justify-between gap-2 text-slate-500 text-[11px] font-mono">
                <div>&copy; {new Date().getFullYear()} CC Campus Connect. All rights reserved.</div>
                <div>Role-Based Access Control · Cryptographic Password Protection</div>
              </div>
            </div>
          </footer>
        </main>
      )}

      {/* Privacy Policy Modal */}
      {showPrivacyModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="w-full max-w-lg bg-white rounded-lg shadow-xl border border-slate-200 p-6 space-y-4">
            <h3 className="text-base font-bold text-slate-900">Institutional Privacy Policy</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              CC Campus Connect is committed to strict data confidentiality. Student grievances and private advisories are stored in encrypted, isolated scopes accessible solely to authorized mentors and adjudicating authorities.
            </p>
            <p className="text-xs text-slate-600 leading-relaxed">
              Student suggestions flagged as "Anonymous" have all identifying references severed from review interfaces.
            </p>
            <div className="text-right pt-2 border-t border-slate-100">
              <button
                onClick={() => setShowPrivacyModal(false)}
                className="px-4 py-2 text-xs font-bold text-white bg-slate-900 rounded-md"
              >
                Acknowledge & Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Terms of Service Modal */}
      {showTermsModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="w-full max-w-lg bg-white rounded-lg shadow-xl border border-slate-200 p-6 space-y-4">
            <h3 className="text-base font-bold text-slate-900">Collegiate Terms of Service</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Access to CC Campus Connect is limited to verified collegiate students, faculty, and administrative staff. Any unauthorized access attempts, forged circulars, or harassment will be logged in the immutable audit registry and subject to disciplinary review.
            </p>
            <div className="text-right pt-2 border-t border-slate-100">
              <button
                onClick={() => setShowTermsModal(false)}
                className="px-4 py-2 text-xs font-bold text-white bg-slate-900 rounded-md"
              >
                Acknowledge & Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
