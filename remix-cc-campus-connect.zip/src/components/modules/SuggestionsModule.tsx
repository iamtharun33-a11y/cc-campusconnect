import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { storageService } from '../../services/storage';
import { Suggestion, SuggestionCategory, SuggestionStatus } from '../../types';
import { EmptyState } from '../common/EmptyState';
import {
  Lightbulb,
  Plus,
  EyeOff,
  User as UserIcon,
  CheckCircle2,
  Clock,
  Sparkles,
  Building,
  Filter
} from 'lucide-react';

export const SuggestionsModule: React.FC = () => {
  const { currentUser } = useAuth();
  const [selectedSugId, setSelectedSugId] = useState<string | null>(null);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showReviewModal, setShowReviewModal] = useState(false);

  // Form state
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<SuggestionCategory>('CAMPUS_INFRASTRUCTURE');
  const [isAnonymous, setIsAnonymous] = useState(false);

  // Review status update state
  const [targetStatus, setTargetStatus] = useState<SuggestionStatus>('UNDER_REVIEW');
  const [officialResponse, setOfficialResponse] = useState('');
  const [internalNotes, setInternalNotes] = useState('');

  if (!currentUser) return null;

  const suggestions = storageService.getSuggestionsForUser(currentUser);
  const activeSuggestion = suggestions.find(s => s.id === selectedSugId || s.referenceNo === selectedSugId) || suggestions[0];

  const handleCreateSuggestion = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !description.trim()) return;

    const newSug = storageService.createSuggestion(currentUser, {
      title,
      description,
      category,
      isAnonymous
    });

    setTitle('');
    setDescription('');
    setCategory('CAMPUS_INFRASTRUCTURE');
    setIsAnonymous(false);
    setShowCreateModal(false);
    setSelectedSugId(newSug.id);
  };

  const handleUpdateStatus = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeSuggestion) return;

    storageService.updateSuggestionStatus(
      activeSuggestion.id,
      currentUser,
      targetStatus,
      officialResponse,
      internalNotes
    );

    setOfficialResponse('');
    setInternalNotes('');
    setShowReviewModal(false);
  };

  const canReview = currentUser.role !== 'STUDENT';

  return (
    <div className="space-y-4">
      {/* Top Banner */}
      <div className="bg-white p-4 rounded-lg border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">Campus Suggestions & Feedback</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Constructive student proposals for infrastructural development, academic improvements, and campus amenities.
          </p>
        </div>

        {currentUser.role === 'STUDENT' && (
          <button
            onClick={() => setShowCreateModal(true)}
            className="px-3.5 py-2 text-xs font-bold text-white bg-red-600 hover:bg-red-700 rounded-md transition-colors flex items-center gap-1.5 shadow-xs"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Submit Proposal</span>
          </button>
        )}
      </div>

      {suggestions.length === 0 ? (
        <EmptyState
          icon={Lightbulb}
          title="No Suggestions Logged"
          description={
            currentUser.role === 'STUDENT'
              ? 'You have not submitted any campus suggestions yet. Share your feedback to help enhance collegiate facilities.'
              : 'There are no student proposals or feedback items pending review in this scope.'
          }
          actionLabel={currentUser.role === 'STUDENT' ? 'Submit First Proposal' : undefined}
          onAction={currentUser.role === 'STUDENT' ? () => setShowCreateModal(true) : undefined}
        />
      ) : (
        <div className="bg-white rounded-lg border border-slate-200 min-h-[580px] flex flex-col md:flex-row overflow-hidden">
          {/* Left Suggestions List */}
          <div className="w-full md:w-80 border-r border-slate-200 flex flex-col bg-slate-50/40">
            <div className="p-3 border-b border-slate-200 font-bold text-xs text-slate-800 uppercase tracking-wider bg-white flex items-center justify-between">
              <span>Proposals ({suggestions.length})</span>
              <span className="text-[10px] text-slate-400 font-mono">Registry</span>
            </div>

            <div className="flex-1 overflow-y-auto divide-y divide-slate-100">
              {suggestions.map((s) => {
                const isSelected = activeSuggestion?.id === s.id;
                return (
                  <button
                    key={s.id}
                    onClick={() => setSelectedSugId(s.id)}
                    className={`w-full p-3 text-left transition-colors flex flex-col ${
                      isSelected ? 'bg-white border-l-2 border-red-600' : 'hover:bg-slate-100/60'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-1 text-[11px] font-mono">
                      <span className="font-bold text-slate-900">{s.referenceNo}</span>
                      <span className="text-slate-400">{s.createdAt.split('T')[0]}</span>
                    </div>

                    <span className="text-xs font-semibold text-slate-800 truncate mt-1">{s.title}</span>

                    <div className="flex items-center justify-between text-[11px] text-slate-500 mt-1">
                      <span>{s.category.replace('_', ' ')}</span>
                      <span className="font-mono font-semibold text-slate-700">{s.status.replace('_', ' ')}</span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Right Suggestion Detail */}
          <div className="flex-1 flex flex-col bg-white overflow-y-auto">
            {activeSuggestion ? (
              <div className="p-6 space-y-6">
                {/* Header */}
                <div className="flex flex-wrap items-start justify-between gap-3 border-b border-slate-200 pb-4">
                  <div>
                    <div className="flex items-center gap-2 text-xs text-slate-500 font-mono">
                      <span className="font-bold text-slate-900">{activeSuggestion.referenceNo}</span>
                      <span aria-hidden="true">·</span>
                      <span>Category: {activeSuggestion.category.replace('_', ' ')}</span>
                      <span aria-hidden="true">·</span>
                      <span>Status: {activeSuggestion.status.replace('_', ' ')}</span>
                    </div>

                    <h2 className="text-base font-bold text-slate-900 mt-1">{activeSuggestion.title}</h2>

                    <div className="flex items-center gap-2 text-xs text-slate-500 mt-1">
                      {activeSuggestion.isAnonymous ? (
                        <span className="flex items-center gap-1 text-slate-600 italic">
                          <EyeOff className="w-3.5 h-3.5 text-slate-400" />
                          Anonymous Student
                        </span>
                      ) : (
                        <span>Submitted by: <strong>{activeSuggestion.studentName}</strong></span>
                      )}
                      <span aria-hidden="true">·</span>
                      <span>Dept: {activeSuggestion.departmentName}</span>
                    </div>
                  </div>

                  {canReview && (
                    <button
                      onClick={() => {
                        setTargetStatus(activeSuggestion.status);
                        setOfficialResponse(activeSuggestion.officialResponse || '');
                        setInternalNotes(activeSuggestion.internalNotes || '');
                        setShowReviewModal(true);
                      }}
                      className="px-3.5 py-1.5 text-xs font-bold text-white bg-red-600 hover:bg-red-700 rounded-md transition-colors flex items-center gap-1 shadow-xs"
                    >
                      <span>Update Review & Decision</span>
                    </button>
                  )}
                </div>

                {/* Description */}
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-1">
                    Proposal Description
                  </h4>
                  <div className="p-3.5 bg-slate-50 rounded-md border border-slate-200 text-xs text-slate-800 leading-relaxed whitespace-pre-line">
                    {activeSuggestion.description}
                  </div>
                </div>

                {/* Official Response */}
                {activeSuggestion.officialResponse && (
                  <div className="p-4 bg-emerald-50/70 border border-emerald-200 rounded-md">
                    <div className="flex items-center gap-2 text-emerald-800 font-bold text-xs">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      <span>Official Institutional Response</span>
                    </div>
                    <p className="text-xs text-emerald-900 mt-1.5 leading-relaxed">
                      {activeSuggestion.officialResponse}
                    </p>
                    <div className="text-[10px] text-emerald-700 font-mono mt-2">
                      Reviewed by {activeSuggestion.reviewerName} ({activeSuggestion.reviewerRole})
                    </div>
                  </div>
                )}

                {/* Internal Notes (Staff-only) */}
                {currentUser.role !== 'STUDENT' && activeSuggestion.internalNotes && (
                  <div className="p-3.5 bg-amber-50/50 border border-amber-200 rounded-md">
                    <h5 className="text-xs font-bold text-amber-900 uppercase tracking-wider mb-1">
                      Staff Deliberation Notes (Internal Only)
                    </h5>
                    <p className="text-xs text-amber-800 font-mono whitespace-pre-line">
                      {activeSuggestion.internalNotes}
                    </p>
                  </div>
                )}
              </div>
            ) : null}
          </div>
        </div>
      )}

      {/* New Proposal Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="w-full max-w-lg bg-white rounded-lg shadow-xl border border-slate-200 p-6">
            <h3 className="text-base font-bold text-slate-900">Submit Campus Improvement Proposal</h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Propose enhancements to institutional amenities, academic delivery, or student life.
            </p>

            <form onSubmit={handleCreateSuggestion} className="mt-4 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Proposal Title *</label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Extended Library Hours During Midterms"
                  className="w-full text-xs p-2.5 rounded-md border border-slate-300 focus:border-red-600 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Category</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as SuggestionCategory)}
                  className="w-full text-xs p-2 rounded-md border border-slate-300 bg-white"
                >
                  <option value="CAMPUS_INFRASTRUCTURE">Campus Infrastructure & Labs</option>
                  <option value="ACADEMIC_CURRICULUM">Academic Curriculum & Seminars</option>
                  <option value="LIBRARY_RESOURCES">Library & Digital Resources</option>
                  <option value="HOSTEL_MESS">Hostel & Dining Facilities</option>
                  <option value="SPORTS_CULTURE">Sports & Cultural Activities</option>
                  <option value="OTHER">General Campus Operations</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Proposal Details & Rationale *</label>
                <textarea
                  required
                  rows={4}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Detail the suggested enhancement and its positive impact on the collegiate community..."
                  className="w-full text-xs p-2.5 rounded-md border border-slate-300 focus:border-red-600 focus:outline-hidden"
                />
              </div>

              {/* Requirement 155: Anonymous suggestion toggle */}
              <div className="p-3 bg-slate-50 rounded-md border border-slate-200">
                <label className="flex items-center gap-2.5 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isAnonymous}
                    onChange={(e) => setIsAnonymous(e.target.checked)}
                    className="rounded text-red-600 focus:ring-red-500"
                  />
                  <div>
                    <span className="text-xs font-bold text-slate-800">Submit Anonymously</span>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      Your identity will be concealed from all faculty and administration reviews.
                    </p>
                  </div>
                </label>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-3.5 py-2 text-xs font-medium text-slate-600 hover:text-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-bold text-white bg-red-600 hover:bg-red-700 rounded-md transition-colors"
                >
                  Submit Proposal
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Review Modal */}
      {showReviewModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-white rounded-lg shadow-xl border border-slate-200 p-6">
            <h3 className="text-base font-bold text-slate-900">Review Proposal {activeSuggestion?.referenceNo}</h3>
            <p className="text-xs text-slate-500 mt-0.5">Record institutional decision and official feedback.</p>

            <form onSubmit={handleUpdateStatus} className="mt-4 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Status Decision</label>
                <select
                  value={targetStatus}
                  onChange={(e) => setTargetStatus(e.target.value as SuggestionStatus)}
                  className="w-full text-xs p-2 rounded-md border border-slate-300 bg-white"
                >
                  <option value="UNDER_REVIEW">Under Review</option>
                  <option value="ACCEPTED">Accepted / Approved</option>
                  <option value="IMPLEMENTED">Implemented</option>
                  <option value="REJECTED">Declined / Infeasible</option>
                  <option value="CLOSED">Closed</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Official Response (Visible to Student)</label>
                <textarea
                  rows={3}
                  value={officialResponse}
                  onChange={(e) => setOfficialResponse(e.target.value)}
                  placeholder="Explain the administration's decision or planned implementation schedule..."
                  className="w-full text-xs p-2.5 rounded-md border border-slate-300 focus:border-red-600 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Internal Notes (Staff Only)</label>
                <textarea
                  rows={2}
                  value={internalNotes}
                  onChange={(e) => setInternalNotes(e.target.value)}
                  placeholder="Budget allocations, committee deliberations, or facility vendor notes..."
                  className="w-full text-xs p-2.5 rounded-md border border-slate-300 focus:border-red-600 focus:outline-hidden"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setShowReviewModal(false)}
                  className="px-3.5 py-2 text-xs font-medium text-slate-600 hover:text-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-bold text-white bg-red-600 hover:bg-red-700 rounded-md transition-colors"
                >
                  Save Review Decision
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
