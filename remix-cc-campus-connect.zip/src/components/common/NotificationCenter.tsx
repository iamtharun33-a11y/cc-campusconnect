import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { storageService } from '../../services/storage';
import { NotificationItem } from '../../types';
import {
  Bell,
  Check,
  X,
  MessageSquare,
  AlertCircle,
  Volume2,
  Lightbulb,
  ArrowRight,
  Clock,
  User as UserIcon,
  CheckCheck
} from 'lucide-react';

interface NotificationCenterProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (module: string, id?: string) => void;
}

export const NotificationCenter: React.FC<NotificationCenterProps> = ({
  isOpen,
  onClose,
  onNavigate
}) => {
  const { currentUser } = useAuth();
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [filterTab, setFilterTab] = useState<'all' | 'unread'>('all');
  const [selectedNotification, setSelectedNotification] = useState<NotificationItem | null>(null);

  const loadNotifications = () => {
    if (currentUser) {
      const list = storageService.getNotificationsForUser(currentUser.id);
      setNotifications(list);
    }
  };

  useEffect(() => {
    if (isOpen) {
      loadNotifications();
      setSelectedNotification(null);
    }
  }, [currentUser, isOpen]);

  if (!isOpen || !currentUser) return null;

  const handleMarkAllRead = () => {
    storageService.markAllNotificationsAsRead(currentUser.id);
    loadNotifications();
  };

  const handleOpenNotification = (notif: NotificationItem) => {
    // 1. Mark as read immediately in storage
    storageService.markNotificationAsRead(notif.id);
    loadNotifications();

    // 2. Open full detail view automatically (Requirement 5)
    setSelectedNotification({ ...notif, isRead: true });
  };

  const handleNavigateToRecord = () => {
    if (selectedNotification?.linkTarget) {
      const { module, id } = selectedNotification.linkTarget;
      setSelectedNotification(null);
      onClose();
      onNavigate(module, id);
    }
  };

  const filteredList = notifications.filter(n => {
    if (filterTab === 'unread') return !n.isRead;
    return true;
  });

  const unreadCount = notifications.filter(n => !n.isRead).length;

  const getIcon = (type: NotificationItem['type']) => {
    switch (type) {
      case 'MESSAGE':
        return <MessageSquare className="w-4 h-4 text-blue-600" />;
      case 'ANNOUNCEMENT':
        return <Volume2 className="w-4 h-4 text-red-600" />;
      case 'GRIEVANCE':
        return <AlertCircle className="w-4 h-4 text-amber-600" />;
      case 'SUGGESTION':
        return <Lightbulb className="w-4 h-4 text-emerald-600" />;
      default:
        return <Bell className="w-4 h-4 text-slate-500" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-slate-900/40 backdrop-blur-xs flex justify-end">
      <div className="w-full max-w-md bg-white h-full shadow-2xl flex flex-col border-l border-slate-200 animate-in slide-in-from-right duration-200">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2">
            <Bell className="w-5 h-5 text-slate-800" />
            <h2 className="text-sm font-bold text-slate-900">Notification Center</h2>
            {unreadCount > 0 && (
              <span className="font-mono text-xs font-bold px-2 py-0.5 bg-red-100 text-red-800 rounded">
                {unreadCount} unread
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            {unreadCount > 0 && (
              <button
                onClick={handleMarkAllRead}
                className="text-xs font-semibold text-slate-600 hover:text-red-700 flex items-center gap-1 transition-colors"
                title="Mark all as read"
              >
                <CheckCheck className="w-3.5 h-3.5" />
                <span>Mark all</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-700 rounded-md transition-colors"
              title="Close panel"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Filters */}
        <div className="px-5 py-2 border-b border-slate-100 bg-white flex items-center gap-2">
          <button
            onClick={() => setFilterTab('all')}
            className={`px-3 py-1 text-xs font-medium rounded transition-colors ${
              filterTab === 'all'
                ? 'bg-slate-900 text-white font-semibold'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            All ({notifications.length})
          </button>
          <button
            onClick={() => setFilterTab('unread')}
            className={`px-3 py-1 text-xs font-medium rounded transition-colors ${
              filterTab === 'unread'
                ? 'bg-slate-900 text-white font-semibold'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            Unread ({unreadCount})
          </button>
        </div>

        {/* Notification Detail View (Requirement 5: Opened automatically upon click) */}
        {selectedNotification ? (
          <div className="flex-1 flex flex-col p-5 overflow-y-auto bg-slate-50/50">
            <button
              onClick={() => setSelectedNotification(null)}
              className="text-xs font-semibold text-slate-600 hover:text-slate-900 mb-4 inline-flex items-center gap-1 self-start"
            >
              &larr; Back to all notifications
            </button>

            <div className="bg-white rounded-lg border border-slate-200 p-5 shadow-xs space-y-4">
              <div className="flex items-start justify-between gap-2 border-b border-slate-100 pb-3">
                <div className="flex items-center gap-2">
                  <div className="p-2 rounded bg-slate-100">
                    {getIcon(selectedNotification.type)}
                  </div>
                  <div>
                    <span className="text-[11px] font-bold font-mono uppercase tracking-wider text-slate-500">
                      {selectedNotification.type} NOTIFICATION
                    </span>
                    <h3 className="text-sm font-bold text-slate-900 mt-0.5">
                      {selectedNotification.title}
                    </h3>
                  </div>
                </div>
              </div>

              {selectedNotification.senderName && (
                <div className="text-xs text-slate-600 flex items-center gap-1.5">
                  <UserIcon className="w-3.5 h-3.5 text-slate-400" />
                  <span>Sender: <strong>{selectedNotification.senderName}</strong></span>
                  {selectedNotification.senderRole && (
                    <span className="text-[10px] text-slate-400 font-mono">({selectedNotification.senderRole})</span>
                  )}
                </div>
              )}

              <div className="p-3.5 bg-slate-50 rounded-md border border-slate-200 text-xs text-slate-800 leading-relaxed whitespace-pre-wrap">
                {selectedNotification.message}
              </div>

              <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono">
                <span>Received: {new Date(selectedNotification.createdAt).toLocaleString()}</span>
                <span className="text-emerald-700 font-semibold flex items-center gap-1">
                  <Check className="w-3 h-3" /> Read
                </span>
              </div>

              {selectedNotification.linkTarget && (
                <div className="pt-2">
                  <button
                    onClick={handleNavigateToRecord}
                    className="w-full py-2.5 px-3 text-xs font-bold text-white bg-red-600 hover:bg-red-700 rounded-md transition-colors flex items-center justify-center gap-1.5 shadow-xs"
                  >
                    <span>View Associated Record</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}
            </div>
          </div>
        ) : (
          /* Notifications List */
          <div className="flex-1 overflow-y-auto divide-y divide-slate-100">
            {filteredList.length === 0 ? (
              <div className="p-8 text-center text-slate-500">
                <Bell className="w-8 h-8 mx-auto text-slate-300 mb-2" />
                <p className="text-sm font-semibold text-slate-700">No Notifications</p>
                <p className="text-xs text-slate-400 mt-0.5">
                  {filterTab === 'unread' ? 'You have no unread notifications.' : 'All collegiate circulars, advisory notes, and case alerts will appear here.'}
                </p>
              </div>
            ) : (
              filteredList.map((notif) => (
                <div
                  key={notif.id}
                  onClick={() => handleOpenNotification(notif)}
                  className={`p-4 hover:bg-slate-50 cursor-pointer transition-colors flex items-start gap-3 ${
                    !notif.isRead ? 'bg-red-50/30' : ''
                  }`}
                >
                  <div className="mt-0.5 p-1.5 bg-white border border-slate-200 rounded-md shrink-0 shadow-2xs">
                    {getIcon(notif.type)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <p className={`text-xs font-semibold truncate ${!notif.isRead ? 'text-slate-900 font-bold' : 'text-slate-700'}`}>
                        {notif.title}
                      </p>
                      <span className="text-[11px] text-slate-400 shrink-0 font-mono">
                        {new Date(notif.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>

                    <p className="text-xs text-slate-600 mt-1 line-clamp-2 leading-relaxed">
                      {notif.message}
                    </p>

                    <div className="flex items-center justify-between text-[11px] text-slate-400 mt-1 font-mono">
                      <span>{notif.senderName ? `From: ${notif.senderName}` : notif.type}</span>
                      {!notif.isRead && (
                        <span className="w-2 h-2 rounded-full bg-red-600 inline-block" />
                      )}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
};
