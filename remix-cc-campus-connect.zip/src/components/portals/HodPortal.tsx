import React, { useState, useMemo } from 'react';
import { useAuth } from '../../context/AuthContext';
import { storageService } from '../../services/storage';
import { User, CollegeClass, Grievance, Suggestion, Announcement } from '../../types';
import {
  Building2,
  Users,
  GraduationCap,
  AlertCircle,
  Lightbulb,
  ShieldAlert,
  BarChart3,
  Download,
  Plus,
  Search,
  Filter,
  CheckCircle2,
  XCircle,
  Clock,
  MessageSquare,
  ArrowUpRight,
  Send,
  Eye,
  LogOut,
  ChevronRight,
  UserCheck,
  Calendar,
  Layers,
  FileSpreadsheet,
  HelpCircle,
  X,
  FileText
} from 'lucide-react';

interface HodPortalProps {
  onNavigate: (tab: string) => void;
  onOpenExport: () => void;
}

export const HodPortal: React.FC<HodPortalProps> = ({ onNavigate, onOpenExport }) => {
  const { currentUser, logout } = useAuth();
  if (!currentUser) return null;

  // Active sub-view in HOD command center
  const [activeTab, setActiveTab] = useState<'overview' | 'students' | 'advisors' | 'sections' | 'grievances' | 'suggestions' | 'academics'>('overview');

  // Search & Filter States
  const [studentSearch, setStudentSearch] = useState('');
  const [studentYearFilter, setStudentYearFilter] = useState('ALL');
  const [studentSectionFilter, setStudentSectionFilter] = useState('ALL');

  const [grievanceFilter, setGrievanceFilter] = useState<'ALL' | 'ESCALATED_HOD' | 'ADVISOR_REVIEW' | 'RESOLVED'>('ALL');
  const [suggestionFilter, setSuggestionFilter] = useState<'ALL' | 'SUBMITTED' | 'UNDER_REVIEW' | 'ACCEPTED' | 'REJECTED'>('ALL');

  // Modals
  const [showAddClassModal, setShowAddClassModal] = useState(false);
  const [newClassName, setNewClassName] = useState('');
  const [newClassSemester, setNewClassSemester] = useState(5);
  const [newClassAdvisorId, setNewClassAdvisorId] = useState('');

  const [escalateModalGrievance, setEscalateModalGrievance] = useState<Grievance | null>(null);
  const [escalateReason, setEscalateReason] = useState('');

  const [reviewSuggestionModal, setReviewSuggestionModal] = useState<Suggestion | null>(null);
  const [suggestionOfficialResponse, setSuggestionOfficialResponse] = useState('');

  const [showProfileModal, setShowProfileModal] = useState(false);

  // Fetch Department Scoped Data
  const deptId = currentUser.departmentId || 'dep_cse';
  const allUsers = storageService.getUsers();
  const allDeptStudents = allUsers.filter(u => u.role === 'STUDENT' && u.departmentId === deptId);
  const allDeptAdvisors = allUsers.filter(u => u.role === 'ADVISOR' && u.departmentId === deptId);
  const deptClasses = storageService.getClasses().filter(c => c.departmentId === deptId);
  const deptGrievances = storageService.getGrievancesForUser(currentUser);
  const deptSuggestions = storageService.getSuggestionsForUser(currentUser);
  const deptAnnouncements = storageService.getAnnouncementsForUser(currentUser);

  // Escalated Grievances pending HOD intervention
  const escalatedGrievances = deptGrievances.filter(g => g.status === 'ESCALATED_HOD');
  const pendingSuggestions = deptSuggestions.filter(s => s.status === 'SUBMITTED' || s.status === 'UNDER_REVIEW');

  // Key KPI Metrics
  const totalStudents = allDeptStudents.length;
  const totalAdvisors = allDeptAdvisors.length;
  const totalClasses = deptClasses.length;
  const pendingActionsCount = escalatedGrievances.length + pendingSuggestions.length;

  // Filtered Students List
  const filteredStudents = useMemo(() => {
    return allDeptStudents.filter(s => {
      const matchesSearch =
        s.name.toLowerCase().includes(studentSearch.toLowerCase()) ||
        (s.rollNumber && s.rollNumber.toLowerCase().includes(studentSearch.toLowerCase())) ||
        s.email.toLowerCase().includes(studentSearch.toLowerCase());
      
      const matchesYear = studentYearFilter === 'ALL' || s.year === studentYearFilter;
      const matchesSection = studentSectionFilter === 'ALL' || s.section === studentSectionFilter || (s.className && s.className.includes(studentSectionFilter));

      return matchesSearch && matchesYear && matchesSection;
    });
  }, [allDeptStudents, studentSearch, studentYearFilter, studentSectionFilter]);

  // Filtered Grievances
  const filteredGrievances = useMemo(() => {
    return deptGrievances.filter(g => {
      if (grievanceFilter === 'ALL') return true;
      return g.status === grievanceFilter;
    });
  }, [deptGrievances, grievanceFilter]);

  // Filtered Suggestions
  const filteredSuggestions = useMemo(() => {
    return deptSuggestions.filter(s => {
      if (suggestionFilter === 'ALL') return true;
      return s.status === suggestionFilter;
    });
  }, [deptSuggestions, suggestionFilter]);

  // Action: Add new class/section to department
  const handleCreateClass = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newClassName.trim()) return;

    const assignedAdvisor = allDeptAdvisors.find(a => a.id === newClassAdvisorId);
    storageService.findOrCreateClass(deptId, newClassName.trim(), Number(newClassSemester));

    setShowAddClassModal(false);
    setNewClassName('');
    setNewClassSemester(5);
    setNewClassAdvisorId('');
  };

  // Action: Escalate Grievance to Principal
  const handleConfirmEscalation = () => {
    if (!escalateModalGrievance || !escalateReason.trim()) return;

    storageService.escalateGrievance(
      escalateModalGrievance.id,
      currentUser,
      'PRINCIPAL',
      escalateReason.trim()
    );

    setEscalateModalGrievance(null);
    setEscalateReason('');
  };

  // Action: Review / Approve / Decline Suggestion
  const handleUpdateSuggestion = (status: 'ACCEPTED' | 'REJECTED' | 'UNDER_REVIEW') => {
    if (!reviewSuggestionModal) return;

    storageService.updateSuggestionStatus(
      reviewSuggestionModal.id,
      currentUser,
      status,
      suggestionOfficialResponse.trim() || undefined
    );

    setReviewSuggestionModal(null);
    setSuggestionOfficialResponse('');
  };

  // Quick export of Student Roster
  const handleExportStudentRoster = () => {
    const csvRows = [
      ['Student Name', 'Roll Number', 'Email', 'Class', 'Year', 'Semester', 'Status'],
      ...allDeptStudents.map(s => [
        s.name,
        s.rollNumber || 'N/A',
        s.email,
        s.className || 'General',
        s.year || '4th Year',
        s.semester || 7,
        s.isActive ? 'Active' : 'Inactive'
      ])
    ];
    const csvContent = 'data:text/csv;charset=utf-8,' + csvRows.map(e => e.join(',')).join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `${currentUser.departmentName || 'Dept'}_Student_Roster.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* 1. HOD Command Header Banner */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs text-red-600 font-bold uppercase tracking-wider">
            <Building2 className="w-4 h-4" />
            <span>Departmental Executive Command · Head of Department</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 mt-1 tracking-tight">
            {currentUser.name}
          </h1>
          <p className="text-xs text-slate-500 mt-1 font-mono">
            Department: <strong className="text-slate-800">{currentUser.departmentName || 'Computer Science & Engineering'}</strong> · Staff ID: {currentUser.employeeId || 'EMP-CSE-HOD'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => onNavigate('announcements')}
            className="px-3.5 py-2 text-xs font-bold text-white bg-red-600 hover:bg-red-700 rounded-lg transition-colors flex items-center gap-1.5 shadow-xs"
          >
            <Send className="w-3.5 h-3.5" />
            <span>Publish Dept Notice</span>
          </button>

          <button
            onClick={onOpenExport}
            className="px-3.5 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors flex items-center gap-1.5 border border-slate-200"
          >
            <Download className="w-3.5 h-3.5 text-slate-500" />
            <span>Export Reports</span>
          </button>

          <button
            onClick={() => setShowProfileModal(true)}
            className="px-3 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-slate-50 hover:bg-slate-100 rounded-lg transition-colors border border-slate-200"
            title="View HOD Credentials & Session"
          >
            HOD Profile
          </button>
        </div>
      </div>

      {/* 2. Pending Actions Alert Banner */}
      {pendingActionsCount > 0 && (
        <div className="p-4 bg-amber-50/80 border border-amber-200 rounded-xl flex items-start justify-between gap-3 text-xs text-amber-900">
          <div className="flex items-start gap-2.5">
            <ShieldAlert className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-amber-950">
                Action Required: {pendingActionsCount} Pending Items on HOD Desk
              </p>
              <p className="text-[11px] text-amber-800 mt-0.5">
                {escalatedGrievances.length} grievance(s) escalated from class advisors requiring your intervention, and {pendingSuggestions.length} proposal(s) awaiting departmental review.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            {escalatedGrievances.length > 0 && (
              <button
                onClick={() => setActiveTab('grievances')}
                className="px-2.5 py-1 text-[11px] font-bold text-red-700 bg-red-100/80 hover:bg-red-200 rounded border border-red-200 transition-colors"
              >
                View Escalations ({escalatedGrievances.length})
              </button>
            )}
            {pendingSuggestions.length > 0 && (
              <button
                onClick={() => setActiveTab('suggestions')}
                className="px-2.5 py-1 text-[11px] font-bold text-amber-800 bg-amber-100 hover:bg-amber-200 rounded border border-amber-300 transition-colors"
              >
                Review Proposals ({pendingSuggestions.length})
              </button>
            )}
          </div>
        </div>
      )}

      {/* 3. KPI Metrics Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-3">
        <div className="bg-white p-3.5 rounded-xl border border-slate-200">
          <p className="text-[11px] text-slate-500 font-medium">Department Students</p>
          <p className="text-xl font-bold text-slate-900 font-mono tabular-nums mt-1">{totalStudents}</p>
          <p className="text-[10px] text-slate-400 mt-0.5">Enrolled</p>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-slate-200">
          <p className="text-[11px] text-slate-500 font-medium">Class Advisors</p>
          <p className="text-xl font-bold text-slate-900 font-mono tabular-nums mt-1">{totalAdvisors}</p>
          <p className="text-[10px] text-slate-400 mt-0.5">Appointed faculty</p>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-slate-200">
          <p className="text-[11px] text-slate-500 font-medium">Class Sections</p>
          <p className="text-xl font-bold text-slate-900 font-mono tabular-nums mt-1">{totalClasses}</p>
          <p className="text-[10px] text-slate-400 mt-0.5">Active groups</p>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-slate-200">
          <p className="text-[11px] text-red-600 font-medium">HOD Escalations</p>
          <p className="text-xl font-bold text-red-700 font-mono tabular-nums mt-1">{escalatedGrievances.length}</p>
          <p className="text-[10px] text-red-600 font-semibold mt-0.5">Requires ruling</p>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-slate-200">
          <p className="text-[11px] text-slate-500 font-medium">Student Proposals</p>
          <p className="text-xl font-bold text-slate-900 font-mono tabular-nums mt-1">{deptSuggestions.length}</p>
          <p className="text-[10px] text-slate-400 mt-0.5">Submitted</p>
        </div>

        <div className="bg-white p-3.5 rounded-xl border border-slate-200">
          <p className="text-[11px] text-slate-500 font-medium">College Authorities</p>
          <p className="text-xl font-bold text-slate-900 font-mono tabular-nums mt-1">{totalAdvisors + (allUsers.filter(u => u.role === 'PRINCIPAL').length)}</p>
          <p className="text-[10px] text-slate-400 mt-0.5">Advisors & Principal</p>
        </div>
      </div>

      {/* 4. Tab Navigation Bar */}
      <div className="border-b border-slate-200 flex items-center gap-1 overflow-x-auto text-xs font-semibold">
        {[
          { id: 'overview', label: 'Command Overview', icon: Building2 },
          { id: 'students', label: `Student Directory (${totalStudents})`, icon: GraduationCap },
          { id: 'advisors', label: `Advisor Oversight (${totalAdvisors})`, icon: Users },
          { id: 'sections', label: `Class Sections (${totalClasses})`, icon: Layers },
          { id: 'grievances', label: `Escalated Grievances (${escalatedGrievances.length})`, icon: AlertCircle },
          { id: 'suggestions', label: `Suggestions & Feedback (${deptSuggestions.length})`, icon: Lightbulb },
          { id: 'academics', label: 'Department Analytics & Records', icon: BarChart3 }
        ].map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-3.5 py-2.5 flex items-center gap-2 border-b-2 whitespace-nowrap transition-colors ${
                isActive
                  ? 'border-red-600 text-red-600 font-bold bg-red-50/40'
                  : 'border-transparent text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* 5. Sub-Views Content */}

      {/* A. OVERVIEW DASHBOARD */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Urgent Grievance Queue */}
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                  <ShieldAlert className="w-4 h-4 text-red-600" />
                  <span>Cases Escalated to HOD Desk</span>
                </h3>
                <button
                  onClick={() => setActiveTab('grievances')}
                  className="text-xs font-semibold text-red-600 hover:text-red-700"
                >
                  Manage All &rarr;
                </button>
              </div>

              {escalatedGrievances.length === 0 ? (
                <div className="py-8 text-center text-slate-400 text-xs">
                  <CheckCircle2 className="w-8 h-8 mx-auto text-emerald-500 mb-2 opacity-80" />
                  <p className="font-semibold text-slate-700">No Pending Escalations</p>
                  <p className="text-[11px] mt-0.5">All departmental grievance petitions are currently managed at the advisor level.</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {escalatedGrievances.slice(0, 3).map(g => (
                    <div key={g.id} className="p-3.5 bg-red-50/50 rounded-lg border border-red-200 text-xs">
                      <div className="flex items-center justify-between font-mono">
                        <span className="font-bold text-slate-900">{g.caseId}</span>
                        <span className="text-red-700 font-bold uppercase">{g.priority} PRIORITY</span>
                      </div>
                      <h4 className="font-bold text-slate-800 mt-1">{g.title}</h4>
                      <p className="text-slate-600 text-[11px] mt-1 line-clamp-2">{g.description}</p>
                      <div className="flex items-center justify-between text-[11px] text-slate-500 mt-3 pt-2 border-t border-red-100 font-mono">
                        <span>Class: {g.className}</span>
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => setEscalateModalGrievance(g)}
                            className="text-purple-700 font-bold hover:underline"
                          >
                            Escalate to Principal &uarr;
                          </button>
                          <button
                            onClick={() => onNavigate('grievances')}
                            className="text-red-700 font-bold hover:underline"
                          >
                            Hear Case &rarr;
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Department Advisors Quick Oversight */}
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                  <Users className="w-4 h-4 text-slate-700" />
                  <span>Appointed Class Advisors</span>
                </h3>
                <button
                  onClick={() => setActiveTab('advisors')}
                  className="text-xs font-semibold text-red-600 hover:text-red-700"
                >
                  View All &rarr;
                </button>
              </div>

              {allDeptAdvisors.length === 0 ? (
                <p className="text-xs text-slate-400 py-6 text-center">No class advisors currently registered in this department.</p>
              ) : (
                <div className="divide-y divide-slate-100 text-xs">
                  {allDeptAdvisors.map(adv => (
                    <div key={adv.id} className="py-2.5 flex items-center justify-between">
                      <div>
                        <p className="font-bold text-slate-800">{adv.name}</p>
                        <p className="text-[11px] text-slate-500 font-mono">
                          Staff ID: {adv.employeeId || 'N/A'} · Class: {adv.className || 'General Section'}
                        </p>
                      </div>
                      <button
                        onClick={() => onNavigate('messages')}
                        className="px-2.5 py-1 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded border border-slate-200 flex items-center gap-1 transition-colors"
                      >
                        <MessageSquare className="w-3 h-3 text-slate-500" />
                        <span>Message</span>
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Quick Department Bulletins */}
          <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <Building2 className="w-4 h-4 text-red-600" />
                <span>Department Circulars & Bulletins</span>
              </h3>
              <button
                onClick={() => onNavigate('announcements')}
                className="text-xs font-semibold text-red-600 hover:text-red-700"
              >
                Manage Circulars &rarr;
              </button>
            </div>

            {deptAnnouncements.length === 0 ? (
              <p className="text-xs text-slate-400 py-6 text-center">No official department circulars published yet.</p>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                {deptAnnouncements.slice(0, 4).map(notice => (
                  <div key={notice.id} className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                    <div className="flex items-center justify-between text-[11px] font-mono text-slate-500">
                      <span className="font-bold text-red-600">{notice.category}</span>
                      <span>{new Date(notice.createdAt).toLocaleDateString()}</span>
                    </div>
                    <h4 className="font-bold text-slate-900 mt-1">{notice.title}</h4>
                    <p className="text-slate-600 text-[11px] mt-1 line-clamp-2">{notice.content}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* B. STUDENT MANAGEMENT DIRECTORY */}
      {activeTab === 'students' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-5 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Enrolled Student Directory</h3>
              <p className="text-xs text-slate-500">Manage and inspect registered students in {currentUser.departmentName}.</p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleExportStudentRoster}
                className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg border border-slate-200 flex items-center gap-1.5 transition-colors"
              >
                <Download className="w-3.5 h-3.5 text-slate-500" />
                <span>Download CSV</span>
              </button>
            </div>
          </div>

          {/* Search & Filters */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={studentSearch}
                onChange={(e) => setStudentSearch(e.target.value)}
                placeholder="Search by name, roll no, or email..."
                className="w-full pl-9 pr-3 py-2 rounded-lg border border-slate-300 focus:border-red-600 focus:outline-hidden"
              />
            </div>

            <div>
              <select
                value={studentYearFilter}
                onChange={(e) => setStudentYearFilter(e.target.value)}
                className="w-full py-2 px-3 rounded-lg border border-slate-300 bg-white"
              >
                <option value="ALL">All Academic Years</option>
                <option value="1st Year">1st Year</option>
                <option value="2nd Year">2nd Year</option>
                <option value="3rd Year">3rd Year</option>
                <option value="4th Year">4th Year</option>
              </select>
            </div>

            <div>
              <select
                value={studentSectionFilter}
                onChange={(e) => setStudentSectionFilter(e.target.value)}
                className="w-full py-2 px-3 rounded-lg border border-slate-300 bg-white"
              >
                <option value="ALL">All Sections</option>
                <option value="Section A">Section A</option>
                <option value="Section B">Section B</option>
                <option value="Section C">Section C</option>
              </select>
            </div>
          </div>

          {/* Table */}
          <div className="overflow-x-auto border border-slate-200 rounded-lg">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-700 font-semibold border-b border-slate-200">
                <tr>
                  <th className="py-2.5 px-3">Student Name</th>
                  <th className="py-2.5 px-3">Roll Number</th>
                  <th className="py-2.5 px-3">Class & Section</th>
                  <th className="py-2.5 px-3">Year / Sem</th>
                  <th className="py-2.5 px-3">Email</th>
                  <th className="py-2.5 px-3">Status</th>
                  <th className="py-2.5 px-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-600">
                {filteredStudents.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="text-center py-8 text-slate-400">
                      No matching students found in this department.
                    </td>
                  </tr>
                ) : (
                  filteredStudents.map(student => (
                    <tr key={student.id} className="hover:bg-slate-50 transition-colors">
                      <td className="py-2.5 px-3 font-semibold text-slate-900">{student.name}</td>
                      <td className="py-2.5 px-3 font-mono text-slate-700">{student.rollNumber || 'N/A'}</td>
                      <td className="py-2.5 px-3">{student.className || student.section || 'General'}</td>
                      <td className="py-2.5 px-3 font-mono">{student.year || '4th Year'} (Sem {student.semester || 7})</td>
                      <td className="py-2.5 px-3 font-mono text-[11px] text-slate-500">{student.email}</td>
                      <td className="py-2.5 px-3">
                        <span className="px-2 py-0.5 text-[10px] font-bold rounded bg-emerald-50 text-emerald-800 border border-emerald-200">
                          Active
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-right">
                        <button
                          onClick={() => onNavigate('messages')}
                          className="text-xs font-semibold text-red-600 hover:text-red-700"
                        >
                          Message
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* C. FACULTY & ADVISOR OVERSIGHT */}
      {activeTab === 'advisors' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Faculty & Class Advisors Oversight</h3>
              <p className="text-xs text-slate-500">Supervise assigned class mentors and initiate follow-up actions.</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {allDeptAdvisors.map(adv => {
              const assignedClassStudents = allDeptStudents.filter(s => s.classId === adv.classId);
              return (
                <div key={adv.id} className="p-4 bg-slate-50 rounded-xl border border-slate-200 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between">
                      <span className="px-2 py-0.5 text-[10px] font-bold bg-blue-50 text-blue-800 rounded border border-blue-200 font-mono">
                        CLASS ADVISOR
                      </span>
                      <span className="text-[11px] font-mono text-slate-400">ID: {adv.employeeId || 'EMP-ADV'}</span>
                    </div>

                    <h4 className="text-sm font-bold text-slate-900 mt-2">{adv.name}</h4>
                    <p className="text-xs text-slate-500 font-mono mt-0.5">{adv.email}</p>

                    <div className="mt-3 p-3 bg-white rounded-lg border border-slate-200 text-xs space-y-1">
                      <p className="text-slate-700"><strong>Assigned Class:</strong> {adv.className || 'General Department Section'}</p>
                      <p className="text-slate-500 text-[11px]">Enrolled Mentees: {assignedClassStudents.length} students</p>
                    </div>
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-200 flex items-center justify-end gap-2">
                    <button
                      onClick={() => onNavigate('messages')}
                      className="px-3 py-1.5 text-xs font-semibold text-slate-700 hover:text-slate-900 bg-white hover:bg-slate-100 rounded border border-slate-200 transition-colors flex items-center gap-1"
                    >
                      <MessageSquare className="w-3.5 h-3.5 text-slate-500" />
                      <span>Direct Message</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* D. CLASS SECTIONS MANAGEMENT */}
      {activeTab === 'sections' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Departmental Classes & Sections</h3>
              <p className="text-xs text-slate-500">Configure and oversee department academic groups.</p>
            </div>

            <button
              onClick={() => setShowAddClassModal(true)}
              className="px-3.5 py-2 text-xs font-bold text-white bg-red-600 hover:bg-red-700 rounded-lg transition-colors flex items-center gap-1.5 shadow-xs"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Class / Section</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {deptClasses.map(cls => {
              const studentsInClass = allDeptStudents.filter(s => s.classId === cls.id);
              return (
                <div key={cls.id} className="p-4 bg-slate-50 rounded-xl border border-slate-200">
                  <div className="flex items-center justify-between text-[11px] font-mono text-slate-500">
                    <span className="font-bold text-slate-800">Semester {cls.semester}</span>
                    <span>{studentsInClass.length} Students</span>
                  </div>

                  <h4 className="text-sm font-bold text-slate-900 mt-2">{cls.name}</h4>
                  <p className="text-xs text-slate-500 mt-1">
                    Advisor: <strong>{cls.advisorName || 'Prof. Sandhya Menon'}</strong>
                  </p>

                  <div className="mt-4 pt-3 border-t border-slate-200 flex items-center justify-between text-xs">
                    <span className="text-slate-400 font-mono text-[11px]">{cls.id}</span>
                    <button
                      onClick={() => {
                        setStudentSectionFilter(cls.name);
                        setActiveTab('students');
                      }}
                      className="text-xs font-semibold text-red-600 hover:underline"
                    >
                      View Students &rarr;
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* E. ESCALATED GRIEVANCES VIEW */}
      {activeTab === 'grievances' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-5 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Department Grievances & Escalations</h3>
              <p className="text-xs text-slate-500">Review, adjudicate, or escalate petitions to the Principal.</p>
            </div>

            <div className="flex items-center gap-2">
              <select
                value={grievanceFilter}
                onChange={(e) => setGrievanceFilter(e.target.value as any)}
                className="text-xs py-1.5 px-3 rounded-lg border border-slate-300 bg-white"
              >
                <option value="ALL">All Case Statuses</option>
                <option value="ESCALATED_HOD">Escalated to HOD Desk</option>
                <option value="ADVISOR_REVIEW">Under Advisor Review</option>
                <option value="RESOLVED">Resolved Cases</option>
              </select>
            </div>
          </div>

          <div className="space-y-3">
            {filteredGrievances.length === 0 ? (
              <p className="text-xs text-slate-400 py-10 text-center">No grievances matching selected criteria.</p>
            ) : (
              filteredGrievances.map(g => (
                <div key={g.id} className="p-4 bg-slate-50 rounded-xl border border-slate-200 text-xs">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 font-mono">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-900 text-sm">{g.caseId}</span>
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        g.status === 'ESCALATED_HOD' ? 'bg-red-100 text-red-800 border border-red-300' : 'bg-slate-200 text-slate-700'
                      }`}>
                        {g.status.replace('_', ' ')}
                      </span>
                    </div>
                    <span className="text-red-700 font-bold uppercase">{g.priority} PRIORITY</span>
                  </div>

                  <h4 className="text-sm font-bold text-slate-800 mt-2">{g.title}</h4>
                  <p className="text-slate-600 mt-1 leading-relaxed">{g.description}</p>

                  <div className="mt-3 p-3 bg-white rounded-lg border border-slate-200 text-[11px] grid grid-cols-1 sm:grid-cols-3 gap-2">
                    <div><strong>Student:</strong> {g.studentName}</div>
                    <div><strong>Class:</strong> {g.className}</div>
                    <div><strong>Current Assignee:</strong> {g.currentAssigneeRole}</div>
                  </div>

                  <div className="mt-3 pt-3 border-t border-slate-200 flex flex-wrap items-center justify-end gap-2">
                    <button
                      onClick={() => setEscalateModalGrievance(g)}
                      className="px-3 py-1.5 text-xs font-semibold text-purple-700 hover:text-purple-900 bg-purple-50 hover:bg-purple-100 rounded border border-purple-200 transition-colors"
                    >
                      Escalate to Principal &uarr;
                    </button>
                    <button
                      onClick={() => {
                        const note = prompt('Enter resolution directive or formal closure summary:');
                        if (note) {
                          storageService.resolveGrievance(g.id, currentUser, note);
                        }
                      }}
                      className="px-3 py-1.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded transition-colors"
                    >
                      Resolve Case
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* F. SUGGESTIONS MANAGEMENT VIEW */}
      {activeTab === 'suggestions' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-5 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Student Proposals & Campus Feedback</h3>
              <p className="text-xs text-slate-500">Review departmental proposals submitted by students.</p>
            </div>

            <select
              value={suggestionFilter}
              onChange={(e) => setSuggestionFilter(e.target.value as any)}
              className="text-xs py-1.5 px-3 rounded-lg border border-slate-300 bg-white"
            >
              <option value="ALL">All Proposal Statuses</option>
              <option value="SUBMITTED">Newly Submitted</option>
              <option value="UNDER_REVIEW">Under Review</option>
              <option value="ACCEPTED">Approved Proposals</option>
              <option value="REJECTED">Declined Proposals</option>
            </select>
          </div>

          <div className="space-y-3">
            {filteredSuggestions.length === 0 ? (
              <p className="text-xs text-slate-400 py-10 text-center">No proposals matching selected filter.</p>
            ) : (
              filteredSuggestions.map(s => (
                <div key={s.id} className="p-4 bg-slate-50 rounded-xl border border-slate-200 text-xs">
                  <div className="flex items-center justify-between font-mono">
                    <span className="font-bold text-slate-900">{s.referenceNo}</span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-200 text-slate-700">
                      {s.status.replace('_', ' ')}
                    </span>
                  </div>

                  <h4 className="text-sm font-bold text-slate-800 mt-1">{s.title}</h4>
                  <p className="text-slate-600 mt-1 leading-relaxed">{s.description}</p>

                  <div className="mt-2 text-[11px] text-slate-500 font-mono">
                    Submitter: {s.isAnonymous ? 'Confidential / Anonymous' : s.studentName} · Category: {s.category}
                  </div>

                  {s.officialResponse && (
                    <div className="mt-2 p-2 bg-blue-50/60 rounded border border-blue-200 text-blue-900 text-[11px]">
                      <strong>HOD Note:</strong> {s.officialResponse}
                    </div>
                  )}

                  <div className="mt-3 pt-3 border-t border-slate-200 flex items-center justify-end gap-2">
                    <button
                      onClick={() => setReviewSuggestionModal(s)}
                      className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-100 rounded border border-slate-200"
                    >
                      Review & Respond &rarr;
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* G. DEPARTMENT ANALYTICS & SECTION RECORDS */}
      {activeTab === 'academics' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Department Sections & Student Group Registry</h3>
              <p className="text-xs text-slate-500">Official section breakdown and advisor assignments.</p>
            </div>
            <button
              onClick={onOpenExport}
              className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg border border-slate-200 flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5 text-slate-500" />
              <span>Export Report</span>
            </button>
          </div>

          {deptClasses.length === 0 ? (
            <p className="text-xs text-slate-400 py-8 text-center">No classes registered in this department yet.</p>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 text-xs">
              {deptClasses.map((cls) => {
                const studentsInClass = allDeptStudents.filter(s => s.classId === cls.id);
                return (
                  <div key={cls.id} className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-slate-900">{cls.name}</span>
                      <span className="text-slate-500 font-mono text-[11px]">Sem {cls.semester}</span>
                    </div>

                    <div className="p-3 bg-white rounded-lg border border-slate-200 space-y-2">
                      <div className="flex items-center justify-between text-[11px]">
                        <span className="text-slate-500">Registered Students:</span>
                        <span className="font-mono font-bold text-slate-900">{studentsInClass.length}</span>
                      </div>
                      <div className="flex items-center justify-between text-[11px]">
                        <span className="text-slate-500">Class Advisor:</span>
                        <span className="font-medium text-slate-800">{cls.advisorName || 'Not Assigned'}</span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-2 border-t border-slate-200 text-[11px]">
                      <span className="text-emerald-700 font-semibold font-mono">Status: Active Section</span>
                      <button
                        onClick={() => {
                          setStudentSectionFilter(cls.name);
                          setActiveTab('students');
                        }}
                        className="text-red-600 font-semibold hover:underline"
                      >
                        View Students &rarr;
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* MODAL 1: ADD CLASS / SECTION */}
      {showAddClassModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-white rounded-xl shadow-xl border border-slate-200 p-6">
            <h3 className="text-base font-bold text-slate-900">Add New Department Class / Section</h3>
            <p className="text-xs text-slate-500 mt-0.5">Register a section under {currentUser.departmentName}.</p>

            <form onSubmit={handleCreateClass} className="mt-4 space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Class & Section Title *</label>
                <input
                  type="text"
                  required
                  value={newClassName}
                  onChange={(e) => setNewClassName(e.target.value)}
                  placeholder="e.g. CSE - Second Year (Sec C)"
                  className="w-full p-2.5 rounded-lg border border-slate-300 focus:border-red-600 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Semester</label>
                <select
                  value={newClassSemester}
                  onChange={(e) => setNewClassSemester(Number(e.target.value))}
                  className="w-full p-2 rounded-lg border border-slate-300 bg-white"
                >
                  {[1, 2, 3, 4, 5, 6, 7, 8].map(sem => (
                    <option key={sem} value={sem}>Semester {sem}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Appointed Advisor</label>
                <select
                  value={newClassAdvisorId}
                  onChange={(e) => setNewClassAdvisorId(e.target.value)}
                  className="w-full p-2 rounded-lg border border-slate-300 bg-white"
                >
                  <option value="">Select advisor (optional)</option>
                  {allDeptAdvisors.map(adv => (
                    <option key={adv.id} value={adv.id}>{adv.name} ({adv.employeeId || 'Staff'})</option>
                  ))}
                </select>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddClassModal(false)}
                  className="px-3.5 py-2 font-medium text-slate-600 hover:text-slate-900"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 font-bold text-white bg-red-600 hover:bg-red-700 rounded-lg shadow-xs"
                >
                  Create Class Section
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: ESCALATE TO PRINCIPAL */}
      {escalateModalGrievance && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-white rounded-xl shadow-xl border border-slate-200 p-6">
            <div className="flex items-center gap-2 text-red-600 font-bold text-xs uppercase">
              <ShieldAlert className="w-4 h-4" />
              <span>Escalate to Principal Office</span>
            </div>
            <h3 className="text-base font-bold text-slate-900 mt-1">
              Case {escalateModalGrievance.caseId}
            </h3>
            <p className="text-xs text-slate-600 mt-1">{escalateModalGrievance.title}</p>

            <div className="mt-4 space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Department Head Escalation Justification *
                </label>
                <textarea
                  rows={4}
                  required
                  value={escalateReason}
                  onChange={(e) => setEscalateReason(e.target.value)}
                  placeholder="Provide detailed institutional context and recommendation for executive intervention..."
                  className="w-full p-2.5 rounded-lg border border-slate-300 focus:border-red-600 focus:outline-hidden"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setEscalateModalGrievance(null)}
                  className="px-3.5 py-2 font-medium text-slate-600 hover:text-slate-900"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleConfirmEscalation}
                  className="px-4 py-2 font-bold text-white bg-purple-700 hover:bg-purple-800 rounded-lg shadow-xs"
                >
                  Confirm Escalation to Principal
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 3: REVIEW SUGGESTION */}
      {reviewSuggestionModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-white rounded-xl shadow-xl border border-slate-200 p-6">
            <h3 className="text-base font-bold text-slate-900">Review Student Proposal</h3>
            <p className="text-xs text-slate-500 font-mono mt-0.5">{reviewSuggestionModal.referenceNo} · {reviewSuggestionModal.title}</p>
            <p className="text-xs text-slate-600 mt-2 bg-slate-50 p-2.5 rounded border border-slate-200">{reviewSuggestionModal.description}</p>

            <div className="mt-4 space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Official Response / Review Remarks</label>
                <textarea
                  rows={3}
                  value={suggestionOfficialResponse}
                  onChange={(e) => setSuggestionOfficialResponse(e.target.value)}
                  placeholder="State decision or administrative steps taken..."
                  className="w-full p-2.5 rounded-lg border border-slate-300 focus:border-red-600 focus:outline-hidden"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setReviewSuggestionModal(null)}
                  className="px-3 py-1.5 font-medium text-slate-600"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={() => handleUpdateSuggestion('REJECTED')}
                  className="px-3 py-1.5 font-semibold text-red-700 bg-red-50 hover:bg-red-100 rounded border border-red-200"
                >
                  Decline
                </button>
                <button
                  type="button"
                  onClick={() => handleUpdateSuggestion('ACCEPTED')}
                  className="px-4 py-1.5 font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded shadow-xs"
                >
                  Approve Proposal
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 4: HOD PROFILE MODAL */}
      {showProfileModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-white rounded-xl shadow-xl border border-slate-200 p-6">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Building2 className="w-5 h-5 text-red-600" />
                <h3 className="text-base font-bold text-slate-900">Head of Department Profile</h3>
              </div>
              <button
                onClick={() => setShowProfileModal(false)}
                className="p-1 text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="mt-4 space-y-3 text-xs">
              <div className="flex items-center justify-between py-1.5 border-b border-slate-100">
                <span className="text-slate-500">Official Name</span>
                <span className="font-bold text-slate-900">{currentUser.name}</span>
              </div>
              <div className="flex items-center justify-between py-1.5 border-b border-slate-100">
                <span className="text-slate-500">Institutional Role</span>
                <span className="font-mono font-bold text-red-700">HEAD OF DEPARTMENT (HOD)</span>
              </div>
              <div className="flex items-center justify-between py-1.5 border-b border-slate-100">
                <span className="text-slate-500">Department</span>
                <span className="font-semibold text-slate-800">{currentUser.departmentName}</span>
              </div>
              <div className="flex items-center justify-between py-1.5 border-b border-slate-100">
                <span className="text-slate-500">Staff Employee ID</span>
                <span className="font-mono text-slate-700">{currentUser.employeeId || 'EMP-CSE-HOD'}</span>
              </div>
              <div className="flex items-center justify-between py-1.5 border-b border-slate-100">
                <span className="text-slate-500">Institutional Email</span>
                <span className="font-mono text-slate-700">{currentUser.email}</span>
              </div>
              <div className="flex items-center justify-between py-1.5">
                <span className="text-slate-500">Session Status</span>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-50 text-emerald-800 border border-emerald-200">
                  Authenticated & Active
                </span>
              </div>

              <div className="pt-4 mt-2 border-t border-slate-200 flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => setShowProfileModal(false)}
                  className="px-3.5 py-2 font-medium text-slate-600 hover:text-slate-800"
                >
                  Close
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowProfileModal(false);
                    logout();
                    window.location.href = '/';
                  }}
                  className="px-4 py-2 font-bold text-red-700 hover:text-white hover:bg-red-600 border border-red-200 hover:border-red-600 rounded-lg transition-colors flex items-center gap-1.5"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Secure Sign Out</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
