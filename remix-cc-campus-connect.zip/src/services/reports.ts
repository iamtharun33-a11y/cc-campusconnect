import { Announcement, Grievance, Suggestion } from '../types';

/**
 * Escapes CSV values according to RFC4180 and protects against formula injection
 */
function escapeCsvCell(val: unknown): string {
  if (val === null || val === undefined) return '""';
  let str = String(val).replace(/"/g, '""');
  // Formula injection defense: prevent Excel from executing formulas starting with =, +, -, @
  if (/^[=+\-@\t\r]/.test(str)) {
    str = `'${str}`;
  }
  return `"${str}"`;
}

export const reportService = {
  /**
   * Generates and triggers download of a safe CSV file
   */
  downloadCsv(filename: string, headers: string[], rows: (string | number | boolean | null | undefined)[][]): void {
    const csvContent = [
      headers.map(escapeCsvCell).join(','),
      ...rows.map(row => row.map(escapeCsvCell).join(','))
    ].join('\r\n');

    const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `${filename}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  },

  /**
   * Generates and triggers download of an Excel-compatible XML Spreadsheet (.xls)
   */
  downloadXlsx(filename: string, sheetName: string, headers: string[], rows: (string | number | boolean | null | undefined)[][]): void {
    const xmlHeader = `<?xml version="1.0" encoding="UTF-8"?>
<?mso-application progid="Excel.Sheet"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:o="urn:schemas-microsoft-com:office:office"
 xmlns:x="urn:schemas-microsoft-com:office:excel"
 xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">
 <Styles>
  <Style ss:ID="Header">
   <Font ss:Bold="1" ss:Color="#FFFFFF"/>
   <Interior ss:Color="#DC2626" ss:Pattern="Solid"/>
   <Alignment ss:Horizontal="Center" ss:Vertical="Center"/>
  </Style>
  <Style ss:ID="Cell">
   <Alignment ss:Vertical="Center"/>
  </Style>
 </Styles>
 <Worksheet ss:Name="${sheetName}">
  <Table>`;

    let xmlRows = `<Row ss:StyleID="Header">`;
    headers.forEach(h => {
      xmlRows += `<Cell><Data ss:Type="String">${escapeXml(h)}</Data></Cell>`;
    });
    xmlRows += `</Row>`;

    rows.forEach(row => {
      xmlRows += `<Row ss:StyleID="Cell">`;
      row.forEach(cell => {
        const val = cell === null || cell === undefined ? '' : String(cell);
        const isNum = typeof cell === 'number';
        xmlRows += `<Cell><Data ss:Type="${isNum ? 'Number' : 'String'}">${escapeXml(val)}</Data></Cell>`;
      });
      xmlRows += `</Row>`;
    });

    const xmlFooter = `  </Table>
 </Worksheet>
</Workbook>`;

    const fullXml = xmlHeader + xmlRows + xmlFooter;
    const blob = new Blob([fullXml], { type: 'application/vnd.ms-excel;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `${filename}.xls`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  },

  /**
   * Prepares and opens a printable PDF document view with print trigger
   */
  printPdfReport(title: string, subtitle: string, headers: string[], rows: (string | number | boolean | null | undefined)[][]): void {
    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      alert('Pop-up blocked. Please enable pop-ups to generate PDF.');
      return;
    }

    const html = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>${escapeXml(title)} — CC Campus Connect Report</title>
        <style>
          body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; margin: 40px; color: #0f172a; }
          .header { border-bottom: 2px solid #dc2626; padding-bottom: 16px; margin-bottom: 24px; display: flex; justify-content: space-between; align-items: flex-end; }
          .brand { font-size: 20px; font-weight: 800; color: #dc2626; letter-spacing: -0.5px; }
          .title { font-size: 18px; font-weight: 700; margin-top: 4px; color: #1e293b; }
          .meta { font-size: 12px; color: #64748b; }
          table { width: 100%; border-collapse: collapse; margin-top: 16px; font-size: 13px; }
          th { background: #f8fafc; border: 1px solid #cbd5e1; padding: 10px 12px; text-align: left; font-weight: 600; color: #334155; }
          td { border: 1px solid #e2e8f0; padding: 8px 12px; }
          tr:nth-child(even) { background-color: #f8fafc; }
          .footer { margin-top: 32px; font-size: 11px; color: #94a3b8; text-align: center; border-top: 1px solid #e2e8f0; padding-top: 12px; }
          @media print {
            button { display: none; }
          }
        </style>
      </head>
      <body>
        <div class="header">
          <div>
            <div class="brand">CC CAMPUS CONNECT</div>
            <div class="title">${escapeXml(title)}</div>
            <div class="meta">${escapeXml(subtitle)}</div>
          </div>
          <div style="text-align: right;">
            <div class="meta">Generated: ${new Date().toLocaleString()}</div>
            <div class="meta">Confidential Institutional Record</div>
          </div>
        </div>

        <div style="margin-bottom: 16px; text-align: right;">
          <button onclick="window.print()" style="background: #dc2626; color: white; border: none; padding: 8px 16px; border-radius: 6px; font-weight: 600; cursor: pointer;">
            Print / Save as PDF
          </button>
        </div>

        <table>
          <thead>
            <tr>${headers.map(h => `<th>${escapeXml(h)}</th>`).join('')}</tr>
          </thead>
          <tbody>
            ${rows.map(row => `<tr>${row.map(c => `<td>${escapeXml(c === null || c === undefined ? '—' : String(c))}</td>`).join('')}</tr>`).join('')}
          </tbody>
        </table>

        <div class="footer">
          Official Institutional Record — CC Campus Connect Enterprise Communication System
        </div>
        <script>
          setTimeout(() => { window.print(); }, 400);
        </script>
      </body>
      </html>
    `;

    printWindow.document.open();
    printWindow.document.write(html);
    printWindow.document.close();
  },

  // Helper formats for Grievances, Announcements, and Suggestions
  formatGrievancesForExport(grievances: Grievance[]) {
    const headers = ['Case ID', 'Title', 'Category', 'Priority', 'Status', 'Student Name', 'Department', 'Class', 'Due Date', 'Created Date', 'Resolution'];
    const rows = grievances.map(g => [
      g.caseId,
      g.title,
      g.category,
      g.priority,
      g.status,
      g.studentName,
      g.departmentName,
      g.className,
      g.dueDate.split('T')[0],
      g.createdAt.split('T')[0],
      g.resolutionSummary || 'Pending'
    ]);
    return { headers, rows };
  },

  formatSuggestionsForExport(suggestions: Suggestion[]) {
    const headers = ['Reference No', 'Title', 'Category', 'Status', 'Submitted By', 'Department', 'Official Response', 'Date'];
    const rows = suggestions.map(s => [
      s.referenceNo,
      s.title,
      s.category,
      s.status,
      s.isAnonymous ? 'Anonymous Student' : (s.studentName || 'Student'),
      s.departmentName,
      s.officialResponse || 'Under Review',
      s.createdAt.split('T')[0]
    ]);
    return { headers, rows };
  },

  formatAnnouncementsForExport(announcements: Announcement[]) {
    const headers = ['Notice ID', 'Title', 'Category', 'Priority', 'Audience', 'Publisher', 'Role', 'Status', 'Acknowledgements', 'Date'];
    const rows = announcements.map(a => [
      a.id,
      a.title,
      a.category,
      a.priority,
      a.audience,
      a.publisherName,
      a.publisherRole,
      a.isDraft ? 'Draft' : 'Published',
      a.acknowledgements ? a.acknowledgements.length : 0,
      a.createdAt.split('T')[0]
    ]);
    return { headers, rows };
  }
};

function escapeXml(unsafe: string): string {
  return unsafe.replace(/[<>&'"]/g, (c) => {
    switch (c) {
      case '<': return '&lt;';
      case '>': return '&gt;';
      case '&': return '&amp;';
      case '\'': return '&apos;';
      case '"': return '&quot;';
      default: return c;
    }
  });
}
